import React, { useState, useContext, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Navbar from "../components/Navbar";
import { AuthContext } from "../context/AuthContext";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUser,
  faLock,
  faSpinner,
  faCheck,
  faExclamationTriangle,
  faStore,
  faGlobe,
  faPhone,
  faEnvelope,
  faLocationDot,
  faEdit,
  faChartBar,
} from "@fortawesome/free-solid-svg-icons";

import SellerProfileSection from "../components/account/SellerProfileSection";
import PasswordChangeForm from "../components/account/PasswordChangeForm";
import EmailChangeForm from "../components/account/EmailChangeForm";
import SellerReviewsSection from "../components/account/SellerReviewsSection";

const AccountPage = () => {
  const { isAuthenticated, user, refreshUser, logout } =
    useContext(AuthContext);
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("profile");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/");
    }
  }, [isAuthenticated, navigate]);

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <FontAwesomeIcon
          icon={faSpinner}
          spin
          className="text-cyan-500 text-4xl"
        />
      </div>
    );
  }

  const handleSuccess = (message, shouldLogout = false) => {
    setSuccess(true);
    if (shouldLogout) {
      setTimeout(() => {
        setSuccess(false);
        logout();
        navigate("/");
      }, 3000);
    } else {
      setTimeout(() => setSuccess(false), 3000);
    }
  };

  const handleError = (errorMessage) => {
    setError(errorMessage);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">
      <Navbar />

      <div className="flex-1 p-8 ml-64">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="bg-cyan-500 p-6">
            <div className="flex items-center">
              <div className="bg-white rounded-full p-4 shadow-md">
                <FontAwesomeIcon
                  icon={faStore}
                  className="text-cyan-500 text-2xl"
                />
              </div>
              <div className="ml-4 text-white">
                <h1 className="text-2xl font-bold">Seller Account</h1>
                <p>Manage your business information and account settings</p>
              </div>
            </div>
          </div>

          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              <button
                onClick={() => setActiveTab("profile")}
                className={`py-4 px-6 font-medium text-sm border-b-2 focus:outline-none ${
                  activeTab === "profile"
                    ? "border-cyan-500 text-cyan-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <FontAwesomeIcon icon={faStore} className="mr-2" />
                Business Profile
              </button>
              <button
                onClick={() => setActiveTab("reviews")}
                className={`py-4 px-6 font-medium text-sm border-b-2 focus:outline-none ${
                  activeTab === "reviews"
                    ? "border-cyan-500 text-cyan-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <FontAwesomeIcon icon={faChartBar} className="mr-2" />
                Reviews & Ratings
              </button>
              <button
                onClick={() => setActiveTab("security")}
                className={`py-4 px-6 font-medium text-sm border-b-2 focus:outline-none ${
                  activeTab === "security"
                    ? "border-cyan-500 text-cyan-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <FontAwesomeIcon icon={faLock} className="mr-2" />
                Security
              </button>
            </nav>
          </div>

          {success && (
            <div className="bg-green-100 text-green-700 p-4 flex items-center">
              <FontAwesomeIcon icon={faCheck} className="mr-2" />
              {activeTab === "profile"
                ? "Business profile updated successfully!"
                : activeTab === "security"
                ? "Changes saved successfully! You may be logged out shortly."
                : "Update successful!"}
            </div>
          )}

          {error && (
            <div className="bg-red-100 text-red-700 p-4 flex items-center">
              <FontAwesomeIcon icon={faExclamationTriangle} className="mr-2" />
              {error}
              <button
                onClick={() => setError(null)}
                className="ml-auto text-red-700 hover:text-red-900"
              >
                ×
              </button>
            </div>
          )}

          <div className="p-6">
            {activeTab === "profile" && (
              <SellerProfileSection
                user={user}
                isEditing={isEditing}
                setIsEditing={setIsEditing}
                refreshUser={refreshUser}
                onSuccess={handleSuccess}
                onError={handleError}
                setLoading={setLoading}
                loading={loading}
              />
            )}

            {activeTab === "reviews" && <SellerReviewsSection user={user} />}

            {activeTab === "security" && (
              <div className="space-y-8">
                <PasswordChangeForm
                  onSuccess={handleSuccess}
                  onError={handleError}
                  setLoading={setLoading}
                  loading={loading}
                />

                <EmailChangeForm
                  user={user}
                  onSuccess={handleSuccess}
                  onError={handleError}
                  setLoading={setLoading}
                  loading={loading}
                  refreshUser={refreshUser}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountPage;
