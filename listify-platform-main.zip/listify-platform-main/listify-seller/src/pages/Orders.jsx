import React, { useState, useEffect, useContext } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faSearch,
  faSpinner,
  faExclamationTriangle,
  faFilter,
  faCheck,
  faTimes,
  faBox,
  faTruck,
  faShippingFast,
  faCheckCircle,
} from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import Navbar from "../components/Navbar";
import { AuthContext } from "../context/AuthContext";

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [pagination, setPagination] = useState({
    page: 1,
    totalPages: 1,
    total: 0,
  });
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [orderUpdated, setOrderUpdated] = useState(false);
  const { user } = useContext(AuthContext);

  useEffect(() => {
    if (user && user.uuid) {
      fetchOrders();
    } else {
      setLoading(false);
      setError("Please log in to view your orders");
    }
  }, [pagination.page, statusFilter, user]);

  const fetchOrders = async () => {
    if (!user?.uuid) {
      console.log("No user UUID available:", user);
      setLoading(false);
      setError("Seller ID is not available");
      return;
    }

    try {
      setLoading(true);
      setError(null);

      let url = `http://localhost:8080/api/orders/seller/${user.uuid}?page=${pagination.page}&limit=10`;

      if (statusFilter !== "all") {
        url += `&status=${statusFilter}`;
      }

      console.log("Fetching orders from:", url);
      console.log("User data:", {
        uuid: user.uuid,
        token: user.token ? "present" : "missing",
      });

      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${
            user.token || localStorage.getItem("token")
          }`,
          "Content-Type": "application/json",
        },
        timeout: 10000, // 10 second timeout
      });

      console.log("Response received:", {
        status: response.status,
        data: response.data,
        orders: response.data.orders,
        ordersLength: response.data.orders?.length || 0,
        pagination: response.data.pagination,
      });

      setOrders(response.data.orders || []);
      setPagination({
        page: response.data.pagination?.page || 1,
        totalPages: response.data.pagination?.pages || 1,
        total: response.data.pagination?.total || 0,
      });

      console.log("Orders set in state:", response.data.orders?.length || 0);
    } catch (err) {
      console.error("Error fetching orders:", {
        message: err.message,
        response: err.response?.data,
        status: err.response?.status,
        url: err.config?.url,
      });

      if (err.response?.status === 404) {
        setError(
          "Orders endpoint not found. Please check your API configuration."
        );
      } else if (err.response?.status === 401) {
        setError("Authentication failed. Please log in again.");
      } else if (err.response?.status === 403) {
        setError("Access denied. You don't have permission to view orders.");
      } else {
        setError(
          `Failed to load orders: ${err.response?.data?.message || err.message}`
        );
      }
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleFilterChange = (e) => {
    setStatusFilter(e.target.value);
    setPagination({ ...pagination, page: 1 });
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      setPagination({ ...pagination, page: newPage });
    }
  };

  const handleViewOrder = (order) => {
    setSelectedOrder(order);
  };

  const handleCloseDetails = () => {
    setSelectedOrder(null);
    if (orderUpdated) {
      fetchOrders();
      setOrderUpdated(false);
    }
  };

  const updateOrderStatus = async (orderId, newStatus) => {
    try {
      setUpdatingStatus(true);
      const token = user.token || localStorage.getItem("token");

      await axios.put(
        `http://localhost:8080/api/orders/${orderId}`,
        { status: newStatus },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      // Update local state
      if (selectedOrder && selectedOrder.orderId === orderId) {
        setSelectedOrder({ ...selectedOrder, status: newStatus });
      }

      // Mark that an update happened
      setOrderUpdated(true);

      alert(`Order status updated to ${newStatus}`);
    } catch (err) {
      console.error("Error updating order status:", err);
      alert("Failed to update order status");
    } finally {
      setUpdatingStatus(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "PENDING":
        return "bg-yellow-100 text-yellow-800";
      case "PAYMENT_PROCESSING":
        return "bg-blue-100 text-blue-800";
      case "PAID":
        return "bg-green-100 text-green-800";
      case "PREPARING":
        return "bg-purple-100 text-purple-800";
      case "SHIPPED":
        return "bg-indigo-100 text-indigo-800";
      case "DELIVERED":
        return "bg-green-100 text-green-800";
      case "CANCELLED":
        return "bg-red-100 text-red-800";
      case "FAILED":
        return "bg-red-500 text-white";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "PENDING":
        return faSpinner;
      case "PAYMENT_PROCESSING":
        return faSpinner;
      case "PAID":
        return faCheck;
      case "PREPARING":
        return faBox;
      case "SHIPPED":
        return faTruck;
      case "DELIVERED":
        return faCheckCircle;
      case "CANCELLED":
        return faTimes;
      default:
        return faSpinner;
    }
  };

  // Filter orders by search term
  const filteredOrders = orders.filter((order) =>
    searchTerm
      ? order.orderId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.shippingInfo?.fullName
          .toLowerCase()
          .includes(searchTerm.toLowerCase())
      : true
  );

  // Format date for display
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Format currency for display
  const formatCurrency = (amount) => {
    return `$${parseFloat(amount).toFixed(2)}`;
  };

  // Get available status options based on current status
  const getAvailableStatusOptions = (currentStatus) => {
    const allStatuses = [
      "PENDING",
      "PAID",
      "PREPARING",
      "SHIPPED",
      "DELIVERED",
    ];

    // For cancelled orders, return no options
    if (currentStatus === "CANCELLED") return [];

    // For payment-related statuses, only allow viewing
    if (["PENDING", "PAYMENT_PROCESSING"].includes(currentStatus)) {
      return [];
    }

    const currentIndex = allStatuses.indexOf(currentStatus);
    if (currentIndex !== -1) {
      return allStatuses.slice(currentIndex + 1);
    }

    return [];
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Navbar />
      <div className="ml-[240px] w-full p-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold text-cyan-500">Orders</h1>

          <div className="flex items-center space-x-4">
            <div className="relative">
              <select
                value={statusFilter}
                onChange={handleFilterChange}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500"
              >
                <option value="all">All Statuses</option>
                <option value="PENDING">Pending</option>
                <option value="PAYMENT_PROCESSING">Payment Processing</option>
                <option value="PAID">Paid</option>
                <option value="PREPARING">Preparing</option>
                <option value="SHIPPED">Shipped</option>
                <option value="DELIVERED">Delivered</option>
                <option value="CANCELLED">Cancelled</option>
              </select>
              <div className="absolute left-3 top-2.5 text-gray-400">
                <FontAwesomeIcon icon={faFilter} />
              </div>
            </div>

            <div className="relative">
              <input
                type="text"
                placeholder="Search orders..."
                value={searchTerm}
                onChange={handleSearchChange}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500"
              />
              <div className="absolute left-3 top-2.5 text-gray-400">
                <FontAwesomeIcon icon={faSearch} />
              </div>
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-100 text-red-700 p-4 rounded-md mb-4 flex justify-between">
            <span>{error}</span>
            <button onClick={() => setError(null)}>×</button>
          </div>
        )}

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <FontAwesomeIcon
              icon={faSpinner}
              spin
              className="text-cyan-500 text-4xl"
            />
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-8 text-center">
            <FontAwesomeIcon
              icon={faBox}
              className="text-gray-300 text-6xl mb-4"
            />
            <h3 className="text-xl font-medium text-gray-700 mb-2">
              No Orders Found
            </h3>
            <p className="text-gray-500 mb-4">
              {searchTerm
                ? "No orders match your search criteria"
                : "You don't have any orders yet."}
            </p>
          </div>
        ) : (
          <>
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Order ID
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Customer
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Amount
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredOrders.map((order) => (
                    <tr key={order.orderId} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div
                          className="text-sm font-medium text-gray-900"
                          title={order.orderId}
                        >
                          {order.orderId.substring(0, 8)}...
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">
                          {formatDate(order.createdAt)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">
                          {order.shippingInfo.fullName}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {formatCurrency(order.totalAmount)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-2 py-1 inline-flex items-center text-xs leading-5 font-semibold rounded-full ${getStatusColor(
                            order.status
                          )}`}
                        >
                          <FontAwesomeIcon
                            icon={getStatusIcon(order.status)}
                            className="mr-1 flex-shrink-0 text-[0.75rem]"
                          />
                          <span className="relative top-px">
                            {order.status.replace("_", " ")}
                          </span>
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => handleViewOrder(order)}
                          className="text-cyan-600 hover:text-cyan-900"
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {pagination.totalPages > 1 && (
              <div className="flex justify-between items-center mt-6">
                <div className="text-sm text-gray-700">
                  Showing page {pagination.page} of {pagination.totalPages}
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handlePageChange(pagination.page - 1)}
                    disabled={pagination.page === 1}
                    className={`px-3 py-1 rounded ${
                      pagination.page === 1
                        ? "bg-gray-200 text-gray-500 cursor-not-allowed"
                        : "bg-cyan-500 text-white hover:bg-cyan-600"
                    }`}
                  >
                    Previous
                  </button>
                  <button
                    onClick={() => handlePageChange(pagination.page + 1)}
                    disabled={pagination.page === pagination.totalPages}
                    className={`px-3 py-1 rounded ${
                      pagination.page === pagination.totalPages
                        ? "bg-gray-200 text-gray-500 cursor-not-allowed"
                        : "bg-cyan-500 text-white hover:bg-cyan-600"
                    }`}
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </>
        )}

        {selectedOrder && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-semibold text-gray-900">
                    Order #{selectedOrder.orderId.substring(0, 8)}...
                  </h2>
                  <button
                    onClick={handleCloseDetails}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    ×
                  </button>
                </div>
                <p className="text-gray-500 mt-1">
                  Placed on {formatDate(selectedOrder.createdAt)}
                </p>
              </div>

              <div className="p-6 border-b">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium">Current Status</h3>
                  <span
                    className={`px-3 py-1 inline-flex items-center text-sm font-semibold rounded-full ${getStatusColor(
                      selectedOrder.status
                    )}`}
                  >
                    <FontAwesomeIcon
                      icon={getStatusIcon(selectedOrder.status)}
                      className="mr-2"
                    />
                    {selectedOrder.status.replace("_", " ")}
                  </span>
                </div>

                {getAvailableStatusOptions(selectedOrder.status).length > 0 && (
                  <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                    <h4 className="text-sm font-medium text-gray-700 mb-2">
                      Update Order Status
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {getAvailableStatusOptions(selectedOrder.status).map(
                        (status) => (
                          <button
                            key={status}
                            onClick={() =>
                              updateOrderStatus(selectedOrder.orderId, status)
                            }
                            disabled={updatingStatus}
                            className="px-3 py-1 bg-cyan-100 text-cyan-700 rounded-full hover:bg-cyan-200 text-sm font-medium flex items-center"
                          >
                            <FontAwesomeIcon
                              icon={getStatusIcon(status)}
                              className="mr-1"
                            />
                            Mark as {status.replace("_", " ")}
                          </button>
                        )
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="p-6 border-b grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Customer</h3>
                  <p className="text-gray-600">
                    {selectedOrder.shippingInfo.fullName}
                    <br />
                    User ID: {selectedOrder.userId.substring(0, 8)}...
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-2">Contact</h3>
                  <p className="text-gray-600">
                    {selectedOrder.shippingInfo.phone || "No phone provided"}
                  </p>
                </div>
              </div>

              <div className="p-6 border-b grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Shipping Address</h3>
                  <p className="text-gray-600">
                    {selectedOrder.shippingInfo.fullName}
                    <br />
                    {selectedOrder.shippingInfo.addressLine1}
                    <br />
                    {selectedOrder.shippingInfo.addressLine2 && (
                      <>
                        {selectedOrder.shippingInfo.addressLine2}
                        <br />
                      </>
                    )}
                    {selectedOrder.shippingInfo.city},{" "}
                    {selectedOrder.shippingInfo.state}{" "}
                    {selectedOrder.shippingInfo.postalCode}
                    <br />
                    {selectedOrder.shippingInfo.country}
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-2">Billing Address</h3>
                  <p className="text-gray-600">
                    {selectedOrder.billingInfo.fullName}
                    <br />
                    {selectedOrder.billingInfo.addressLine1}
                    <br />
                    {selectedOrder.billingInfo.addressLine2 && (
                      <>
                        {selectedOrder.billingInfo.addressLine2}
                        <br />
                      </>
                    )}
                    {selectedOrder.billingInfo.city},{" "}
                    {selectedOrder.billingInfo.state}{" "}
                    {selectedOrder.billingInfo.postalCode}
                    <br />
                    {selectedOrder.billingInfo.country}
                  </p>
                </div>
              </div>

              <div className="p-6 border-b">
                <h3 className="text-lg font-medium mb-4">Order Items</h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Product
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Price
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Quantity
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Total
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {selectedOrder.orderItems.map((item, index) => (
                        <tr key={index}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">
                              {item.name}
                            </div>
                            <div className="text-sm text-gray-500">
                              ID: {item.productId.substring(0, 8)}...
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              ${item.price.toFixed(2)}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              {item.quantity}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">
                              ${(item.price * item.quantity).toFixed(2)}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-gray-50">
                      <tr>
                        <th
                          colSpan="3"
                          className="px-6 py-3 text-right text-sm font-medium text-gray-500"
                        >
                          Subtotal
                        </th>
                        <td className="px-6 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                          ${selectedOrder.totalAmount.toFixed(2)}
                        </td>
                      </tr>
                      <tr>
                        <th
                          colSpan="3"
                          className="px-6 py-3 text-right text-sm font-medium text-gray-900"
                        >
                          Total
                        </th>
                        <td className="px-6 py-3 whitespace-nowrap text-sm font-bold text-gray-900">
                          ${selectedOrder.totalAmount.toFixed(2)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>

              <div className="p-6 border-b">
                <h3 className="text-lg font-medium mb-4">
                  Payment Information
                </h3>
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Payment Status</p>
                      <p className="text-sm font-medium">
                        {selectedOrder.paymentInfo.status}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Payment ID</p>
                      <p className="text-sm font-medium">
                        {selectedOrder.paymentInfo.paymentId || "Not available"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {selectedOrder.notes && (
                <div className="p-6 border-b">
                  <h3 className="text-lg font-medium mb-2">Notes</h3>
                  <p className="text-gray-600">{selectedOrder.notes}</p>
                </div>
              )}

              <div className="flex justify-end p-6">
                <button
                  onClick={handleCloseDetails}
                  className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Orders;
