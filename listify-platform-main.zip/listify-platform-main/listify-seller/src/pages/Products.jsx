import React, { useState, useEffect, useContext, useCallback } from "react";
import axios from "axios";
import { AuthContext } from "../context/AuthContext";
import Navbar from "../components/Navbar";
import ProductsList from "../components/products/ProductsList";
import ProductForm from "../components/products/ProductForm";
import SearchBar from "../components/products/SearchBar";
import Pagination from "../components/products/Pagination";
import LoadingSpinner from "../components/shared/LoadingSpinner";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faPlus,
  faExclamationTriangle,
} from "@fortawesome/free-solid-svg-icons";

const Products = () => {
  const { user } = useContext(AuthContext);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleteConfirmation, setDeleteConfirmation] = useState(null);
  const [error, setError] = useState(null);
  const [pagination, setPagination] = useState({
    page: 1,
    totalPages: 0,
    total: 0,
  });
  const [showModal, setShowModal] = useState(false);
  const [currentProduct, setCurrentProduct] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoadingProduct, setIsLoadingProduct] = useState(false);

  const fetchProducts = useCallback(
    async (page = 1) => {
      try {
        setLoading(true);
        const timestamp = new Date().getTime();
        const response = await axios.get(
          `http://localhost:8080/api/products/seller?page=${page}&limit=10&_t=${timestamp}`,
          {
            headers: {
              Authorization: `Bearer ${user.token}`,
            },
          }
        );

        setProducts(response.data.products);
        setPagination({
          page: response.data.page,
          totalPages: response.data.totalPages,
          total: response.data.total,
        });
      } catch (err) {
        setError("Failed to load products. Please try again.");
      } finally {
        setLoading(false);
      }
    },
    [user]
  );

  useEffect(() => {
    if (user?.token) {
      fetchProducts(pagination.page);
    }
  }, [user, fetchProducts, pagination.page]);

  const handleAddNew = () => {
    setCurrentProduct(null);
    setShowModal(true);
  };

  const handleEdit = async (product) => {
    try {
      setIsLoadingProduct(true);
      const response = await axios.get(
        `http://localhost:8080/api/products/${product.uuid}`,
        {
          headers: {
            Authorization: `Bearer ${user.token}`,
          },
          params: {
            _t: new Date().getTime(),
          },
        }
      );

      setCurrentProduct(response.data);
      setShowModal(true);
    } catch (err) {
      setError("Failed to load product details. Please try again.");
    } finally {
      setIsLoadingProduct(false);
    }
  };

  const handleDelete = (productId) => {
    const productToDelete = products.find(
      (product) => product.uuid === productId
    );
    setDeleteConfirmation(productToDelete);
  };

  const confirmDelete = async () => {
    try {
      await axios.delete(
        `http://localhost:8080/api/products/${deleteConfirmation.uuid}`,
        {
          headers: {
            Authorization: `Bearer ${user.token}`,
          },
        }
      );

      setDeleteConfirmation(null);
      fetchProducts(pagination.page);
    } catch (err) {
      setError("Failed to delete product. Please try again.");
      setDeleteConfirmation(null);
    }
  };

  const handleStockUpdate = async (product, increment) => {
    try {
      const newStock = Math.max(0, product.stock + increment);

      setProducts((prevProducts) =>
        prevProducts.map((p) =>
          p.uuid === product.uuid ? { ...p, stock: newStock } : p
        )
      );

      await axios.put(
        `http://localhost:8080/api/products/${product.uuid}`,
        {
          ...product,
          stock: newStock,
        },
        {
          headers: {
            Authorization: `Bearer ${user.token}`,
          },
          params: {
            _t: new Date().getTime(),
          },
        }
      );
    } catch (err) {
      setError("Failed to update stock. Please try again.");
      fetchProducts(pagination.page);
    }
  };

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleFormSubmit = async (formData, isNewProduct) => {
    try {
      if (isNewProduct) {
        await axios.post("http://localhost:8080/api/products", formData, {
          headers: {
            Authorization: `Bearer ${user.token}`,
          },
        });
      } else {
        await axios.put(
          `http://localhost:8080/api/products/${currentProduct.uuid}`,
          formData,
          {
            headers: {
              Authorization: `Bearer ${user.token}`,
            },
          }
        );
      }
      setShowModal(false);
      fetchProducts(pagination.page);
    } catch (err) {
      setError("Failed to save product. Please try again.");
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Navbar />
      <div className="ml-[240px] w-full p-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold text-cyan-500">Products</h1>
          <button
            onClick={handleAddNew}
            className="bg-cyan-500 text-white px-4 py-2 rounded-md hover:bg-cyan-600 transition-colors flex items-center"
          >
            <FontAwesomeIcon icon={faPlus} className="mr-2" />
            Add New Product
          </button>
        </div>

        <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />

        {error && (
          <div className="bg-red-100 text-red-700 p-4 rounded-md mb-4 flex justify-between">
            <span>{error}</span>
            <button onClick={() => setError(null)}>×</button>
          </div>
        )}

        {loading ? (
          <LoadingSpinner />
        ) : (
          <>
            <ProductsList
              products={filteredProducts}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onStockUpdate={handleStockUpdate}
            />

            {pagination.totalPages > 1 && (
              <Pagination
                currentPage={pagination.page}
                totalPages={pagination.totalPages}
                onPageChange={(page) => fetchProducts(page)}
              />
            )}
          </>
        )}

        {showModal && (
          <ProductForm
            product={currentProduct}
            onSubmit={handleFormSubmit}
            onCancel={() => setShowModal(false)}
            token={user.token}
            isLoading={isLoadingProduct}
          />
        )}

        {deleteConfirmation && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full">
              <div className="flex items-center mb-4 text-red-500">
                <FontAwesomeIcon
                  icon={faExclamationTriangle}
                  className="mr-2 text-xl"
                />
                <h3 className="text-lg font-medium">Confirm Deletion</h3>
              </div>

              <p className="mb-4">
                Are you sure you want to delete{" "}
                <span className="font-semibold">{deleteConfirmation.name}</span>
                ? This action cannot be undone.
              </p>

              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setDeleteConfirmation(null)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Products;
