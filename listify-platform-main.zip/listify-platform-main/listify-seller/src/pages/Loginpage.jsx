import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faArrowLeft,
  faWandMagicSparkles,
} from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import { AuthContext } from "../context/AuthContext";

const LoginPage = () => {
  const { login } = useContext(AuthContext);
  const [currState, setCurrState] = useState("Login");
  const [formData, setFormData] = useState({
    businessName: "",
    contact_number: "",
    contact_email: "",
    password: "",
    confirmPassword: "",
  });
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const handleSwitchState = () => {
    setCurrState(currState === "Register" ? "Login" : "Register");
    setFormData({
      businessName: "",
      contact_number: "",
      contact_email: "",
      password: "",
      confirmPassword: "",
    });
    setError("");
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const generateRandomPassword = () => {
    const length = Math.floor(Math.random() * 5) + 12; // Random length between 12 and 16
    const lower = "abcdefghijklmnopqrstuvwxyz";
    const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const numbers = "0123456789";
    const symbols = "!@#$%^&*()_+[]{}|;:,.<>?";

    const allChars = lower + upper + numbers + symbols;

    let password = "";
    password += lower[Math.floor(Math.random() * lower.length)];
    password += upper[Math.floor(Math.random() * upper.length)];
    password += numbers[Math.floor(Math.random() * numbers.length)];
    password += symbols[Math.floor(Math.random() * symbols.length)];

    for (let i = password.length; i < length; i++) {
      password += allChars[Math.floor(Math.random() * allChars.length)];
    }

    // Shuffling the password in order rto be more random
    password = password
      .split("")
      .sort(() => Math.random() - 0.5)
      .join("");

    setFormData((prev) => ({
      ...prev,
      password: password,
      confirmPassword: password,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const url =
        currState === "Login"
          ? "http://localhost:8080/api/auth/sellers/login"
          : "http://localhost:8080/api/auth/sellers/register";

      const apiData =
        currState === "Login"
          ? {
              email: formData.contact_email, 
              password: formData.password,
            }
          : {
              email: formData.contact_email, 
              password: formData.password,
              business_Name: formData.businessName,
              contact_number: formData.contact_number,
              contact_email: formData.contact_email,
            };

      console.log("Sending data to API:", apiData);

      const response = await axios.post(url, apiData);
      console.log("Login successful, navigating to /home");
      login(response.data, response.data.token);
      navigate("/home");
    } catch (error) {
      console.error("Login error:", error);
      setError(error.response?.data?.message || "An error occurred");
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="relative bg-white border-2 border-cyan-500 rounded-lg p-6 w-[400px] flex flex-col items-center">
        <div className="w-full flex justify-between items-center mb-6">
          {currState === "Register" && (
            <FontAwesomeIcon
              icon={faArrowLeft}
              onClick={handleSwitchState}
              className="text-xl cursor-pointer text-cyan-500 hover:scale-110"
            />
          )}
        </div>

        {error && (
          <div className="w-full mb-4 text-red-500 text-sm text-center">
            {error}
          </div>
        )}

        {currState === "Register" && (
          <>
            <div className="w-full mb-4">
              <label className="w-full text-left mb-1 text-sm font-semibold text-gray-700">
                Business Name
              </label>
              <input
                type="text"
                name="businessName"
                value={formData.businessName}
                onChange={handleChange}
                placeholder="Business Name"
                className="w-full border border-cyan-500 rounded-md p-2"
                required
              />
            </div>
          </>
        )}

        <label className="w-full text-left mb-1 text-sm font-semibold text-gray-700">
          Contact Email
        </label>
        <input
          type="email"
          name="contact_email"
          value={formData.contact_email}
          onChange={handleChange}
          placeholder="Contact Email"
          className="w-full border border-cyan-500 rounded-md p-2 mb-4"
          required
        />

        <label className="w-full text-left mb-1 text-sm font-semibold text-gray-700">
          Password
        </label>
        <div className="relative w-full mb-4">
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Password"
            className="w-full border border-cyan-500 rounded-md p-2 pr-10"
            required
          />
          {currState === "Register" && (
            <FontAwesomeIcon
              icon={faWandMagicSparkles}
              onClick={generateRandomPassword}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-cyan-500 cursor-pointer hover:scale-110"
            />
          )}
        </div>

        {currState === "Register" && (
          <>
            <label className="w-full text-left mb-1 text-sm font-semibold text-gray-700">
              Confirm Password
            </label>
            <input
              type="password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              placeholder="Confirm Password"
              className="w-full border border-cyan-500 rounded-md p-2 mb-4"
              required
            />
          </>
        )}

        <button
          type="submit"
          className="bg-cyan-500 text-white py-2 px-4 rounded-md w-full hover:bg-cyan-600 transition-all font-semibold"
          onClick={handleSubmit}
        >
          {currState === "Login" ? "Login" : "Register"}
        </button>

        <div className="mt-4 text-center">
          {currState === "Login" ? (
            <>
              <span>Don't have an account? </span>
              <button
                type="button"
                onClick={handleSwitchState}
                className="text-cyan-500 underline font-semibold"
              >
                Register
              </button>
            </>
          ) : (
            <>
              <span>Already have an account? </span>
              <button
                type="button"
                onClick={handleSwitchState}
                className="text-cyan-500 underline font-semibold"
              >
                Login
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
