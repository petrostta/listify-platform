import React, { useContext, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import LoginPage from "./pages/Loginpage";
import Products from "./pages/Products";
import { AuthProvider, AuthContext } from "./context/AuthContext";
import PrivateRoute from "./routes/PrivateRoute";
import PublicRoute from "./routes/PublicRoute";
import LoadingSpinner from "./components/shared/LoadingSpinner";
import Orders from "./pages/Orders";
import AccountPage from "./pages/AccountPage";

const App = () => {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<PublicRoute element={LoginPage} />} />
          <Route
            path="/products"
            element={<PrivateRoute element={Products} />}
          />
          <Route
            path="/profile"
            element={<PrivateRoute element={AccountPage} />}
          />
          <Route path="*" element={<CatchAllRoute />} />
          <Route path="/orders" element={<PrivateRoute element={Orders} />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
};

const CatchAllRoute = () => {
  const { user, loading } = React.useContext(AuthContext);

  if (loading) {
    return <LoadingSpinner />;
  }

  return user ? <Navigate to="/products" /> : <Navigate to="/" />;
};

export default App;
