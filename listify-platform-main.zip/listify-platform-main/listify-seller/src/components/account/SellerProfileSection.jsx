import React, { useState, useEffect } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faStore,
  faMapMarkerAlt,
  faPhone,
  faEnvelope,
  faEdit,
  faSpinner,
  faGlobe,
  faFileAlt,
} from "@fortawesome/free-solid-svg-icons";

const SellerProfileSection = ({
  user,
  isEditing,
  setIsEditing,
  refreshUser,
  onSuccess,
  onError,
  loading,
  setLoading,
}) => {
  const [profileData, setProfileData] = useState({
    business_Name: "",
    description: "",
    contact_number: "",
    contact_email: "",
    website: "",
    street: "",
    city: "",
    country: "",
    zipCode: "",
  });

  // Populating thw form data when user data changes
  useEffect(() => {
    if (user) {
      setProfileData({
        business_Name: user.business_Name || "",
        description: user.description || "",
        contact_number: user.contact_number || "",
        contact_email: user.contact_email || "",
        website: user.website || "",
        street: user.businessAddress?.street || "",
        city: user.businessAddress?.city || "",
        country: user.businessAddress?.country || "",
        zipCode: user.businessAddress?.zipCode || "",
      });
    }
  }, [user]);

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setProfileData((prev) => ({ ...prev, [name]: value }));
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.put(
        `http://localhost:8080/api/sellers/${user.uuid}`,
        {
          business_Name: profileData.business_Name,
          description: profileData.description,
          contact_number: profileData.contact_number,
          contact_email: profileData.contact_email,
          website: profileData.website,
          businessAddress: {
            street: profileData.street,
            city: profileData.city,
            country: profileData.country,
            zipCode: profileData.zipCode,
          },
        },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      // Refresh user in context
      refreshUser();
      setIsEditing(false);
      onSuccess("Business profile updated successfully!");
    } catch (error) {
      console.error("Error updating profile:", error);
      onError(error.response?.data?.message || "Failed to update profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      {isEditing ? (
        <form onSubmit={handleProfileSubmit}>
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                <FontAwesomeIcon
                  icon={faStore}
                  className="mr-2 text-cyan-500"
                />
                Business Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Business Name
                  </label>
                  <input
                    type="text"
                    name="business_Name"
                    value={profileData.business_Name}
                    onChange={handleProfileChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    required
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Business Description
                  </label>
                  <textarea
                    name="description"
                    value={profileData.description}
                    onChange={handleProfileChange}
                    rows="3"
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Contact Number
                  </label>
                  <input
                    type="text"
                    name="contact_number"
                    value={profileData.contact_number}
                    onChange={handleProfileChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Contact Email
                  </label>
                  <input
                    type="email"
                    name="contact_email"
                    value={profileData.contact_email}
                    onChange={handleProfileChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Website (Optional)
                  </label>
                  <input
                    type="url"
                    name="website"
                    value={profileData.website}
                    onChange={handleProfileChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    placeholder="https://example.com"
                  />
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                <FontAwesomeIcon
                  icon={faMapMarkerAlt}
                  className="mr-2 text-cyan-500"
                />
                Business Address
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Street Address
                  </label>
                  <input
                    type="text"
                    name="street"
                    value={profileData.street}
                    onChange={handleProfileChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    City
                  </label>
                  <input
                    type="text"
                    name="city"
                    value={profileData.city}
                    onChange={handleProfileChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Country
                  </label>
                  <input
                    type="text"
                    name="country"
                    value={profileData.country}
                    onChange={handleProfileChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Zip Code
                  </label>
                  <input
                    type="text"
                    name="zipCode"
                    value={profileData.zipCode}
                    onChange={handleProfileChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-3 mt-6">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-cyan-500 text-white rounded-md hover:bg-cyan-600 flex items-center"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <FontAwesomeIcon icon={faSpinner} spin className="mr-2" />
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </button>
            </div>
          </div>
        </form>
      ) : (
        <div className="space-y-8">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-gray-800 flex items-center">
                <FontAwesomeIcon
                  icon={faStore}
                  className="mr-2 text-cyan-500"
                />
                Business Information
              </h2>
              <button
                onClick={() => setIsEditing(true)}
                className="text-cyan-500 hover:text-cyan-700 flex items-center"
              >
                <FontAwesomeIcon icon={faEdit} className="mr-1" />
                Edit
              </button>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="text-sm font-medium text-gray-500">
                  Business Name
                </p>
                <p className="mt-1 text-lg font-semibold">
                  {user.business_Name || "Not provided"}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Website</p>
                <p className="mt-1 text-lg flex items-center">
                  <FontAwesomeIcon
                    icon={faGlobe}
                    className="mr-2 text-gray-400"
                  />
                  {user.website ? (
                    <a
                      href={user.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-600 hover:underline"
                    >
                      {user.website}
                    </a>
                  ) : (
                    "Not provided"
                  )}
                </p>
              </div>
              <div className="col-span-2">
                <p className="text-sm font-medium text-gray-500">
                  Business Description
                </p>
                <p className="mt-1">
                  {user.description || "No description provided"}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">
                  Contact Number
                </p>
                <p className="mt-1 flex items-center">
                  <FontAwesomeIcon
                    icon={faPhone}
                    className="mr-2 text-gray-400"
                  />
                  {user.contact_number || "Not provided"}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">
                  Contact Email
                </p>
                <p className="mt-1 flex items-center">
                  <FontAwesomeIcon
                    icon={faEnvelope}
                    className="mr-2 text-gray-400"
                  />
                  {user.contact_email || "Not provided"}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">
                  Seller Since
                </p>
                <p className="mt-1">
                  {new Date(user.createdAt).toLocaleDateString()}
                </p>
              </div>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-gray-800 flex items-center">
                <FontAwesomeIcon
                  icon={faMapMarkerAlt}
                  className="mr-2 text-cyan-500"
                />
                Business Address
              </h2>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              {user.businessAddress &&
              (user.businessAddress.street || user.businessAddress.city) ? (
                <div className="flex items-start">
                  <FontAwesomeIcon
                    icon={faMapMarkerAlt}
                    className="text-gray-400 mr-3 mt-1"
                  />
                  <div>
                    <p className="text-lg">
                      {user.businessAddress.street}
                      <br />
                      {user.businessAddress.city},{" "}
                      {user.businessAddress.zipCode}
                      <br />
                      {user.businessAddress.country}
                    </p>
                  </div>
                </div>
              ) : (
                <p className="text-gray-500 italic">
                  No business address provided
                </p>
              )}
            </div>
          </div>

          <div className="mt-6">
            <button
              onClick={() => setIsEditing(true)}
              className="w-full md:w-auto px-6 py-3 bg-cyan-500 text-white rounded-md hover:bg-cyan-600 flex items-center justify-center"
            >
              <FontAwesomeIcon icon={faEdit} className="mr-2" />
              Edit Business Profile
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SellerProfileSection;
