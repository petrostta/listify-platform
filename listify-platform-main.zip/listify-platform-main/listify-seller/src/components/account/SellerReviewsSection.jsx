import React, { useState, useEffect } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faStar,
  faSpinner,
  faChartBar,
  faComments,
  faBox,
  faUser,
  faCalendarAlt,
  faStore,
  faTrophy,
} from "@fortawesome/free-solid-svg-icons";

const SellerReviewsSection = ({ user }) => {
  const [reviewsData, setReviewsData] = useState({
    reviews: [],
    allReviews: [],
    stats: {
      averageRating: 0,
      totalReviews: 0,
    },
    loading: true,
    error: null,
  });

  const [expandedReviews, setExpandedReviews] = useState(new Set());

  useEffect(() => {
    if (user?.uuid) {
      fetchSellerReviews();
    }
  }, [user]);

  const fetchSellerReviews = async () => {
    try {
      setReviewsData((prev) => ({ ...prev, loading: true, error: null }));

      const response = await axios.get(
        `http://localhost:8080/api/reviews/seller/${user.uuid}?limit=10`
      );

      const reviews = response.data.reviews || [];
      const calculatedStats = calculateStats(reviews);

      setReviewsData({
        reviews,
        allReviews: reviews,
        stats: calculatedStats,
        loading: false,
        error: null,
      });
    } catch (error) {
      console.error("Error fetching seller reviews:", error);
      setReviewsData((prev) => ({
        ...prev,
        loading: false,
        error: "Failed to load reviews",
      }));
    }
  };

  const calculateStats = (reviews) => {
    if (!reviews || reviews.length === 0) {
      return {
        averageRating: 0,
        totalReviews: 0,
      };
    }

    const totalReviews = reviews.length;
    const totalRating = reviews.reduce((sum, review) => {
      const rating = parseFloat(review.rating) || 0;
      return sum + rating;
    }, 0);

    const averageRating = totalReviews > 0 ? totalRating / totalReviews : 0;

    return {
      averageRating: Math.round(averageRating * 10) / 10,
      totalReviews,
    };
  };

  const renderStars = (rating, size = "sm") => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.push(
          <FontAwesomeIcon
            key={i}
            icon={faStar}
            className="text-yellow-400"
            size={size === "xs" ? "xs" : "sm"}
          />
        );
      } else if (i === fullStars && hasHalfStar) {
        stars.push(
          <FontAwesomeIcon
            key={i}
            icon={faStar}
            className="text-yellow-400 opacity-50"
            size={size === "xs" ? "xs" : "sm"}
          />
        );
      } else {
        stars.push(
          <FontAwesomeIcon
            key={i}
            icon={faStar}
            className="text-gray-300"
            size={size === "xs" ? "xs" : "sm"}
          />
        );
      }
    }
    return stars;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return "Yesterday";
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;

    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const getProductImageUrl = (product) => {
    if (!product?.pictures || product.pictures.length === 0) {
      return "/placeholder-product.png";
    }

    const firstPicture = product.pictures[0];

    if (firstPicture.url) {
      if (
        firstPicture.url.startsWith("https://") ||
        firstPicture.url.startsWith("http://")
      ) {
        return firstPicture.url;
      }

      if (firstPicture.url.startsWith("/")) {
        return `https://pub-e2dfc4f311fa40c0b98535194e9c7266.r2.dev${firstPicture.url}`;
      }

      return `https://pub-e2dfc4f311fa40c0b98535194e9c7266.r2.dev/${firstPicture.url}`;
    }

    if (firstPicture.key) {
      if (firstPicture.key.startsWith("products/")) {
        return `https://pub-e2dfc4f311fa40c0b98535194e9c7266.r2.dev/${firstPicture.key}`;
      } else {
        return `https://pub-e2dfc4f311fa40c0b98535194e9c7266.r2.dev/products/${firstPicture.key}`;
      }
    }

    return "/placeholder-product.png";
  };

  const getRatingDistribution = () => {
    const allReviews = reviewsData.allReviews || [];

    if (!allReviews.length) return [];

    const distribution = [0, 0, 0, 0, 0];

    allReviews.forEach((review) => {
      const rating = parseInt(review.rating);
      if (rating >= 1 && rating <= 5) {
        distribution[rating - 1]++;
      }
    });

    return distribution.map((count, index) => ({
      stars: index + 1,
      count,
      percentage:
        reviewsData.stats.totalReviews > 0
          ? (count / reviewsData.stats.totalReviews) * 100
          : 0,
    }));
  };

  const toggleExpanded = (reviewId) => {
    setExpandedReviews((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(reviewId)) {
        newSet.delete(reviewId);
      } else {
        newSet.add(reviewId);
      }
      return newSet;
    });
  };

  const ratingDistribution = getRatingDistribution();

  if (reviewsData.loading) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <FontAwesomeIcon
          icon={faSpinner}
          spin
          size="2x"
          className="text-cyan-500 mb-3"
        />
        <p className="text-gray-600">Loading your reviews...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold flex items-center">
              <FontAwesomeIcon icon={faStore} className="mr-3" />
              Store Performance
            </h2>
            <p className="text-cyan-100 mt-1">
              Your customer feedback and ratings overview
            </p>
          </div>
          <FontAwesomeIcon
            icon={faTrophy}
            className="text-4xl text-yellow-300"
          />
        </div>
      </div>

      {reviewsData.error ? (
        <div className="text-center py-12 bg-red-50 rounded-lg border border-red-200">
          <FontAwesomeIcon
            icon={faBox}
            className="text-red-400 text-4xl mb-4"
          />
          <p className="text-red-600 text-lg">{reviewsData.error}</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl p-6 border border-yellow-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-yellow-800 uppercase tracking-wide">
                    Overall Rating
                  </p>
                  <div className="flex items-center mt-3">
                    <span className="text-4xl font-bold text-yellow-900">
                      {reviewsData.stats.averageRating.toFixed(1)}
                    </span>
                    <div className="flex ml-3 space-x-1">
                      {renderStars(reviewsData.stats.averageRating)}
                    </div>
                  </div>
                  <p className="text-xs text-yellow-700 mt-2">
                    {reviewsData.stats.averageRating >= 4.5
                      ? "Excellent!"
                      : reviewsData.stats.averageRating >= 4
                      ? "Very Good"
                      : reviewsData.stats.averageRating >= 3
                      ? "Good"
                      : "Needs Improvement"}
                  </p>
                </div>
                <div className="bg-yellow-100 rounded-full p-4">
                  <FontAwesomeIcon
                    icon={faStar}
                    className="text-yellow-500 text-2xl"
                  />
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-blue-800 uppercase tracking-wide">
                    Total Reviews
                  </p>
                  <p className="text-4xl font-bold text-blue-900 mt-3">
                    {reviewsData.stats.totalReviews}
                  </p>
                  <p className="text-xs text-blue-700 mt-2">
                    {reviewsData.stats.totalReviews === 0
                      ? "No reviews yet"
                      : reviewsData.stats.totalReviews === 1
                      ? "First review!"
                      : reviewsData.stats.totalReviews < 10
                      ? "Building reputation"
                      : "Great engagement!"}
                  </p>
                </div>
                <div className="bg-blue-100 rounded-full p-4">
                  <FontAwesomeIcon
                    icon={faComments}
                    className="text-blue-500 text-2xl"
                  />
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-gray-50 to-slate-50 rounded-xl p-6 border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-gray-800 uppercase tracking-wide">
                  Rating Breakdown
                </h3>
                <FontAwesomeIcon
                  icon={faChartBar}
                  className="text-gray-400 text-lg"
                />
              </div>
              <div className="space-y-3">
                {ratingDistribution
                  .slice()
                  .reverse()
                  .map((item) => (
                    <div key={item.stars} className="flex items-center">
                      <div className="flex items-center w-8">
                        <span className="text-xs font-medium text-gray-600 mr-1">
                          {item.stars}
                        </span>
                        <FontAwesomeIcon
                          icon={faStar}
                          className="text-yellow-400"
                          size="xs"
                        />
                      </div>
                      <div className="flex-1 bg-gray-200 rounded-full h-2 mx-3">
                        <div
                          className="bg-gradient-to-r from-yellow-400 to-orange-400 h-2 rounded-full transition-all duration-700 ease-out"
                          style={{ width: `${Math.max(item.percentage, 2)}%` }}
                        ></div>
                      </div>
                      <span className="text-xs font-medium text-gray-600 w-6 text-right">
                        {item.count}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="bg-gradient-to-r from-gray-50 to-gray-100 px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-800 flex items-center">
                <FontAwesomeIcon
                  icon={faComments}
                  className="mr-3 text-cyan-500"
                />
                Recent Reviews
                <span className="ml-2 bg-cyan-100 text-cyan-800 text-xs font-medium px-2 py-1 rounded-full">
                  {reviewsData.reviews.length} shown
                </span>
              </h3>
            </div>

            <div className="p-6">
              {reviewsData.reviews.length > 0 ? (
                <div className="space-y-6">
                  {reviewsData.reviews.map((review, index) => {
                    const isExpanded = expandedReviews.has(review.uuid);
                    const shouldTruncate =
                      review.reviewDescription?.length > 150;

                    return (
                      <div
                        key={review.uuid}
                        className={`group relative bg-gray-50 hover:bg-gray-100 rounded-xl p-5 border border-gray-200 transition-all duration-200 ${
                          index === 0 ? "ring-2 ring-cyan-100" : ""
                        }`}
                      >
                        <div className="flex items-start space-x-4">
                          <div className="flex-shrink-0">
                            <img
                              src={getProductImageUrl(review.product)}
                              alt={review.product?.name || "Product"}
                              className="w-16 h-16 object-cover rounded-lg border-2 border-white shadow-sm group-hover:shadow-md transition-shadow"
                              onError={(e) => {
                                e.target.src = "/placeholder-product.png";
                              }}
                            />
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex-1">
                                <h4 className="font-semibold text-gray-900 text-sm line-clamp-1 mb-1">
                                  {review.product?.name || "Product"}
                                </h4>
                                <div className="flex items-center space-x-3">
                                  <div className="flex items-center space-x-1">
                                    {renderStars(review.rating, "xs")}
                                  </div>
                                  <span className="text-sm font-bold text-gray-700">
                                    {review.rating}/5
                                  </span>
                                  <div className="flex items-center text-xs text-gray-500">
                                    <FontAwesomeIcon
                                      icon={faCalendarAlt}
                                      className="mr-1"
                                    />
                                    {formatDate(review.createdAt)}
                                  </div>
                                </div>
                              </div>
                              {index === 0 && (
                                <span className="bg-cyan-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                                  Latest
                                </span>
                              )}
                            </div>

                            <div className="text-sm text-gray-700 leading-relaxed">
                              <p className={isExpanded ? "" : "line-clamp-2"}>
                                {review.reviewDescription}
                              </p>
                              {shouldTruncate && (
                                <button
                                  onClick={() => toggleExpanded(review.uuid)}
                                  className="text-cyan-600 hover:text-cyan-700 font-medium mt-2 text-xs focus:outline-none focus:underline"
                                >
                                  {isExpanded ? "Show less" : "Read more"}
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-16">
                  <div className="bg-gray-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                    <FontAwesomeIcon
                      icon={faBox}
                      className="text-gray-400 text-2xl"
                    />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    No reviews yet
                  </h3>
                  <p className="text-gray-600 max-w-md mx-auto">
                    When customers leave reviews for your products, they'll
                    appear here. Great products and service lead to great
                    reviews!
                  </p>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default SellerReviewsSection;
