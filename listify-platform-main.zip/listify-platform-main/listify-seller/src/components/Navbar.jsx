import React, { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { NavLink } from "react-router-dom";

export default function Navbar() {
  const { logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <div className="fixed left-0 top-0 w-64 border-r-2 border-cyan-500 h-screen p-4 px-16 block text-center justify-center bg-white z-50">
      <NavLink to="/" className="text-cyan-500 text-3xl font-pacifico">
        listify
      </NavLink>
      <div className="flex flex-col mt-8 space-y-4 hover:cursor-pointer">
        <NavLink
          to="/products"
          className="text-gray-500 text-lg font-semibold hover:text-cyan-500"
        >
          Products
        </NavLink>
        <NavLink
          to="/orders"
          className="text-gray-500 text-lg font-semibold hover:text-cyan-500"
        >
          Orders
        </NavLink>
        <NavLink
          to="/profile"
          className="text-gray-500 text-lg font-semibold hover:text-cyan-500"
        >
          Profile
        </NavLink>
        <div
          className="text-gray-500 text-lg font-semibold hover:text-red-500"
          onClick={handleLogout}
        >
          Logout
        </div>
      </div>
    </div>
  );
}
