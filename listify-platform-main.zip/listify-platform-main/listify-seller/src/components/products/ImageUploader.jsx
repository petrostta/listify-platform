import React, { useState } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUpload,
  faTrash,
  faSpinner,
} from "@fortawesome/free-solid-svg-icons";

const ImageUploader = ({
  productId,
  token,
  images = [],
  onChange,
  maxImages = 5,
}) => {
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState(null);

  const handleImageSelect = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    if (images.length + files.length > maxImages) {
      setError(`You can only upload a maximum of ${maxImages} images`);
      return;
    }

    setUploading(true);
    setUploadProgress(0);
    setError(null);

    try {
      // Process each file
      const newImages = [...images];

      for (const file of files) {
        const fileExtension = file.name.split(".").pop();

        let uploadUrlResponse;
        try {
          uploadUrlResponse = await axios.post(
            `http://localhost:8080/api/products/${
              productId || "temp"
            }/upload-url`,
            { fileType: fileExtension },
            { headers: { Authorization: `Bearer ${token}` } }
          );
        } catch (err) {
          console.error("Error getting upload URL:", err);
          const errorMessage =
            err.response?.data?.message || "Failed to get upload URL";
          setError(errorMessage);
          setUploading(false);
          return;
        }

        const { uploadUrl, fileKey, publicUrl } = uploadUrlResponse.data;

        try {
          await axios.put(uploadUrl, file, {
            headers: { "Content-Type": file.type },
            onUploadProgress: (progressEvent) => {
              const percentCompleted = Math.round(
                (progressEvent.loaded * 100) / progressEvent.total
              );
              setUploadProgress(percentCompleted);
            },
          });
        } catch (err) {
          console.error("Error uploading to storage:", err);
          setError("Failed to upload image. Please try again.");
          setUploading(false);
          return;
        }

        newImages.push({
          key: fileKey,
          url: publicUrl,
          altText: file.name,
        });
      }

      onChange(newImages);
    } catch (err) {
      console.error("Image upload error:", err);
      setError("Failed to upload. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveImage = (index) => {
    const newImages = [...images];
    newImages.splice(index, 1);
    onChange(newImages);
  };

  return (
    <div className="mb-4">
      <label className="block text-gray-700 mb-2">Product Images</label>

      <div className="flex flex-wrap gap-4 mb-4">
        {images.map((image, index) => (
          <div key={index} className="relative w-24 h-24 border rounded">
            <img
              src={image.url}
              alt={image.altText || `Product image ${index + 1}`}
              className="w-full h-full object-cover rounded"
            />
            <button
              type="button"
              onClick={() => handleRemoveImage(index)}
              className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center"
            >
              <FontAwesomeIcon icon={faTrash} className="text-xs" />
            </button>
          </div>
        ))}

        {images.length < maxImages && (
          <div className="w-24 h-24 border-2 border-dashed border-gray-300 rounded flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50">
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              multiple
              onChange={handleImageSelect}
              className="hidden"
              id="image-upload"
              disabled={uploading}
            />
            <label
              htmlFor="image-upload"
              className="cursor-pointer flex flex-col items-center justify-center w-full h-full"
            >
              {uploading ? (
                <>
                  <FontAwesomeIcon
                    icon={faSpinner}
                    spin
                    className="text-cyan-500 mb-1"
                  />
                  <span className="text-xs text-center">{uploadProgress}%</span>
                </>
              ) : (
                <>
                  <FontAwesomeIcon
                    icon={faUpload}
                    className="text-cyan-500 mb-1"
                  />
                  <span className="text-xs text-center">Upload</span>
                </>
              )}
            </label>
          </div>
        )}
      </div>

      {error && <div className="text-red-500 text-sm">{error}</div>}

      <div className="text-xs text-gray-500">
        Upload up to {maxImages} images (JPEG, PNG or WebP)
      </div>
    </div>
  );
};

export default ImageUploader;
