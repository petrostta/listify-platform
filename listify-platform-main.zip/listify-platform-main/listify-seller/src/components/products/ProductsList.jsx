import React, { useState, useCallback, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEdit,
  faTrash,
  faSave,
  faTimes,
  faExclamationTriangle,
  faChevronUp,
  faLayerGroup,
  faStar,
  faEye,
  faSpinner,
} from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import ReviewsModal from "./ReviewsModal";

const ProductsList = ({ products, onEdit, onDelete, onStockUpdate }) => {
  const [stockEdits, setStockEdits] = useState({});
  const [editingStock, setEditingStock] = useState({});
  const [confirmStock, setConfirmStock] = useState(null);
  const [expandedVariants, setExpandedVariants] = useState(null);
  const [reviewsData, setReviewsData] = useState({});
  const [loadingReviews, setLoadingReviews] = useState({});
  const [reviewsModal, setReviewsModal] = useState({
    isOpen: false,
    productId: null,
    productName: "",
  });

  // Fetch review data for a product
  const fetchProductReviews = async (productId) => {
    if (reviewsData[productId] || loadingReviews[productId]) {
      return;
    }

    setLoadingReviews((prev) => ({ ...prev, [productId]: true }));

    try {
      const countResponse = await axios.get(
        `http://localhost:8080/api/reviews/product/${productId}/count-simple`
      );

      setReviewsData((prev) => ({
        ...prev,
        [productId]: {
          count: countResponse.data.count || 0,
          averageRating: countResponse.data.averageRating || 0,
        },
      }));
    } catch (error) {
      console.error("Error fetching reviews:", error);
      setReviewsData((prev) => ({
        ...prev,
        [productId]: {
          count: 0,
          averageRating: 0,
        },
      }));
    } finally {
      setLoadingReviews((prev) => ({ ...prev, [productId]: false }));
    }
  };

  // Load review counts for all products on component mount
  useEffect(() => {
    products.forEach((product) => {
      if (!reviewsData[product.uuid] && !loadingReviews[product.uuid]) {
        fetchProductReviews(product.uuid);
      }
    });
  }, [products]);

  const openReviewsModal = (productId, productName) => {
    setReviewsModal({ isOpen: true, productId, productName });
  };

  const closeReviewsModal = () => {
    setReviewsModal({ isOpen: false, productId: null, productName: "" });
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.push(
          <FontAwesomeIcon key={i} icon={faStar} className="text-yellow-400" />
        );
      } else if (i === fullStars && hasHalfStar) {
        stars.push(
          <FontAwesomeIcon
            key={i}
            icon={faStar}
            className="text-yellow-400 opacity-50"
          />
        );
      } else {
        stars.push(
          <FontAwesomeIcon key={i} icon={faStar} className="text-gray-300" />
        );
      }
    }
    return stars;
  };

  if (products.length === 0) {
    return (
      <div className="bg-white p-8 rounded-lg shadow text-center">
        <p className="text-gray-500">No products found</p>
      </div>
    );
  }

  // ...existing stock handling functions...
  const handleStockChange = (productId, value) => {
    const newValue = Math.max(0, parseInt(value) || 0);
    setStockEdits({
      ...stockEdits,
      [productId]: newValue,
    });
  };

  const handleStockEditStart = useCallback((product) => {
    setEditingStock({ [product.uuid]: true });
    setStockEdits({ [product.uuid]: product.stock });
  }, []);

  const handleStockIncrement = (productId, currentValue, amount) => {
    const newValue = Math.max(0, currentValue + amount);
    setStockEdits({
      ...stockEdits,
      [productId]: newValue,
    });
  };

  const handleStockSave = (product) => {
    const newStock = stockEdits[product.uuid];
    if (newStock !== undefined && newStock !== product.stock) {
      setConfirmStock({
        product,
        newStock,
        difference: newStock - product.stock,
      });
    } else {
      handleStockCancel();
    }
  };

  const confirmStockChange = useCallback(() => {
    if (confirmStock) {
      const { product, difference } = confirmStock;

      setConfirmStock(null);
      setEditingStock({});
      setStockEdits({});
      setTimeout(() => {
        onStockUpdate(product, difference);
      }, 0);
    }
  }, [confirmStock, onStockUpdate]);

  const handleStockCancel = useCallback(() => {
    setEditingStock({});
    setStockEdits({});
  }, []);

  const toggleVariants = useCallback(
    (productId) => {
      setExpandedVariants(expandedVariants === productId ? null : productId);
    },
    [expandedVariants]
  );

  return (
    <>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-cyan-500 uppercase tracking-wider">
                Product
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-cyan-500 uppercase tracking-wider">
                Category
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-cyan-500 uppercase tracking-wider">
                Price
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-cyan-500 uppercase tracking-wider">
                Stock
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-cyan-500 uppercase tracking-wider">
                Reviews
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-cyan-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {products.map((product) => (
              <React.Fragment key={product.uuid}>
                <tr className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 flex-shrink-0">
                        {product.pictures && product.pictures.length > 0 ? (
                          <img
                            className="h-10 w-10 rounded-full object-cover"
                            src={product.pictures[0].url}
                            alt={product.name}
                          />
                        ) : (
                          <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500">
                            No img
                          </div>
                        )}
                      </div>
                      <div className="ml-4">
                        <div className="flex items-center text-sm font-medium text-gray-900">
                          {product.name}
                          {product.variants && product.variants.length > 0 && (
                            <span className="ml-2 px-2 py-0.5 text-xs rounded-full bg-cyan-100 text-cyan-800">
                              {product.variants.length} variant
                              {product.variants.length !== 1 ? "s" : ""}
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-500 truncate max-w-xs">
                          {product.description}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-cyan-100 text-cyan-800">
                      {product.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${product.original_price?.toFixed(2)}
                    {product.discount > 0 && (
                      <span className="ml-2 text-xs text-red-500">
                        -{product.discount}%
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    {editingStock[product.uuid] ? (
                      <div className="flex items-center justify-center space-x-2">
                        <button
                          onClick={() =>
                            handleStockIncrement(
                              product.uuid,
                              stockEdits[product.uuid],
                              -1
                            )
                          }
                          className="text-gray-500 hover:text-gray-700 px-2 py-1 rounded border border-gray-300"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          min="0"
                          value={stockEdits[product.uuid]}
                          onChange={(e) =>
                            handleStockChange(product.uuid, e.target.value)
                          }
                          className="w-16 px-2 py-1 border border-gray-300 rounded text-center
                                    focus:outline-none focus:ring-1 focus:ring-cyan-500 focus:border-cyan-500"
                        />
                        <button
                          onClick={() =>
                            handleStockIncrement(
                              product.uuid,
                              stockEdits[product.uuid],
                              1
                            )
                          }
                          className="text-gray-500 hover:text-gray-700 px-2 py-1 rounded border border-gray-300"
                        >
                          +
                        </button>
                        <button
                          onClick={() => handleStockSave(product)}
                          className="text-green-600 hover:text-green-800 px-2 py-1 rounded border border-green-200 bg-green-50"
                          title="Save"
                        >
                          <FontAwesomeIcon icon={faSave} />
                        </button>
                        <button
                          onClick={handleStockCancel}
                          className="text-gray-500 hover:text-gray-700 px-2 py-1 rounded border border-gray-200 bg-gray-50"
                          title="Cancel"
                        >
                          <FontAwesomeIcon icon={faTimes} />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center">
                        <span className="text-sm font-medium text-gray-900 mr-3">
                          {product.stock}
                        </span>
                        <button
                          onClick={() => handleStockEditStart(product)}
                          className="text-cyan-600 hover:text-cyan-800 p-1 rounded hover:bg-gray-100"
                          title="Edit stock"
                        >
                          <FontAwesomeIcon icon={faEdit} />
                        </button>
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <div className="flex flex-col items-center space-y-1">
                      {loadingReviews[product.uuid] ? (
                        <FontAwesomeIcon
                          icon={faSpinner}
                          spin
                          className="text-gray-400"
                        />
                      ) : (
                        <>
                          <div className="flex items-center space-x-1">
                            {reviewsData[product.uuid]?.averageRating > 0 ? (
                              <>
                                <div className="flex space-x-0.5">
                                  {renderStars(
                                    reviewsData[product.uuid].averageRating
                                  )}
                                </div>
                                <span className="text-sm font-medium text-gray-900">
                                  {reviewsData[
                                    product.uuid
                                  ].averageRating.toFixed(1)}
                                </span>
                              </>
                            ) : (
                              <span className="text-sm text-gray-500">
                                No reviews
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-gray-500">
                            {reviewsData[product.uuid]?.count || 0} review
                            {(reviewsData[product.uuid]?.count || 0) !== 1
                              ? "s"
                              : ""}
                          </div>
                          {(reviewsData[product.uuid]?.count || 0) > 0 && (
                            <button
                              onClick={() =>
                                openReviewsModal(product.uuid, product.name)
                              }
                              className="text-xs text-cyan-600 hover:text-cyan-800 flex items-center"
                            >
                              <FontAwesomeIcon icon={faEye} className="mr-1" />
                              View Reviews
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button
                      onClick={() => onEdit(product)}
                      className="text-cyan-600 hover:text-cyan-900 mr-3 p-1 rounded hover:bg-gray-100"
                      title="Edit product"
                    >
                      <FontAwesomeIcon icon={faEdit} />
                    </button>
                    {product.variants && product.variants.length > 0 && (
                      <button
                        onClick={() => toggleVariants(product.uuid)}
                        className="text-cyan-600 hover:text-cyan-900 mr-3 p-1 rounded hover:bg-gray-100"
                        title={
                          expandedVariants === product.uuid
                            ? "Hide variants"
                            : "Show variants"
                        }
                      >
                        <FontAwesomeIcon
                          icon={
                            expandedVariants === product.uuid
                              ? faChevronUp
                              : faLayerGroup
                          }
                        />
                      </button>
                    )}
                    <button
                      onClick={() => onDelete(product.uuid)}
                      className="text-red-600 hover:text-red-900 p-1 rounded hover:bg-gray-100"
                      title="Delete product"
                    >
                      <FontAwesomeIcon icon={faTrash} />
                    </button>
                  </td>
                </tr>

                {/* Variants Section - Keep this for variants */}
                {expandedVariants === product.uuid &&
                  product.variants &&
                  product.variants.length > 0 && (
                    <tr className="bg-gray-50">
                      <td colSpan="6" className="px-6 py-4">
                        <h3 className="text-sm font-medium text-gray-700 mb-2">
                          Product Variants
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                          {product.variants.map((variant) => (
                            <div
                              key={variant.uuid}
                              className="bg-white p-3 rounded border"
                            >
                              <div className="flex items-start">
                                <div className="h-10 w-10 flex-shrink-0 mr-3">
                                  {variant.pictures &&
                                  variant.pictures.length > 0 ? (
                                    <img
                                      className="h-10 w-10 rounded-full object-cover"
                                      src={variant.pictures[0].url}
                                      alt=""
                                    />
                                  ) : (
                                    <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 text-xs">
                                      No img
                                    </div>
                                  )}
                                </div>
                                <div>
                                  <div className="text-xs font-medium text-gray-900 mb-1">
                                    {variant.attributes &&
                                    variant.attributes.length > 0
                                      ? variant.attributes
                                          .map(
                                            (attr) =>
                                              `${attr.key}: ${attr.value}`
                                          )
                                          .join(", ")
                                      : "Default Variant"}
                                  </div>
                                  <div className="text-xs text-gray-600 mb-1">
                                    ${variant.original_price?.toFixed(2)}
                                    {variant.discount > 0 && (
                                      <span className="ml-1 text-xs text-red-500">
                                        -{variant.discount}%
                                      </span>
                                    )}
                                  </div>
                                  <div className="text-xs text-gray-600">
                                    Stock: {variant.stock}
                                  </div>
                                </div>
                              </div>
                              {variant.description && (
                                <div className="mt-2 text-xs text-gray-500 border-t pt-2">
                                  {variant.description}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </td>
                    </tr>
                  )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      {/* Reviews Modal */}
      <ReviewsModal
        isOpen={reviewsModal.isOpen}
        onClose={closeReviewsModal}
        productId={reviewsModal.productId}
        productName={reviewsModal.productName}
      />

      {/* Stock Confirmation Modal */}
      {confirmStock && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <div className="flex items-center mb-4 text-amber-500">
              <FontAwesomeIcon
                icon={faExclamationTriangle}
                className="mr-2 text-xl"
              />
              <h3 className="text-lg font-medium">Confirm Stock Update</h3>
            </div>

            <p className="mb-4">
              Are you sure you want to change the stock for{" "}
              <span className="font-semibold">{confirmStock.product.name}</span>{" "}
              from{" "}
              <span className="font-semibold">
                {confirmStock.product.stock}
              </span>{" "}
              to <span className="font-semibold">{confirmStock.newStock}</span>?
            </p>

            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setConfirmStock(null)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={confirmStockChange}
                className="px-4 py-2 bg-cyan-500 text-white rounded-md hover:bg-cyan-600"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ProductsList;
