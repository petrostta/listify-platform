import React from "react";

const VariantBadge = ({ count }) => {
  if (!count || count === 0) return null;

  return (
    <span className="ml-2 px-2 py-0.5 text-xs rounded-full bg-cyan-100 text-cyan-800">
      {count} variant{count !== 1 ? "s" : ""}
    </span>
  );
};

export default VariantBadge;
