import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faTimes,
  faStar,
  faSpinner,
  faChevronLeft,
  faChevronRight,
} from "@fortawesome/free-solid-svg-icons";
import axios from "axios";

const ReviewsModal = ({ isOpen, onClose, productId, productName }) => {
  const [reviewsData, setReviewsData] = useState({
    reviews: [],
    averageRating: 0,
    totalReviews: 0,
    loading: true,
  });
  const [currentPage, setCurrentPage] = useState(1);
  const reviewsPerPage = 10;

  useEffect(() => {
    if (isOpen && productId) {
      fetchReviews(1);
    }
  }, [isOpen, productId]);

  const fetchReviews = async (page = 1) => {
    setReviewsData((prev) => ({ ...prev, loading: true }));

    try {
      const countResponse = await axios.get(
        `http://localhost:8080/api/reviews/product/${productId}/count-simple`
      );

      const reviewsResponse = await axios.get(
        `http://localhost:8080/api/reviews/product/${productId}?page=${page}&limit=${reviewsPerPage}`
      );

      setReviewsData({
        reviews: reviewsResponse.data.reviews || [],
        averageRating: countResponse.data.averageRating || 0,
        totalReviews: countResponse.data.count || 0,
        loading: false,
      });
      setCurrentPage(page);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      setReviewsData({
        reviews: [],
        averageRating: 0,
        totalReviews: 0,
        loading: false,
      });
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.push(
          <FontAwesomeIcon key={i} icon={faStar} className="text-yellow-400" />
        );
      } else if (i === fullStars && hasHalfStar) {
        stars.push(
          <FontAwesomeIcon
            key={i}
            icon={faStar}
            className="text-yellow-400 opacity-50"
          />
        );
      } else {
        stars.push(
          <FontAwesomeIcon key={i} icon={faStar} className="text-gray-300" />
        );
      }
    }
    return stars;
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const totalPages = Math.ceil(reviewsData.totalReviews / reviewsPerPage);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">
              Customer Reviews
            </h2>
            <p className="text-sm text-gray-600 mt-1">{productName}</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 p-2"
          >
            <FontAwesomeIcon icon={faTimes} size="lg" />
          </button>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-200px)]">
          {reviewsData.loading ? (
            <div className="flex items-center justify-center py-12">
              <FontAwesomeIcon
                icon={faSpinner}
                spin
                size="2x"
                className="text-cyan-500"
              />
            </div>
          ) : (
            <>
              <div className="p-6 bg-gray-50 border-b">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <div className="flex space-x-0.5">
                        {renderStars(reviewsData.averageRating)}
                      </div>
                      <span className="text-2xl font-bold text-gray-900">
                        {reviewsData.averageRating.toFixed(1)}
                      </span>
                      <span className="text-gray-600">out of 5</span>
                    </div>
                    <div className="text-gray-600">
                      Based on {reviewsData.totalReviews} review
                      {reviewsData.totalReviews !== 1 ? "s" : ""}
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6">
                {reviewsData.reviews.length > 0 ? (
                  <div className="space-y-6">
                    {reviewsData.reviews.map((review) => (
                      <div
                        key={review.uuid}
                        className="border-b border-gray-200 pb-6 last:border-b-0"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <div className="flex space-x-0.5">
                              {renderStars(review.rating)}
                            </div>
                            <span className="font-medium text-gray-900">
                              {review.rating}/5
                            </span>
                          </div>
                          <span className="text-sm text-gray-500">
                            {formatDate(review.createdAt)}
                          </span>
                        </div>
                        <p className="text-gray-700 leading-relaxed">
                          {review.reviewDescription}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="text-gray-400 mb-4">
                      <FontAwesomeIcon icon={faStar} size="3x" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      No reviews yet
                    </h3>
                    <p className="text-gray-600">
                      This product hasn't received any reviews from customers
                      yet.
                    </p>
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        {totalPages > 1 && !reviewsData.loading && (
          <div className="flex items-center justify-between px-6 py-4 border-t bg-gray-50">
            <div className="text-sm text-gray-600">
              Page {currentPage} of {totalPages}
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => fetchReviews(currentPage - 1)}
                disabled={currentPage === 1}
                className={`px-3 py-1 rounded ${
                  currentPage === 1
                    ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                    : "bg-cyan-500 text-white hover:bg-cyan-600"
                }`}
              >
                <FontAwesomeIcon icon={faChevronLeft} />
              </button>
              <button
                onClick={() => fetchReviews(currentPage + 1)}
                disabled={currentPage === totalPages}
                className={`px-3 py-1 rounded ${
                  currentPage === totalPages
                    ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                    : "bg-cyan-500 text-white hover:bg-cyan-600"
                }`}
              >
                <FontAwesomeIcon icon={faChevronRight} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReviewsModal;
