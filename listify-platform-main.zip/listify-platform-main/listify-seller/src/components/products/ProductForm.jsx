import React, { useState, useEffect } from "react";
import { v4 as uuidv4 } from "uuid";
import ImageUploader from "./ImageUploader";
import AttributesEditor from "./AttributesEditor";
import VariantEditor from "./VariantEditor";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTimes, faInfoCircle } from "@fortawesome/free-solid-svg-icons";

const ProductForm = ({ product, onSubmit, onCancel, token }) => {
  const productId = product?.uuid || "temp";

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    category: "",
    original_price: 0,
    discount: 0,
    stock: 0,
    isAvailable: true,
    pictures: [],
    attributes: [],
    variantAttributes: [],
    variants: [],
  });
  const [errors, setErrors] = useState({});
  const [activeTab, setActiveTab] = useState("basic");

  const categories = [
    "Electronics",
    "Fashion",
    "Home & Garden",
    "Sports",
    "Books",
    "Toys",
    "Health & Beauty",
    "Automotive",
  ];

  // Initializing the form with product data if editing
  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name || "",
        description: product.description || "",
        category: product.category || "",
        original_price: product.original_price || 0,
        discount: product.discount || 0,
        stock: product.stock || 0,
        isAvailable: product.isAvailable !== false,
        pictures: product.pictures || [],
        attributes: product.attributes || [],
        variants: product.variants || [],
      });
    }
  }, [product]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]:
        type === "checkbox"
          ? checked
          : type === "number"
          ? parseFloat(value) || 0
          : value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const handleImagesChange = (newImages) => {
    setFormData((prev) => ({
      ...prev,
      pictures: newImages,
    }));

    if (errors.pictures) {
      setErrors((prev) => ({ ...prev, pictures: null }));
    }
  };

  const handleAttributesChange = (newAttributes) => {
    setFormData((prev) => ({
      ...prev,
      attributes: newAttributes,
    }));
  };

  const handleVariantsChange = (newVariants) => {
    setFormData((prev) => ({
      ...prev,
      variants: newVariants,
    }));
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
    }

    if (!formData.description.trim()) {
      newErrors.description = "Description is required";
    }

    if (!formData.category) {
      newErrors.category = "Category is required";
    }

    if (formData.original_price <= 0) {
      newErrors.original_price = "Price must be greater than 0";
    }

    if (formData.stock < 0) {
      newErrors.stock = "Stock cannot be negative";
    }

    if (formData.discount < 0 || formData.discount > 100) {
      newErrors.discount = "Discount must be between 0 and 100";
    }

    if (formData.pictures.length === 0) {
      newErrors.pictures = "At least one image is required";
    }

    // Validate variants if they aexist
    if (formData.variants.length > 0) {
      const variantErrors = [];
      formData.variants.forEach((variant, index) => {
        const vErrors = {};
        if (variant.original_price <= 0) {
          vErrors.price = "Variant price must be greater than 0";
        }
        if (variant.stock < 0) {
          vErrors.stock = "Variant stock cannot be negative";
        }
        if (variant.attributes.length === 0) {
          vErrors.attributes = "Variant must have at least one attribute";
        }
        if (Object.keys(vErrors).length > 0) {
          variantErrors[index] = vErrors;
        }
      });
      if (Object.keys(variantErrors).length > 0) {
        newErrors.variants = variantErrors;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    onSubmit(formData, !product);
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
      <div className="bg-white rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">
            {product ? "Edit Product" : "Add New Product"}
          </h2>
          <button
            type="button"
            onClick={onCancel}
            className="text-gray-500 hover:text-gray-700"
          >
            <FontAwesomeIcon icon={faTimes} />
          </button>
        </div>

        <div className="mb-6 border-b">
          <nav className="flex space-x-4">
            <button
              type="button"
              onClick={() => setActiveTab("basic")}
              className={`py-2 px-4 ${
                activeTab === "basic"
                  ? "border-b-2 border-cyan-500 text-cyan-600 font-medium"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              Basic Info
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("images")}
              className={`py-2 px-4 ${
                activeTab === "images"
                  ? "border-b-2 border-cyan-500 text-cyan-600 font-medium"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              Images
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("attributes")}
              className={`py-2 px-4 ${
                activeTab === "attributes"
                  ? "border-b-2 border-cyan-500 text-cyan-600 font-medium"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              Attributes
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("variants")}
              className={`py-2 px-4 ${
                activeTab === "variants"
                  ? "border-b-2 border-cyan-500 text-cyan-600 font-medium"
                  : "text-gray-500 hover:text-gray-700"
              } flex items-center`}
            >
              Variants
              {formData.variants.length > 0 && (
                <span className="ml-2 bg-cyan-100 text-cyan-800 text-xs rounded-full px-2 py-1">
                  {formData.variants.length}
                </span>
              )}
            </button>
          </nav>
        </div>

        <form onSubmit={handleSubmit}>
          {activeTab === "basic" && (
            <div className="mb-6">
              <div className="mb-4">
                <label className="block text-gray-700 mb-2">
                  Product Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className={`w-full p-2 border ${
                    errors.name ? "border-red-500" : "border-gray-300"
                  } rounded`}
                />
                {errors.name && (
                  <div className="text-red-500 text-sm mt-1">{errors.name}</div>
                )}
              </div>

              <div className="mb-4">
                <label className="block text-gray-700 mb-2">
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                  className={`w-full p-2 border ${
                    errors.category ? "border-red-500" : "border-gray-300"
                  } rounded`}
                >
                  <option value="">Select a category</option>
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
                {errors.category && (
                  <div className="text-red-500 text-sm mt-1">
                    {errors.category}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-3 gap-4 mb-4">
                <div>
                  <label className="block text-gray-700 mb-2">
                    Price ($) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    name="original_price"
                    value={formData.original_price}
                    onChange={handleChange}
                    min="0"
                    step="0.01"
                    className={`w-full p-2 border ${
                      errors.original_price
                        ? "border-red-500"
                        : "border-gray-300"
                    } rounded`}
                  />
                  {errors.original_price && (
                    <div className="text-red-500 text-sm mt-1">
                      {errors.original_price}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">
                    Discount (%)
                  </label>
                  <input
                    type="number"
                    name="discount"
                    value={formData.discount}
                    onChange={handleChange}
                    min="0"
                    max="100"
                    className={`w-full p-2 border ${
                      errors.discount ? "border-red-500" : "border-gray-300"
                    } rounded`}
                  />
                  {errors.discount && (
                    <div className="text-red-500 text-sm mt-1">
                      {errors.discount}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">
                    Stock <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    name="stock"
                    value={formData.stock}
                    onChange={handleChange}
                    min="0"
                    className={`w-full p-2 border ${
                      errors.stock ? "border-red-500" : "border-gray-300"
                    } rounded`}
                  />
                  {errors.stock && (
                    <div className="text-red-500 text-sm mt-1">
                      {errors.stock}
                    </div>
                  )}
                </div>
              </div>

              <div className="mb-4">
                <label className="flex items-center text-gray-700">
                  <input
                    type="checkbox"
                    name="isAvailable"
                    checked={formData.isAvailable}
                    onChange={handleChange}
                    className="mr-2"
                  />
                  Product is available for sale
                </label>
              </div>

              <div className="mb-4">
                <label className="block text-gray-700 mb-2">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows="4"
                  className={`w-full p-2 border ${
                    errors.description ? "border-red-500" : "border-gray-300"
                  } rounded`}
                ></textarea>
                {errors.description && (
                  <div className="text-red-500 text-sm mt-1">
                    {errors.description}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === "images" && (
            <div className="mb-6">
              <div className="flex items-center mb-3">
                <h3 className="text-lg font-medium">Product Images</h3>
                <div className="ml-2 text-sm text-gray-500 flex items-center">
                  <FontAwesomeIcon icon={faInfoCircle} className="mr-1" />
                  Main product images (not variant-specific)
                </div>
              </div>
              <ImageUploader
                productId={productId}
                token={token}
                images={formData.pictures}
                onChange={handleImagesChange}
              />
              {errors.pictures && (
                <div className="text-red-500 text-sm">{errors.pictures}</div>
              )}
            </div>
          )}

          {activeTab === "attributes" && (
            <div className="mb-6">
              <div className="flex items-center mb-3">
                <h3 className="text-lg font-medium">Product Attributes</h3>
                <div className="ml-2 text-sm text-gray-500 flex items-center">
                  <FontAwesomeIcon icon={faInfoCircle} className="mr-1" />
                  Common attributes for all variants
                </div>
              </div>
              <AttributesEditor
                attributes={formData.attributes}
                onChange={handleAttributesChange}
              />
            </div>
          )}

          {activeTab === "variants" && (
            <div className="mb-6">
              <VariantEditor
                variants={formData.variants}
                onChange={(variants) => setFormData({ ...formData, variants })}
                productId={productId}
                token={token}
                productAttributes={formData.attributes}
                variantAttributes={formData.variantAttributes} // Make sure this is passed
                onVariantAttributesChange={(variantAttributes) =>
                  setFormData({ ...formData, variantAttributes })
                }
              />
              {errors.variants && (
                <div className="text-red-500 text-sm mt-2">
                  Please fix errors in your variants
                </div>
              )}
            </div>
          )}

          <div className="flex justify-end space-x-3 mt-6 pt-4 border-t">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded hover:bg-gray-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-cyan-500 text-white rounded hover:bg-cyan-600"
            >
              {product ? "Update Product" : "Create Product"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProductForm;
