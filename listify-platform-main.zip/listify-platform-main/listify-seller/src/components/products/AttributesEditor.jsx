import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus, faTrash } from "@fortawesome/free-solid-svg-icons";

const AttributesEditor = ({ attributes = [], onChange }) => {
  const [newKey, setNewKey] = useState("");
  const [newValue, setNewValue] = useState("");
  const [error, setError] = useState("");

  const handleAddAttribute = () => {
    if (!newKey.trim()) {
      setError("Attribute name is required");
      return;
    }

    if (!newValue.trim()) {
      setError("Attribute value is required");
      return;
    }

    if (
      attributes.some(
        (attr) =>
          attr.key.toLowerCase() === newKey.toLowerCase() &&
          attr.value.toLowerCase() === newValue.toLowerCase()
      )
    ) {
      setError("This exact attribute already exists");
      return;
    }

    const updatedAttributes = [
      ...attributes,
      { key: newKey.trim(), value: newValue.trim() },
    ];

    onChange(updatedAttributes);
    setNewKey("");
    setNewValue("");
    setError("");
  };

  const handleRemoveAttribute = (index) => {
    const updatedAttributes = [...attributes];
    updatedAttributes.splice(index, 1);
    onChange(updatedAttributes);
  };

  return (
    <div>
      {attributes.length > 0 && (
        <div className="mb-4">
          <div className="grid grid-cols-[1fr,1fr,auto] gap-2 mb-2 font-medium">
            <div>Name</div>
            <div>Value</div>
            <div></div>
          </div>

          {attributes.map((attr, index) => (
            <div
              key={index}
              className="grid grid-cols-[1fr,1fr,auto] gap-2 mb-2 items-center"
            >
              <div className="p-2 bg-gray-50 rounded border border-gray-200">
                {attr.key}
              </div>
              <div className="p-2 bg-gray-50 rounded border border-gray-200">
                {attr.value}
              </div>
              <button
                type="button"
                onClick={() => handleRemoveAttribute(index)}
                className="text-red-500 hover:text-red-700"
              >
                <FontAwesomeIcon icon={faTrash} />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-cols-[1fr,1fr,auto] gap-2 items-end">
        <div>
          <input
            type="text"
            value={newKey}
            onChange={(e) => setNewKey(e.target.value)}
            placeholder="Attribute name"
            className="w-full p-2 border border-gray-300 rounded"
          />
        </div>
        <div>
          <input
            type="text"
            value={newValue}
            onChange={(e) => setNewValue(e.target.value)}
            placeholder="Attribute value"
            className="w-full p-2 border border-gray-300 rounded"
          />
        </div>
        <button
          type="button"
          onClick={handleAddAttribute}
          className="p-2 bg-cyan-500 text-white rounded hover:bg-cyan-600"
        >
          <FontAwesomeIcon icon={faPlus} />
        </button>
      </div>

      {error && <div className="text-red-500 text-sm mt-1">{error}</div>}

      <div className="text-xs text-gray-500 mt-2">
        Add attributes like color, size, material, etc. You can add multiple
        values for the same attribute type.
      </div>
    </div>
  );
};

export default AttributesEditor;
