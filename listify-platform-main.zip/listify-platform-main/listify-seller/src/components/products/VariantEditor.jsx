import React, { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faPlus,
  faTrash,
  faChevronDown,
  faChevronUp,
  faInfoCircle,
} from "@fortawesome/free-solid-svg-icons";
import ImageUploader from "./ImageUploader";
import AttributesEditor from "./AttributesEditor";

const VariantEditor = ({
  variants = [],
  onChange,
  productId,
  token,
  productAttributes = [],
  variantAttributes = [],
  onVariantAttributesChange = () => {},
}) => {
  const [expandedVariant, setExpandedVariant] = useState(null);

  const addVariant = () => {
    const newVariant = {
      uuid: uuidv4(),
      original_price: 0,
      discount: 0,
      description: "",
      stock: 0,
      pictures: [],
      attributes: [],
    };
    onChange([...variants, newVariant]);
    setExpandedVariant(newVariant.uuid);
  };

  const updateVariant = (index, field, value) => {
    const updatedVariants = [...variants];
    updatedVariants[index] = {
      ...updatedVariants[index],
      [field]: value,
    };
    onChange(updatedVariants);
  };

  const removeVariant = (index) => {
    const updatedVariants = [...variants];
    updatedVariants.splice(index, 1);
    onChange(updatedVariants);
  };

  const toggleVariant = (uuid) => {
    setExpandedVariant(expandedVariant === uuid ? null : uuid);
  };

  const toggleVariantAttribute = (attributeKey) => {
    if (variantAttributes.includes(attributeKey)) {
      onVariantAttributesChange(
        variantAttributes.filter((key) => key !== attributeKey)
      );
    } else {
      onVariantAttributesChange([...variantAttributes, attributeKey]);
    }
  };

  const getAllAttributeKeys = () => {
    const keys = new Set();

    (productAttributes || []).forEach((attr) => keys.add(attr.key));

    variants.forEach((variant) => {
      (variant.attributes || []).forEach((attr) => keys.add(attr.key));
    });

    return Array.from(keys);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mb-6">
        <div className="flex items-center mb-3">
          <h3 className="text-lg font-medium">Variant Selectors</h3>
          <div className="ml-2 text-sm text-gray-500 flex items-center">
            <FontAwesomeIcon icon={faInfoCircle} className="mr-1" />
            <span>
              Choose which attributes customers will use to select variants
            </span>
          </div>
        </div>

        <p className="text-sm text-gray-600 mb-3">
          Select attributes that will appear in the variant selector on the
          product page. For example, choose "Color" and "Size" to let customers
          select products by these attributes.
        </p>

        <div className="space-y-2">
          {getAllAttributeKeys().map((key) => (
            <div key={key} className="flex items-center">
              <input
                type="checkbox"
                id={`variant-attr-${key}`}
                checked={variantAttributes.includes(key)}
                onChange={() => toggleVariantAttribute(key)}
                className="h-4 w-4 text-cyan-600 focus:ring-cyan-500 rounded"
              />
              <label
                htmlFor={`variant-attr-${key}`}
                className="ml-2 text-gray-700"
              >
                {key.charAt(0).toUpperCase() + key.slice(1)}
              </label>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-medium">Product Variants</h3>
          <button
            type="button"
            onClick={addVariant}
            className="px-3 py-1 bg-cyan-500 text-white rounded hover:bg-cyan-600 text-sm flex items-center"
          >
            <FontAwesomeIcon icon={faPlus} className="mr-2" />
            Add Variant
          </button>
        </div>

        {variants.length === 0 ? (
          <div className="text-gray-500 text-sm italic">
            No variants added. Add variants for products with different options
            like size, color, etc.
          </div>
        ) : (
          <div className="space-y-4">
            {variants.map((variant, index) => (
              <div
                key={variant.uuid}
                className="border rounded-lg overflow-hidden"
              >
                <div
                  className="flex justify-between items-center p-3 bg-gray-50 cursor-pointer"
                  onClick={() => toggleVariant(variant.uuid)}
                >
                  <div className="font-medium">
                    {variant.attributes && variant.attributes.length > 0
                      ? variant.attributes
                          .map((attr) => `${attr.key}: ${attr.value}`)
                          .join(", ")
                      : `Variant #${index + 1}`}
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="text-sm text-gray-500">
                      ${variant.original_price} · Stock: {variant.stock}
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeVariant(index);
                      }}
                      className="text-red-600 hover:text-red-800"
                    >
                      <FontAwesomeIcon icon={faTrash} />
                    </button>
                    <FontAwesomeIcon
                      icon={
                        expandedVariant === variant.uuid
                          ? faChevronUp
                          : faChevronDown
                      }
                      className="text-gray-500"
                    />
                  </div>
                </div>

                {expandedVariant === variant.uuid && (
                  <div className="p-4 border-t">
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div>
                        <label className="block text-gray-700 mb-2">
                          Price ($) <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="number"
                          value={variant.original_price}
                          onChange={(e) =>
                            updateVariant(
                              index,
                              "original_price",
                              parseFloat(e.target.value) || 0
                            )
                          }
                          min="0"
                          step="0.01"
                          className="w-full p-2 border border-gray-300 rounded"
                        />
                      </div>

                      <div>
                        <label className="block text-gray-700 mb-2">
                          Discount (%)
                        </label>
                        <input
                          type="number"
                          value={variant.discount}
                          onChange={(e) =>
                            updateVariant(
                              index,
                              "discount",
                              Math.min(
                                100,
                                Math.max(0, parseInt(e.target.value) || 0)
                              )
                            )
                          }
                          min="0"
                          max="100"
                          className="w-full p-2 border border-gray-300 rounded"
                        />
                      </div>

                      <div>
                        <label className="block text-gray-700 mb-2">
                          Stock <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="number"
                          value={variant.stock}
                          onChange={(e) =>
                            updateVariant(
                              index,
                              "stock",
                              parseInt(e.target.value) || 0
                            )
                          }
                          min="0"
                          className="w-full p-2 border border-gray-300 rounded"
                        />
                      </div>
                    </div>

                    <div className="mb-4">
                      <label className="block text-gray-700 mb-2">
                        Description
                      </label>
                      <textarea
                        value={variant.description || ""}
                        onChange={(e) =>
                          updateVariant(index, "description", e.target.value)
                        }
                        rows="2"
                        className="w-full p-2 border border-gray-300 rounded"
                      ></textarea>
                    </div>

                    <div className="mb-4">
                      <label className="block text-gray-700 mb-2">
                        Variant Attributes
                      </label>
                      <AttributesEditor
                        attributes={variant.attributes || []}
                        onChange={(newAttributes) =>
                          updateVariant(index, "attributes", newAttributes)
                        }
                      />

                      {variantAttributes && variantAttributes.length > 0 && (
                        <div className="mt-2 p-2 bg-cyan-50 border border-cyan-100 rounded-md">
                          <div className="text-sm text-cyan-800 font-medium mb-1">
                            Selected Variant Attributes:
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {variantAttributes.map((attrKey) => (
                              <span
                                key={attrKey}
                                className="px-2 py-1 bg-cyan-100 text-cyan-700 rounded-full text-xs"
                              >
                                {attrKey}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="text-xs text-gray-500 mt-1">
                        Add attributes like "Color: Red", "Size: XL", etc.
                      </div>
                    </div>

                    <div className="mb-4">
                      <label className="block text-gray-700 mb-2">
                        Variant Images
                      </label>
                      <ImageUploader
                        productId={productId}
                        token={token}
                        images={variant.pictures || []}
                        onChange={(newImages) =>
                          updateVariant(index, "pictures", newImages)
                        }
                        maxImages={3}
                      />
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default VariantEditor;
