import amqlib from "amqplib";
import paymentModel from "../models/payment.js";
import { publishPaymentEvent } from "./eventPublisher.js";
import StripeGateway from "../gateways/StripeGateway.js";

let channel;
let connection;

export const connectEventListeners = async (retries = 5, delay = 2000) => {
  let attempt = 0;
  while (attempt < retries) {
    try {
      console.log(`Connecting to RabbitMQ listeners (attempt ${attempt + 1}/${retries})...`);

      connection = await amqlib.connect(process.env.RABBITMQ_URL);

      connection.on("error", (err) => {
        console.error("RabbitMQ listener connection error:", err.message);
      });

      connection.on("close", () => {
        console.warn("RabbitMQ listener connection closed unexpectedly, reconnecting...");
        setTimeout(() => connectEventListeners(), 5000);
      });

      channel = await connection.createChannel();

      await setupPaymentRequestListener(channel);
      await setupOrderEventListener(channel);

      console.log("Payment service event listeners connected successfully");
      return true;
    } catch (error) {
      attempt++;
      console.error(`RabbitMQ connection failed (attempt ${attempt}/${retries}):`, error.message);

      if (channel) {
        try { await channel.close(); } catch (e) { console.error("Error closing channel:", e); }
        channel = null;
      }

      if (connection) {
        try { await connection.close(); } catch (e) { console.error("Error closing connection:", e); }
        connection = null;
      }

      if (attempt < retries) {
        console.log(`Retrying in ${delay / 1000} seconds...`);
        await new Promise((res) => setTimeout(res, delay));
        delay *= 2;
      } else {
        console.error("Could not connect to RabbitMQ after multiple attempts");
        return false;
      }
    }
  }
};

async function setupPaymentRequestListener(channel) {
  const exchange = "payment_events";
  const routingKey = "PAYMENT_REQUEST";
  const queue = "payment_service_request_queue";

  await channel.assertExchange(exchange, "topic", { durable: true });
  const { queue: queueName } = await channel.assertQueue(queue, {
    durable: true,
  });
  await channel.bindQueue(queueName, exchange, routingKey);

  console.log(`Listening for payment requests on ${exchange}/${routingKey}`);

  channel.consume(queueName, async (msg) => {
    if (!msg) return;

    try {
      const paymentRequest = JSON.parse(msg.content.toString());
      await processPaymentRequest(paymentRequest);
      channel.ack(msg);
    } catch (error) {
      console.error("Error processing payment request:", error);
      channel.nack(msg, false, true);
    }
  });
}

async function setupOrderEventListener(channel) {
  const exchange = "order_events";
  const routingKey = "ORDER_#";
  const queue = "payment_service_order_queue";

  await channel.assertExchange(exchange, "topic", { durable: true });
  const { queue: queueName } = await channel.assertQueue(queue, {
    durable: true,
  });
  await channel.bindQueue(queueName, exchange, routingKey);

  console.log(`Listening for order events on ${exchange}/${routingKey}`);

  channel.consume(queueName, async (msg) => {
    if (!msg) return;

    try {
      const orderEvent = JSON.parse(msg.content.toString());
      
      if (orderEvent.type === "ORDER_CANCELLED") {
        await handleOrderCancellation(orderEvent);
      }

      channel.ack(msg);
    } catch (error) {
      console.error("Error processing order event:", error);
      channel.nack(msg, false, false);
    }
  });
}

async function processPaymentRequest(paymentRequest) {
  try {
    const { orderId, userId, amount } = paymentRequest;

    let paymentMethod = {
      type: "CREDIT_CARD",
      cardLast4: "4242",
      provider: "Stripe Test",
    };

    const payment = new paymentModel({
      orderId,
      userId,
      amount,
      paymentMethod,
      gatewayType: "stripe",
      status: "PROCESSING",
    });

    await payment.save();

    const stripeGateway = new StripeGateway({
      success_rate: 0.9,
    });

    const result = await stripeGateway.processPayment({
      orderId: payment.orderId,
      paymentId: payment.paymentId,
      amount: payment.amount,
      paymentMethod: payment.paymentMethod,
    });

    payment.status = result.success ? "SUCCESSFUL" : "FAILED";
    payment.gatewayTransactionId = result.transactionId;
    payment.gatewayResponse = result.gatewayResponse;

    if (!result.success) {
      payment.errorInfo = result.error || "Payment processing failed";
    }

    await payment.save();

    const eventType = result.success ? "PAYMENT_SUCCESSFUL" : "PAYMENT_FAILED";
    await publishPaymentEvent(eventType, payment);

    return payment;
  } catch (error) {
    console.error("Error processing payment request:", error);
    throw error;
  }
}

async function handleOrderCancellation(orderEvent) {
  try {
    const { orderId } = orderEvent;
    const payment = await paymentModel.findOne({ orderId });

    if (!payment) {
      console.log(`No payment found for cancelled order ${orderId}`);
      return;
    }

    if (payment.status === "SUCCESSFUL") {
      console.log(`Initiating refund for payment ${payment.paymentId}`);

      const stripeGateway = new StripeGateway();

      const refundResult = await stripeGateway.processRefund({
        paymentId: payment.paymentId,
        amount: payment.amount,
        reason: "Order cancelled",
        gatewayTransactionId: payment.gatewayTransactionId,
      });

      payment.status = "REFUNDED";
      payment.refundInfo = {
        amount: payment.amount,
        reason: "Order cancelled",
        date: new Date(),
        transactionId: refundResult.transactionId,
        gatewayResponse: refundResult.gatewayResponse,
      };

      await payment.save();
      await publishPaymentEvent("PAYMENT_REFUNDED", payment);
    }
  } catch (error) {
    console.error("Error handling order cancellation:", error);
  }
}