import amqplib from "amqplib";

let channel;
let connection;
const exchangeName = "payment_events";

export const connectRabbitMQ = async (retries = 5, delay = 2000) => {
  let attempt = 0;
  while (attempt < retries) {
    try {
      console.log(
        `Connecting to RabbitMQ (attempt ${attempt + 1}/${retries})...`
      );

      connection = await amqplib.connect(process.env.RABBITMQ_URL);

      connection.on("error", (err) => {
        console.error("RabbitMQ connection error:", err.message);
      });

      connection.on("close", () => {
        console.warn("RabbitMQ connection closed, attempting to reconnect...");
        channel = null;
        setTimeout(() => connectRabbitMQ(), 5000);
      });

      channel = await connection.createChannel();

      await channel.assertExchange(exchangeName, "topic", {
        durable: true,
        arguments: {
          "x-message-ttl": 300000,
          "x-max-length": 10000,
        },
      });

      console.log(
        "Connected to RabbitMQ for payment events with enhanced configuration"
      );
      return true;
    } catch (error) {
      attempt++;
      console.error(
        `RabbitMQ connection failed (attempt ${attempt}/${retries}):`,
        error.message
      );

      if (channel) {
        try {
          await channel.close();
        } catch (e) {
          console.error("Error closing channel:", e);
        }
        channel = null;
      }

      if (connection) {
        try {
          await connection.close();
        } catch (e) {
          console.error("Error closing connection:", e);
        }
        connection = null;
      }

      if (attempt < retries) {
        console.log(`Retrying in ${delay / 1000} seconds...`);
        await new Promise((res) => setTimeout(res, delay));
        delay *= 2;
      } else {
        console.error("Could not connect to RabbitMQ after multiple attempts");
        return false;
      }
    }
  }
};

export const publishPaymentEvent = async (eventType, payload) => {
  if (!channel) {
    console.error("RabbitMQ not connected. Attempting to reconnect...");
    await connectRabbitMQ();
    if (!channel) throw new Error("RabbitMQ connection failed");
  }

  const eventPayload = {
    type: eventType,
    paymentId: payload.paymentId,
    orderId: payload.orderId,
    userId: payload.userId,
    amount: payload.amount,
    status: payload.status,
    gatewayTransactionId: payload.gatewayTransactionId,
    timestamp: new Date().toISOString(),
    eventId: `pay_evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    correlationId: `pay_${payload.orderId}_${payload.paymentId}`,
    source: "payment-service",
    version: "2.0",
    sagaId: payload.sagaId,
  };

  try {
    const published = channel.publish(
      exchangeName,
      eventType,
      Buffer.from(JSON.stringify(eventPayload)),
      {
        persistent: true,
        messageId: eventPayload.eventId,
        correlationId: eventPayload.correlationId,
        timestamp: Date.now(),
        headers: {
          "event-type": eventType,
          "source-service": "payment-service",
        },
      }
    );

    if (published) {
      console.log(
        `Published ${eventType} event for payment ${payload.paymentId} with correlation ${eventPayload.correlationId}`
      );
      return true;
    } else {
      console.warn(`Channel buffer full, ${eventType} event queued for retry`);
      setTimeout(() => publishPaymentEvent(eventType, payload), 1000);
      return false;
    }
  } catch (error) {
    console.error(`Failed to publish ${eventType} event:`, error);
    return false;
  }
};
