import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { connectDB } from "./config/db.js";
import paymentRouter from "./routes/paymentRoutes.js";
import { connectRabbitMQ } from "./utils/eventPublisher.js";
import { connectEventListeners } from "./utils/eventListener.js";
import redis from "./config/redis.js";
import mongoose from "mongoose";

dotenv.config();

const app = express();
const port = process.env.PORT || 6001;

app.use(express.json());

connectDB();

connectRabbitMQ().catch((err) => {
  console.error("Failed to connect to RabbitMQ for publishing:", err);
});

connectEventListeners().catch((err) => {
  console.error("Failed to set up event listeners:", err);
});

app.use("/api/payments", paymentRouter);

app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    redis: redis.status,
    db: mongoose.connection.readyState === 1 ? "connected" : "disconnected",
  });
});

app.listen(port, () => {
  console.log(`Payment service running on port ${port}`);
});
