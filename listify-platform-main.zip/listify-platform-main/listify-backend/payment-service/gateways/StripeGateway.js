import Stripe from "stripe";

export default class StripeGateway {
  constructor(config = {}) {
    const apiKey = config.apiKey || process.env.STRIPE_SECRET_KEY;

    this.options = {
      apiVersion: config.apiVersion || "2022-11-15",
      publicKey: config.publicKey || process.env.STRIPE_PUBLIC_KEY,
      currency: config.currency || "usd",
      returnUrl: config.returnUrl || "https://yoursite.com/checkout/complete",
      ...config,
    };

    this.stripe = new Stripe(apiKey, {
      apiVersion: this.options.apiVersion,
    });

    console.log("Initialized Stripe gateway with sandbox configuration");
  }

  async processPayment(paymentData) {
    console.log(`Processing Stripe payment for order ${paymentData.orderId}`);

    try {
      let paymentMethod;

      if (paymentData.cardNumber) {
        // Map known test cards to their corresponding test tokens
        if (paymentData.cardNumber === "4000000000000002") {
          paymentMethod = { id: "pm_card_visa_chargeDeclined" };
        } else if (paymentData.cardNumber === "4000000000000069") {
          paymentMethod = { id: "pm_card_visa_chargeDeclinedExpiredCard" };
        } else if (paymentData.cardNumber === "4000000000000127") {
          paymentMethod = { id: "pm_card_visa_chargeDeclinedIncorrectCvc" };
        } else if (paymentData.cardNumber === "4000000000009995") {
          paymentMethod = { id: "pm_card_visa_chargeDeclinedFraudulent" };
        } else if (paymentData.cardNumber.startsWith("4242")) {
          paymentMethod = { id: "pm_card_visa" };
        } else {
          paymentMethod = { id: "pm_card_visa" };
        }
      } else if (paymentData.paymentMethodId) {
        paymentMethod = { id: paymentData.paymentMethodId };
      } else {
        paymentMethod = { id: "pm_card_visa" };
      }

      const paymentIntent = await this.stripe.paymentIntents.create({
        amount: Math.round(paymentData.amount * 100),
        currency: this.options.currency,
        payment_method_types: ["card"],
        description: `Order #${paymentData.orderId}`,
        metadata: {
          orderId: paymentData.orderId,
          paymentId: paymentData.paymentId,
        },
        payment_method: paymentMethod.id,
        confirm: true,
        return_url: this.options.returnUrl,
      });

      console.log(
        `Payment processed: ${paymentIntent.id} (Status: ${paymentIntent.status})`
      );

      return {
        success: paymentIntent.status === "succeeded",
        transactionId: paymentIntent.id,
        gatewayResponse: paymentIntent,
        status: paymentIntent.status,
      };
    } catch (error) {
      console.error("Error processing Stripe payment:", error);

      let errorType = error.type || "processing_error";
      let errorCode = error.code || "unknown";
      let errorMessage = error.message || "Payment processing failed";

      if (error.raw && error.raw.code) {
        errorCode = error.raw.code;
        errorType = error.raw.type;
        errorMessage = error.raw.message;
      }

      return {
        success: false,
        error: errorMessage,
        transactionId: null,
        gatewayResponse: {
          error: {
            type: errorType,
            code: errorCode,
            message: errorMessage,
          },
        },
      };
    }
  }

  async processRefund(refundData) {
    console.log(
      `[SAGA:COMPENSATE] Processing refund for payment ${refundData.gatewayTransactionId}`
    );

    try {
      if (!refundData.gatewayTransactionId) {
        throw new Error("Missing gatewayTransactionId for refund");
      }

      const refund = await this.stripe.refunds.create({
        payment_intent: refundData.gatewayTransactionId,
        amount: Math.round(refundData.amount * 100),
        reason: "requested_by_customer",
        metadata: {
          reason: refundData.reason || "Order compensation",
          orderId: refundData.orderId,
        },
      });

      console.log(
        `[SAGA:COMPENSATE] Refund created: ${refund.id} (${refund.status})`
      );

      return {
        success: true,
        transactionId: refund.id,
        gatewayResponse: refund,
      };
    } catch (error) {
      console.error("[SAGA:COMPENSATE] Error processing refund:", error);
      return {
        success: false,
        error: error.message || "Refund processing failed",
        transactionId: null,
        gatewayResponse: {
          error: {
            type: error.type || "processing_error",
            code: error.code || "unknown",
            message: error.message,
          },
        },
      };
    }
  }

  getClientConfig() {
    return {
      gateway: "stripe",
      publicKey: this.options.publicKey,
      options: {
        appearance: {
          theme: "stripe",
        },
      },
    };
  }
}
