import express from "express";
import PaymentController from "../controllers/paymentController.js";
import userAuth from "../middleware/userAuth.js";

const paymentRouter = express.Router();

paymentRouter.get("/gateways", PaymentController.getPaymentGateways);

paymentRouter.post("/process", userAuth, PaymentController.processPayment);
paymentRouter.post("/refund", userAuth, PaymentController.processRefund);

export default paymentRouter;
