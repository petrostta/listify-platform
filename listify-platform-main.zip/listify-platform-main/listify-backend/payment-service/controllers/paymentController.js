import paymentModel from "../models/payment.js";
import { publishPaymentEvent } from "../utils/eventPublisher.js";
import StripeGateway from "../gateways/StripeGateway.js";

export default class PaymentController {
  static async processPayment(req, res) {
    try {
      const {
        orderId,
        userId,
        amount,
        paymentMethod,
        cardNumber,
        expMonth,
        expYear,
        cvc,
      } = req.body;

      const payment = new paymentModel({
        orderId,
        userId,
        amount,
        paymentMethod,
        gatewayType: "stripe",
        status: "PROCESSING",
      });

      await payment.save();

      const stripeGateway = new StripeGateway();
      const result = await stripeGateway.processPayment({
        orderId: payment.orderId,
        paymentId: payment.paymentId,
        amount: payment.amount,
        paymentMethod: payment.paymentMethod,
        cardNumber,
        expMonth,
        expYear,
        cvc,
      });

      payment.status = result.success ? "SUCCESSFUL" : "FAILED";
      payment.gatewayTransactionId = result.transactionId;
      payment.gatewayResponse = result.gatewayResponse;

      if (!result.success) {
        payment.errorInfo = result.error || "Payment processing failed";
      }

      await payment.save();

      const eventType = result.success
        ? "PAYMENT_SUCCESSFUL"
        : "PAYMENT_FAILED";
      await publishPaymentEvent(eventType, payment);

      return res.status(200).json({
        success: result.success,
        payment: {
          paymentId: payment.paymentId,
          status: payment.status,
          transactionId: payment.gatewayTransactionId,
        },
      });
    } catch (error) {
      console.error("Error processing payment:", error);
      return res.status(500).json({
        message: "Payment processing failed",
        error: error.message,
      });
    }
  }

  static async getPaymentGateways(req, res) {
    try {
      const stripeGateway = new StripeGateway();
      const gateways = [stripeGateway.getClientConfig()];

      return res.json({ gateways });
    } catch (error) {
      console.error("Error fetching payment gateways:", error);
      return res.status(500).json({
        message: "Failed to retrieve payment gateways",
        error: error.message,
      });
    }
  }

  static async processRefund(req, res) {
    try {
      const { orderId, paymentId, amount, reason } = req.body;

      console.log(`[SAGA:COMPENSATE] Processing refund for order ${orderId}`);

      if (!orderId || !paymentId || !amount) {
        return res
          .status(400)
          .json({ message: "Missing required refund information" });
      }

      const payment = await paymentModel.findOne({
        orderId,
        status: "SUCCESSFUL",
      });

      if (!payment) {
        return res
          .status(404)
          .json({ message: "Payment not found or not in refundable state" });
      }

      const stripeGateway = new StripeGateway();

      const result = await stripeGateway.processRefund({
        paymentId: payment.paymentId,
        gatewayTransactionId: payment.gatewayTransactionId,
        amount: amount,
        reason: reason || "Order cancelled",
        orderId: orderId,
      });

      payment.status = "REFUNDED";
      payment.refundInfo = {
        amount: amount,
        reason: reason || "Order cancelled",
        date: new Date(),
        transactionId: result.transactionId,
        gatewayResponse: result.gatewayResponse,
      };

      await payment.save();
      await publishPaymentEvent("PAYMENT_REFUNDED", payment);

      return res.status(200).json({
        success: true,
        message: "Refund processed successfully",
        payment: {
          paymentId: payment.paymentId,
          status: payment.status,
          refundId: result.transactionId,
        },
      });
    } catch (error) {
      console.error("[SAGA:COMPENSATE] Error processing refund:", error);
      return res.status(500).json({
        message: "Refund processing failed",
        error: error.message,
      });
    }
  }
}
