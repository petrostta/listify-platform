import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const paymentMethodSchema = new mongoose.Schema({
  type: { type: String, required: true },
  cardLast4: { type: String },
  provider: { type: String },
  gatewayCustomerId: { type: String },
  gatewayPaymentMethodId: { type: String },
});

const paymentSchema = new mongoose.Schema(
  {
    paymentId: {
      type: String,
      default: uuidv4,
      unique: true,
    },
    orderId: {
      type: String,
      required: true,
    },
    userId: {
      type: String,
      required: true,
    },
    amount: {
      type: Number,
      required: true,
    },
    currency: {
      type: String,
      default: "USD",
    },
    paymentMethod: {
      type: paymentMethodSchema,
      required: true,
    },
    status: {
      type: String,
      enum: ["PENDING", "PROCESSING", "SUCCESSFUL", "FAILED", "REFUNDED"],
      default: "PENDING",
    },
    gatewayType: {
      type: String,
      enum: ["stripe"],
      default: "stripe",
      required: true,
    },
    gatewayTransactionId: {
      type: String,
    },
    gatewayResponse: {
      type: mongoose.Schema.Types.Mixed,
    },
    errorInfo: {
      type: String,
    },
    refundInfo: {
      amount: { type: Number },
      reason: { type: String },
      date: { type: Date },
      transactionId: { type: String },
      gatewayResponse: { type: mongoose.Schema.Types.Mixed },
    },
  },
  {
    timestamps: true,
  }
);

const paymentModel =
  mongoose.models.payment || mongoose.model("payment", paymentSchema);
export default paymentModel;
