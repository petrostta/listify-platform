import reviewModel from "../models/review.js";
import productReviewProfileModel from "../models/productReviewProfile.js";
import sellerReviewProfileModel from "../models/sellerReviewProfile.js";
import ReviewEligibilityService from "../services/reviewEligibilityService.js";
import { publishReviewEvent } from "../utils/eventPublisher.js";
import redis from "../config/redis.js";
import ProductCache from "../models/productCache.js";

const getProductDetails = async (productId) => {
  try {
    const product = await ProductCache.findOne({ productId });
    if (product) {
      return {
        name: product.name,
        image: product.pictures?.[0]?.url || null,
        pictures: product.pictures || [],
      };
    }
  } catch (error) {
    console.warn(
      `Failed to get product details for ${productId}:`,
      error.message
    );
  }

  return {
    name: "Product",
    image: null,
    pictures: [],
  };
};

export default class ReviewController {
  static async createReview(req, res) {
    try {
      const { productId, orderId, rating, reviewDescription } = req.body;
      const userId = req.user.uuid;

      if (
        !ReviewEligibilityService.isEligibleToReview(userId, productId, orderId)
      ) {
        return res.status(403).json({
          message:
            "You can only review products that you have purchased and received",
        });
      }

      const productProfile = await productReviewProfileModel.findOne({
        productId,
      });
      if (!productProfile) {
        return res.status(404).json({ message: "Product not found" });
      }

      const review = new reviewModel({
        productId,
        userId,
        sellerId: productProfile.sellerId,
        orderId,
        rating,
        reviewDescription,
      });

      await review.save();

      await updateProductReviewMetrics(productId);
      await updateSellerReviewMetrics(productProfile.sellerId);

      ReviewEligibilityService.removeEligibility(userId, productId, orderId);

      try {
        await redis.del(`product:reviews:${productId}`);
        await redis.del(`product:review:count:${productId}`);
        await redis.del(`product:review:count-simple:${productId}`);
        await redis.del(`seller:reviews:${productProfile.sellerId}`);

        const keys = await redis.keys(`product:reviews:${productId}:*`);
        if (keys.length > 0) {
          await redis.del(keys);
        }
      } catch (cacheError) {
        console.error("Error clearing cache:", cacheError);
      }

      const updatedProfile = await productReviewProfileModel.findOne({
        productId,
      });

      await publishReviewEvent("REVIEW_CREATED", {
        productId,
        reviewId: review.uuid,
        userId,
        rating,
        averageRating: updatedProfile?.averageRating || 0,
        totalReviews: updatedProfile?.totalReviews || 0,
      });

      return res.status(201).json({
        success: true,
        review,
      });
    } catch (error) {
      console.error("Error creating review:", error);
      return res
        .status(500)
        .json({ message: "Failed to create review", error: error.message });
    }
  }

  static async getProductReviews(req, res) {
    try {
      const { productId } = req.params;
      const { page = 1, limit = 10 } = req.query;

      const cacheKey = `reviews:product:${productId}:page:${page}:limit:${limit}`;

      try {
        const cachedData = await redis.get(cacheKey);
        if (cachedData) {
          return res.json(JSON.parse(cachedData));
        }
      } catch (cacheError) {
        console.warn("Cache error:", cacheError);
      }

      const skip = (parseInt(page) - 1) * parseInt(limit);

      const [reviews, productProfile, totalReviews] = await Promise.all([
        reviewModel
          .find(
            { productId },
            {
              uuid: 1,
              rating: 1,
              reviewDescription: 1,
              createdAt: 1,
              userDisplayName: 1,
              helpfulCount: 1,
              _id: 0,
            }
          )
          .sort({ createdAt: -1 })
          .skip(skip)
          .limit(parseInt(limit))
          .lean(),

        productReviewProfileModel
          .findOne({ productId }, { averageRating: 1, totalReviews: 1, _id: 0 })
          .lean(),

        reviewModel.countDocuments({ productId }),
      ]);

      const totalPages = Math.ceil(totalReviews / parseInt(limit));

      const result = {
        reviews,
        stats: productProfile
          ? {
              averageRating: productProfile.averageRating,
              totalReviews: productProfile.totalReviews,
            }
          : { averageRating: 0, totalReviews: 0 },
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          totalReviews,
          totalPages,
        },
      };

      try {
        await redis.setex(cacheKey, 600, JSON.stringify(result));
      } catch (cacheError) {
        console.warn("Cache set error:", cacheError);
      }

      return res.json(result);
    } catch (error) {
      console.error("Error fetching product reviews:", error);
      return res
        .status(500)
        .json({ message: "Failed to fetch reviews", error: error.message });
    }
  }

  static async getSimpleProductReviewCount(req, res) {
    try {
      const { productId } = req.params;

      const cacheKey = `product:review:count-simple:${productId}`;
      let cachedData;

      try {
        cachedData = await redis.get(cacheKey);
        if (cachedData) {
          return res.json(JSON.parse(cachedData));
        }
      } catch (cacheError) {
        console.error("Cache error:", cacheError);
      }

      const productProfile = await productReviewProfileModel.findOne(
        { productId },
        { averageRating: 1, totalReviews: 1, _id: 0 }
      );

      const data = {
        count: productProfile ? productProfile.totalReviews || 0 : 0,
        averageRating: productProfile ? productProfile.averageRating || 0 : 0,
      };

      try {
        await redis.setex(cacheKey, 86400, JSON.stringify(data));
      } catch (cacheError) {
        console.error("Error setting cache:", cacheError);
      }

      return res.json(data);
    } catch (error) {
      console.error("Error fetching simple review count:", error);
      return res.json({ count: 0, averageRating: 0 });
    }
  }

  static async getProductReviewCount(req, res) {
    try {
      const { productId } = req.params;

      const cacheKey = `product:review:count:${productId}`;
      try {
        await redis.del(cacheKey);
      } catch (err) {
        console.error("Error clearing cache:", err);
      }

      const productProfile = await productReviewProfileModel.findOne({
        productId,
      });

      const data = {
        count: productProfile ? productProfile.totalReviews || 0 : 0,
        averageRating: productProfile ? productProfile.averageRating || 0 : 0,
      };

      return res.json(data);
    } catch (error) {
      console.error("Error fetching review count:", error);
      return res.status(500).json({
        message: "Failed to fetch review count",
        error: error.message,
      });
    }
  }

  static async getSellerReviews(req, res) {
    try {
      const { sellerId } = req.params;
      const { page = 1, limit = 10 } = req.query;

      const skip = (parseInt(page) - 1) * parseInt(limit);

      const reviews = await reviewModel
        .find({ sellerId })
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit));

      // Enrich reviews with cached product details
      const enrichedReviews = await Promise.all(
        reviews.map(async (review) => {
          const productDetails = await getProductDetails(review.productId);
          return {
            ...review.toObject(),
            product: {
              name: productDetails.name,
              pictures: productDetails.pictures,
            },
          };
        })
      );

      const totalReviews = await reviewModel.countDocuments({ sellerId });

      res.json({
        reviews: enrichedReviews,
        total: totalReviews,
        page: parseInt(page),
        totalPages: Math.ceil(totalReviews / parseInt(limit)),
      });
    } catch (error) {
      console.error("Error fetching seller reviews:", error);
      res.status(500).json({ message: error.message });
    }
  }

  static async getUserReviews(req, res) {
    try {
      const userId = req.user.uuid;
      const { includeProductDetails } = req.query;

      const reviews = await reviewModel
        .find({ userId })
        .sort({ createdAt: -1 });

      let enrichedReviews = reviews;

      if (includeProductDetails === "true") {
        enrichedReviews = await Promise.all(
          reviews.map(async (review) => {
            const productDetails = await getProductDetails(review.productId);
            return {
              ...review.toObject(),
              productName: productDetails.name,
              image: productDetails.image,
              product: {
                name: productDetails.name,
                pictures: productDetails.pictures,
              },
            };
          })
        );
      }

      res.json({ reviews: enrichedReviews });
    } catch (error) {
      console.error("Error fetching user reviews:", error);
      res.status(500).json({ message: error.message });
    }
  }

  static async getEligibleReviews(req, res) {
    try {
      const userId = req.user.uuid;

      const eligibleProducts =
        ReviewEligibilityService.getEligibleProductsForUser(userId);

      // Enrich with cached product details
      const enrichedProducts = await Promise.all(
        eligibleProducts.map(async (product) => {
          const productDetails = await getProductDetails(product.productId);
          return {
            ...product,
            productName: productDetails.name,
            image: productDetails.image,
            pictures: productDetails.pictures,
          };
        })
      );

      return res.json({
        success: true,
        eligibleProducts: enrichedProducts,
      });
    } catch (error) {
      console.error("Error fetching eligible reviews:", error);
      res.status(500).json({ message: error.message });
    }
  }

  static async updateReview(req, res) {
    try {
      const { reviewId } = req.params;
      const { rating, reviewDescription } = req.body;
      const userId = req.user.uuid;

      const review = await reviewModel.findOne({
        uuid: reviewId,
        userId,
      });

      if (!review) {
        return res
          .status(404)
          .json({ message: "Review not found or unauthorized" });
      }

      review.rating = rating || review.rating;
      review.reviewDescription = reviewDescription || review.reviewDescription;
      await review.save();

      await updateProductReviewMetrics(review.productId);
      await updateSellerReviewMetrics(review.sellerId);

      try {
        await redis.del(`product:reviews:${review.productId}`);
        await redis.del(`product:review:count:${review.productId}`);
        await redis.del(`product:review:count-simple:${review.productId}`);

        const keys = await redis.keys(`product:reviews:${review.productId}:*`);
        if (keys.length > 0) {
          await redis.del(keys);
        }
      } catch (cacheError) {
        console.error("Error clearing cache:", cacheError);
      }

      const productProfile = await productReviewProfileModel.findOne({
        productId: review.productId,
      });

      await publishReviewEvent("REVIEW_UPDATED", {
        productId: review.productId,
        reviewId: review.uuid,
        userId,
        rating: review.rating,
        averageRating: productProfile ? productProfile.averageRating : 0,
        totalReviews: productProfile ? productProfile.totalReviews : 0,
      });

      return res.json({
        success: true,
        review,
      });
    } catch (error) {
      console.error("Error updating review:", error);
      return res.status(500).json({
        message: "Failed to update review",
        error: error.message,
      });
    }
  }

  static async deleteReview(req, res) {
    try {
      const { reviewId } = req.params;
      const userId = req.user.uuid;

      const review = await reviewModel.findOne({
        uuid: reviewId,
        userId,
      });

      if (!review) {
        return res
          .status(404)
          .json({ message: "Review not found or unauthorized" });
      }

      const productId = review.productId;
      const sellerId = review.sellerId;

      await reviewModel.deleteOne({ uuid: reviewId });

      await updateProductReviewMetrics(productId);
      await updateSellerReviewMetrics(sellerId);

      try {
        await redis.del(`product:reviews:${productId}`);
        await redis.del(`product:review:count:${productId}`);
        await redis.del(`product:review:count-simple:${productId}`);

        const keys = await redis.keys(`product:reviews:${productId}:*`);
        if (keys.length > 0) {
          await redis.del(keys);
        }
      } catch (cacheError) {
        console.error("Error clearing cache:", cacheError);
      }

      const productProfile = await productReviewProfileModel.findOne({
        productId: productId,
      });

      await publishReviewEvent("REVIEW_DELETED", {
        productId,
        reviewId,
        userId,
        averageRating: productProfile ? productProfile.averageRating : 0,
        totalReviews: productProfile ? productProfile.totalReviews : 0,
      });

      return res.json({
        success: true,
        message: "Review deleted successfully",
      });
    } catch (error) {
      console.error("Error deleting review:", error);
      return res.status(500).json({
        message: "Failed to delete review",
        error: error.message,
      });
    }
  }
}

async function updateProductReviewMetrics(productId) {
  try {
    const reviewCount = await reviewModel.countDocuments({ productId });

    if (reviewCount === 0) {
      await productReviewProfileModel.findOneAndUpdate(
        { productId },
        {
          averageRating: 0,
          totalReviews: 0,
        },
        { upsert: true, new: true }
      );
      return;
    }

    const result = await reviewModel.aggregate([
      { $match: { productId } },
      {
        $group: {
          _id: null,
          averageRating: { $avg: "$rating" },
          totalReviews: { $sum: 1 },
        },
      },
    ]);

    if (result.length === 0) {
      return;
    }

    await productReviewProfileModel.findOneAndUpdate(
      { productId },
      {
        averageRating: result[0].averageRating,
        totalReviews: result[0].totalReviews,
      },
      { upsert: true, new: true }
    );
  } catch (error) {
    console.error("Error updating product review metrics:", error);
  }
}

async function updateSellerReviewMetrics(sellerId) {
  try {
    const reviewCount = await reviewModel.countDocuments({ sellerId });

    if (reviewCount === 0) {
      await sellerReviewProfileModel.findOneAndUpdate(
        { sellerId },
        {
          averageRating: 0,
          totalReviews: 0,
        },
        { upsert: true, new: true }
      );
      return;
    }

    const result = await reviewModel.aggregate([
      { $match: { sellerId } },
      {
        $group: {
          _id: null,
          averageRating: { $avg: "$rating" },
          totalReviews: { $sum: 1 },
        },
      },
    ]);

    if (result.length === 0) {
      return;
    }

    await sellerReviewProfileModel.findOneAndUpdate(
      { sellerId },
      {
        averageRating: result[0].averageRating,
        totalReviews: result[0].totalReviews,
      },
      { upsert: true, new: true }
    );
  } catch (error) {
    console.error("Error updating seller review metrics:", error);
  }
}
