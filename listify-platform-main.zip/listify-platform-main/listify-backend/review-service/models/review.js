import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const reviewSchema = new mongoose.Schema({
  uuid: { type: String, default: uuidv4, unique: true },
  productId: { type: String, required: true, index: true },
  userId: { type: String, required: true, index: true },
  sellerId: { type: String, required: true, index: true },
  rating: { type: Number, required: true },
  reviewDescription: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

reviewSchema.index({ productId: 1, createdAt: -1 });
reviewSchema.index({ sellerId: 1, createdAt: -1 });
reviewSchema.index({ userId: 1, createdAt: -1 });
reviewSchema.index({ productId: 1, rating: -1 });
reviewSchema.index({ sellerId: 1, rating: -1 });

reviewSchema.index({ uuid: 1 }, { unique: true, sparse: true });

reviewSchema.index({ reviewDescription: "text" });

const reviewModel =
  mongoose.models.review || mongoose.model("review", reviewSchema);
export default reviewModel;
