import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const sellerReviewProfileSchema = new mongoose.Schema({
  uuid: { type: String, default: uuidv4, unique: true },
  sellerId: { type: String, required: true, index: true },
  averageRating: { type: Number, default: 0 },
  totalReviews: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
});

const sellerReviewProfileModel =
  mongoose.models.sellerReviewProfile ||
  mongoose.model("sellerReviewProfile", sellerReviewProfileSchema);

export default sellerReviewProfileModel;
