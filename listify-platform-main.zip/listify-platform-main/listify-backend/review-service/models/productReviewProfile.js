import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const productReviewProfileSchema = new mongoose.Schema({
  uuid: { type: String, default: uuidv4, unique: true },
  productId: { type: String, required: true, index: true },
  sellerId: { type: String, required: true, index: true },
  averageRating: { type: Number, default: 0 },
  totalReviews: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
});

productReviewProfileSchema.index({ productId: 1 }, { unique: true });
productReviewProfileSchema.index({ sellerId: 1 });
productReviewProfileSchema.index({ averageRating: -1 });
productReviewProfileSchema.index({ totalReviews: -1 });

const productReviewProfileModel =
  mongoose.models.productReviewProfile ||
  mongoose.model("productReviewProfile", productReviewProfileSchema);

export default productReviewProfileModel;
