import mongoose from "mongoose";

const eligibleReviews = new Map();

class ReviewEligibilityService {
  static async markOrderEligibleForReview(orderId, userId, orderItems = []) {
    try {
      for (const item of orderItems) {
        const key = `${userId}:${item.productId}:${orderId}`;
        eligibleReviews.set(key, {
          orderId,
          productId: item.productId,
          userId,
          eligibleSince: new Date(),
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        });
      }

      return true;
    } catch (error) {
      console.error("Error marking order for review eligibility:", error);
      return false;
    }
  }

  static isEligibleToReview(userId, productId, orderId) {
    const key = `${userId}:${productId}:${orderId}`;
    const eligibility = eligibleReviews.get(key);

    if (!eligibility) return false;

    if (eligibility.expiresAt < new Date()) {
      eligibleReviews.delete(key);
      return false;
    }

    return true;
  }

  static removeEligibility(userId, productId, orderId) {
    const key = `${userId}:${productId}:${orderId}`;
    return eligibleReviews.delete(key);
  }

  static getEligibleProductsForUser(userId) {
    const result = [];

    for (const [key, value] of eligibleReviews.entries()) {
      if (key.startsWith(`${userId}:`)) {
        result.push({
          productId: value.productId,
          orderId: value.orderId,
        });
      }
    }

    return result;
  }
}

export default ReviewEligibilityService;
