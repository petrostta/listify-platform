import amqplib from "amqplib";
import productReviewProfileModel from "../models/productReviewProfile.js";

let channel;
let connection;

export const connectReviewMQ = async (retries = 5, delay = 2000) => {
  let attempt = 0;
  while (attempt < retries) {
    try {
      connection = await amqplib.connect(process.env.RABBITMQ_URI);

      connection.on("error", (err) => {
        console.error("RabbitMQ connection error:", err.message);
      });

      connection.on("close", () => {
        console.warn("RabbitMQ connection closed, attempting to reconnect...");
        setTimeout(() => connectReviewMQ(), 5000);
      });

      channel = await connection.createChannel();

      await channel.assertExchange("review_events", "topic", { durable: true });

      console.log("Review service connected to RabbitMQ");
      return true;
    } catch (error) {
      attempt++;
      console.error(
        `RabbitMQ connection failed (attempt ${attempt}/${retries}):`,
        error.message
      );

      if (attempt < retries) {
        await new Promise((resolve) => setTimeout(resolve, delay));
        delay *= 2;
      }
    }
  }
  throw new Error("Failed to connect to RabbitMQ after multiple attempts");
};

export const publishReviewEvent = async (eventType, reviewData) => {
  if (!channel) {
    console.error("RabbitMQ channel not available");
    return false;
  }

  try {
    const reviewStats = await productReviewProfileModel.findOne({
      productId: reviewData.productId,
    });

    const eventPayload = {
      type: eventType,
      reviewId: reviewData.uuid,
      productId: reviewData.productId,
      userId: reviewData.userId,
      rating: reviewData.rating,
      averageRating: reviewStats?.averageRating || 0,
      reviewCount: reviewStats?.totalReviews || 0,
      timestamp: new Date().toISOString(),
    };

    return channel.publish(
      "review_events",
      eventType,
      Buffer.from(JSON.stringify(eventPayload)),
      { persistent: true }
    );
  } catch (error) {
    console.error("Error publishing review event:", error);
    return false;
  }
};
