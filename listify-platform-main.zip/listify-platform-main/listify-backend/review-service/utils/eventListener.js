import amqplib from "amqplib";
import sellerReviewProfileModel from "../models/sellerReviewProfile.js";
import productReviewProfileModel from "../models/productReviewProfile.js";
import reviewEligibilityService from "../services/reviewEligibilityService.js";
import ProductCache from "../models/productCache.js";

let channel;
let connection;

export const connectEventListeners = async (retries = 5, delay = 2000) => {
  let attempt = 0;
  while (attempt < retries) {
    try {
      console.log(
        `Connecting to RabbitMQ (attempt ${attempt + 1}/${retries})...`
      );

      connection = await amqplib.connect(process.env.RABBITMQ_URI);

      connection.on("error", (err) => {
        console.error("Review Service RabbitMQ connection error:", err.message);
      });

      connection.on("close", () => {
        console.warn(
          "Review Service RabbitMQ connection closed, attempting to reconnect..."
        );
        setTimeout(() => connectEventListeners(), 5000);
      });

      channel = await connection.createChannel();

      // Set up all event listeners
      await setupSellerListener();
      await setupProductListener();
      await setupOrderListener();

      console.log("Review service event listeners connected successfully");
      return true;
    } catch (error) {
      attempt++;
      console.error(
        `RabbitMQ connection failed (attempt ${attempt}/${retries}):`,
        error.message
      );

      if (attempt < retries) {
        console.log(`Retrying in ${delay / 1000} seconds...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
        delay *= 2;
      } else {
        console.error("Failed to connect to RabbitMQ after multiple attempts");
        throw error;
      }
    }
  }
};

async function setupSellerListener() {
  try {
    const exchange = "seller_events";
    await channel.assertExchange(exchange, "topic", { durable: true });
    const { queue } = await channel.assertQueue("review_service_seller_queue", {
      durable: true,
    });

    await channel.bindQueue(queue, exchange, "SELLER_PROFILE_CREATED");

    console.log("Listening for seller events...");

    channel.consume(queue, async (msg) => {
      if (!msg) return;

      try {
        const sellerEvent = JSON.parse(msg.content.toString());
        console.log(
          `Processing seller event: ${sellerEvent.type} for seller ${sellerEvent.uuid}`
        );

        switch (sellerEvent.type) {
          case "SELLER_PROFILE_CREATED":
            await createSellerReviewProfile(sellerEvent.uuid);
            break;
          default:
            console.warn(`Unhandled seller event type: ${sellerEvent.type}`);
        }

        channel.ack(msg);
      } catch (error) {
        console.error("Error processing seller event:", error);
        channel.ack(msg);
      }
    });
  } catch (error) {
    console.error("Error setting up seller event listener:", error);
    throw error;
  }
}

async function setupProductListener() {
  try {
    const exchange = "product_data_events";
    await channel.assertExchange(exchange, "topic", { durable: true });
    const { queue } = await channel.assertQueue(
      "review_service_product_queue",
      { durable: true }
    );

    await channel.bindQueue(queue, exchange, "PRODUCT_CREATED");
    await channel.bindQueue(queue, exchange, "PRODUCT_UPDATED");
    await channel.bindQueue(queue, exchange, "PRODUCT_DELETED");

    console.log("Listening for product data events...");

    channel.consume(queue, async (msg) => {
      if (!msg) return;

      try {
        const productData = JSON.parse(msg.content.toString());
        console.log(
          `Processing product event: ${productData.type} for product ${productData.productId}`
        );

        switch (productData.type) {
          case "PRODUCT_CREATED":
            await createProductReviewProfile(productData);
            await updateProductCache(productData);
            break;
          case "PRODUCT_UPDATED":
            await updateProductCache(productData);
            break;
          case "PRODUCT_DELETED":
            await deleteProductCache(productData.productId);
            await deleteProductReviewProfile(productData.productId);
            break;
          default:
            console.warn(`Unhandled product event type: ${productData.type}`);
        }

        channel.ack(msg);
      } catch (error) {
        console.error("Error processing product event:", error);
        channel.ack(msg);
      }
    });
  } catch (error) {
    console.error("Error setting up product event listener:", error);
    throw error;
  }
}

async function setupOrderListener() {
  try {
    const exchange = "order_events";
    await channel.assertExchange(exchange, "topic", { durable: true });
    const { queue } = await channel.assertQueue("review_service_order_queue", {
      durable: true,
    });

    await channel.bindQueue(queue, exchange, "ORDER_CONFIRMED");
    await channel.bindQueue(queue, exchange, "ORDER_DELIVERED");
    await channel.bindQueue(queue, exchange, "ORDER_UPDATED");

    console.log("Listening for order events...");

    channel.consume(queue, async (msg) => {
      if (!msg) return;

      try {
        const orderEvent = JSON.parse(msg.content.toString());
        console.log(
          `Processing order event: ${orderEvent.type} for order ${orderEvent.orderId}`
        );

        switch (orderEvent.type) {
          case "ORDER_DELIVERED":
          case "ORDER_UPDATED":
            if (orderEvent.status === "DELIVERED") {
              await handleOrderDelivered(orderEvent);
            }
            break;
          case "ORDER_CONFIRMED":
            console.log(
              `Order ${orderEvent.orderId} confirmed - will be eligible for review once delivered`
            );
            break;
          default:
            console.warn(`Unhandled order event type: ${orderEvent.type}`);
        }

        channel.ack(msg);
      } catch (error) {
        console.error("Error processing order event:", error);
        channel.ack(msg);
      }
    });
  } catch (error) {
    console.error("Error setting up order event listener:", error);
    throw error;
  }
}

async function handleOrderDelivered(orderEvent) {
  try {
    console.log(
      `Order ${orderEvent.orderId} delivered - making eligible for review`
    );

    const items = orderEvent.items || orderEvent.orderItems || [];
    if (items.length === 0) {
      console.warn(
        `Order ${orderEvent.orderId} has no items to make eligible for review`
      );
      return;
    }

    await reviewEligibilityService.markOrderEligibleForReview(
      orderEvent.orderId,
      orderEvent.userId,
      items
    );

    console.log(
      `Made ${items.length} items from order ${orderEvent.orderId} eligible for review`
    );
  } catch (error) {
    console.error("Error handling order delivered event:", error);
  }
}

async function createProductReviewProfile(productData) {
  try {
    if (!productData.seller) {
      console.warn(
        `Product ${productData.productId} missing seller ID - cannot create review profile`
      );
      return null;
    }

    const existingProfile = await productReviewProfileModel.findOne({
      productId: productData.productId,
    });

    if (existingProfile) {
      console.log(
        `Product review profile already exists for ${productData.productId}`
      );
      return existingProfile;
    }

    const productProfile = new productReviewProfileModel({
      productId: productData.productId,
      sellerId: productData.seller,
      averageRating: 0,
      totalReviews: 0,
    });

    await productProfile.save();
    console.log(`Created product review profile for ${productData.productId}`);
    return productProfile;
  } catch (error) {
    console.error(
      `Error creating product review profile for ${productData.productId}:`,
      error
    );
    throw error;
  }
}

async function createSellerReviewProfile(sellerId) {
  try {
    const existingProfile = await sellerReviewProfileModel.findOne({
      sellerId,
    });

    if (existingProfile) {
      console.log(`Seller review profile already exists for ${sellerId}`);
      return existingProfile;
    }

    const sellerProfile = new sellerReviewProfileModel({
      sellerId,
      averageRating: 0,
      totalReviews: 0,
    });

    await sellerProfile.save();
    console.log(`Created seller review profile for ${sellerId}`);
    return sellerProfile;
  } catch (error) {
    console.error(
      `Error creating seller review profile for ${sellerId}:`,
      error
    );
    throw error;
  }
}

async function updateProductCache(productData) {
  try {
    const cacheData = {
      productId: productData.productId,
      name: productData.name,
      pictures: productData.pictures || [],
      seller: productData.seller,
      lastUpdated: new Date(),
    };

    await ProductCache.findOneAndUpdate(
      { productId: productData.productId },
      cacheData,
      { upsert: true, new: true }
    );

    console.log(`Updated product cache for ${productData.productId}`);
  } catch (error) {
    console.error(
      `Error updating product cache for ${productData.productId}:`,
      error
    );
  }
}

async function deleteProductCache(productId) {
  try {
    const result = await ProductCache.findOneAndDelete({ productId });
    if (result) {
      console.log(`Deleted product cache for ${productId}`);
    } else {
      console.log(`Product cache not found for ${productId}`);
    }
  } catch (error) {
    console.error(`Error deleting product cache for ${productId}:`, error);
  }
}

async function deleteProductReviewProfile(productId) {
  try {
    const result = await productReviewProfileModel.findOneAndDelete({
      productId,
    });
    if (result) {
      console.log(`Deleted product review profile for ${productId}`);
    } else {
      console.log(`Product review profile not found for ${productId}`);
    }
  } catch (error) {
    console.error(
      `Error deleting product review profile for ${productId}:`,
      error
    );
  }
}
