import express from "express";
import ReviewController from "../controllers/reviewController.js";
import userAuth from "../middleware/userAuth.js";

const reviewRouter = express.Router();

// Public routes
reviewRouter.get("/product/:productId", ReviewController.getProductReviews);
reviewRouter.get(
  "/product/:productId/count",
  ReviewController.getProductReviewCount
);
reviewRouter.get(
  "/product/:productId/count-simple",
  ReviewController.getSimpleProductReviewCount
);
reviewRouter.get("/seller/:sellerId", ReviewController.getSellerReviews);


// Protected routes
reviewRouter.post("/", userAuth, ReviewController.createReview);
reviewRouter.get("/eligibility", userAuth, ReviewController.getEligibleReviews);
reviewRouter.get("/user", userAuth, ReviewController.getUserReviews);

// Add these two missing routes
reviewRouter.put("/:reviewId", userAuth, ReviewController.updateReview);
reviewRouter.delete("/:reviewId", userAuth, ReviewController.deleteReview);

export default reviewRouter;
