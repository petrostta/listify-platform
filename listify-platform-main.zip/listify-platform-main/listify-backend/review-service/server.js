import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { connectDB } from "./config/db.js";
import reviewRouter from "./routes/reviewRoutes.js";
import { connectEventListeners } from "./utils/eventListener.js";
import { connectReviewMQ } from "./utils/eventPublisher.js"; // Add this import

dotenv.config();

const app = express();
const port = process.env.PORT || 7000;

app.use(express.json());

connectDB();

connectEventListeners().catch((err) => {
  console.error("Failed to set up event listeners:", err);
});

connectReviewMQ().catch((err) => {
  console.error("Failed to connect review publishing MQ:", err);
});

app.use("/api/reviews", reviewRouter);

app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

app.listen(port, () => {
  console.log(`Review service running on port ${port}`);
  console.log("Review event publishing enabled");
});
