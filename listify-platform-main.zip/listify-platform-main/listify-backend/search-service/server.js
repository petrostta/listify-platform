import searchRoutes from "./routes/searchRoutes.js";
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { connectRabbitMQ } from "./service/searchService.js";
import esClient from "./config/esClient.js";
import setupElasticsearchIndices from "./config/setupElasticsearch.js";

dotenv.config();

const app = express();
const port = process.env.PORT || 3002;

app.use(express.json());

// Health check endpoint
app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

async function cleanupElasticsearchIndices() {
  try {
    console.log("Checking for duplicate Elasticsearch indices...");

    const productsExists = await esClient.indices.exists({ index: "products" });
    const productsNewExists = await esClient.indices.exists({
      index: "products_new",
    });

    if (productsExists.body && productsNewExists.body) {
      console.log(
        "Found both 'products' and 'products_new' indices. Cleaning up..."
      );

      const productsCount = await esClient.count({ index: "products" });
      const productsNewCount = await esClient.count({ index: "products_new" });

      console.log(`products index: ${productsCount.body.count} documents`);
      console.log(
        `products_new index: ${productsNewCount.body.count} documents`
      );

      if (productsNewCount.body.count > productsCount.body.count) {
        console.log(
          "products_new has more documents - keeping it as the primary index"
        );

        await esClient.indices.delete({ index: "products" });

        await esClient.indices.create({
          index: "products",
          body: {
            aliases: {
              products_alias: {},
            },
            settings: (
              await esClient.indices.getSettings({ index: "products_new" })
            ).body.products_new.settings,
          },
        });

        await esClient.reindex({
          body: {
            source: { index: "products_new" },
            dest: { index: "products" },
          },
          refresh: true,
          timeout: "5m",
        });

        await esClient.indices.delete({ index: "products_new" });
      } else {
        console.log(
          "products has more documents or equal count - keeping it and removing products_new"
        );
        await esClient.indices.delete({ index: "products_new" });
      }

      console.log("Duplicate index cleanup complete!");
    } else {
      console.log(
        "No duplicate indices found, continuing with normal startup."
      );
    }
  } catch (error) {
    console.error("Error during index cleanup:", error);
  }
}

const init = async () => {
  try {
    await esClient.ping();
    console.log("Successfully connected to Elasticsearch");

    await cleanupElasticsearchIndices();

    await setupElasticsearchIndices();
    console.log("Elasticsearch setup completed successfully!");

    await connectRabbitMQ();

    app.use("/api/search", searchRoutes);

    app.listen(port, () => {
      console.log(`Search service listening at http://localhost:${port}`);
    });
  } catch (err) {
    console.error("Initialization error:", err);
    process.exit(1);
  }
};

init();
