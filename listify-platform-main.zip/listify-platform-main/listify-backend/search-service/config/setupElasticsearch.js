import esClient from "./esClient.js";
import synonyms from "./synonyms.js";

const setupElasticsearchIndices = async () => {
  try {
    let indexExists = false;
    let aliasExists = false;

    try {
      indexExists = (await esClient.indices.exists({ index: "products" })).body;
      aliasExists = (
        await esClient.indices.existsAlias({ name: "products_alias" })
      ).body;
    } catch (err) {
      console.log("Error checking indices:", err.message);
    }

    if (indexExists) {
      console.log("Products index already exists");

      if (!aliasExists) {
        console.log("Creating products_alias pointing to products index");
        await esClient.indices.putAlias({
          index: "products",
          name: "products_alias",
        });
      }
      return;
    }

    console.log("Creating products index with optimized mappings...");

    await esClient.indices.create({
      index: "products",
      body: {
        settings: {
          number_of_shards: 1,
          number_of_replicas: 1,
          "index.mapping.coerce": false,
          analysis: {
            analyzer: {
              ngram_analyzer: {
                type: "custom",
                tokenizer: "standard",
                filter: ["lowercase", "asciifolding", "ngram_filter"],
              },
              edge_ngram_analyzer: {
                type: "custom",
                tokenizer: "standard",
                filter: ["lowercase", "asciifolding", "edge_ngram_filter"],
              },
              synonym_analyzer: {
                tokenizer: "standard",
                filter: ["lowercase", "asciifolding", "synonym_filter"],
              },
            },
            filter: {
              ngram_filter: {
                type: "ngram",
                min_gram: 3,
                max_gram: 4,
              },
              edge_ngram_filter: {
                type: "edge_ngram",
                min_gram: 2,
                max_gram: 20,
              },
              synonym_filter: {
                type: "synonym",
                synonyms: synonyms || [
                  "laptop, notebook, computer",
                  "phone, smartphone, mobile",
                  "tv, television",
                  "headphone, earphone, earbud",
                  "discount, sale, deal",
                ],
              },
            },
          },
        },
        mappings: {
          properties: {
            uuid: { type: "keyword" },
            name: {
              type: "text",
              analyzer: "standard",
              fields: {
                keyword: { type: "keyword" },
                ngram: { type: "text", analyzer: "ngram_analyzer" },
                edge_ngram: { type: "text", analyzer: "edge_ngram_analyzer" },
                synonym: { type: "text", analyzer: "synonym_analyzer" },
              },
            },
            description: {
              type: "text",
              analyzer: "standard",
              fields: {
                synonym: { type: "text", analyzer: "synonym_analyzer" },
              },
            },
            price: { type: "double" },
            original_price: { type: "double" },
            discount: { type: "double" },
            stock: { type: "integer" },
            isAvailable: { type: "boolean" },
            category: {
              type: "text",
              fields: {
                keyword: { type: "keyword" },
                synonym: { type: "text", analyzer: "synonym_analyzer" },
              },
            },
            variants: {
              type: "nested",
              properties: {
                uuid: { type: "keyword" },
                name: { type: "text" },
                price: { type: "double" },
                stock: { type: "integer" },
                attributes: {
                  type: "object",
                  enabled: true,
                },
              },
            },
            attributes: {
              type: "object",
              enabled: true,
            },
            variantAttributes: {
              type: "keyword",
            },
            pictures: {
              type: "nested",
              properties: {
                key: { type: "keyword" },
                url: { type: "keyword" },
                altText: { type: "text" },
                _id: { type: "keyword" },
              },
            },
            seller: {
              properties: {
                id: { type: "keyword" },
                name: { type: "text" },
              },
            },
            rating: { type: "float" },
            reviewCount: { type: "integer" },
            createdAt: {
              type: "date",
              format: "strict_date_optional_time||epoch_millis",
            },
            updatedAt: {
              type: "date",
              format: "strict_date_optional_time||epoch_millis",
            },
            indexed_at: {
              type: "date",
              format: "strict_date_optional_time||epoch_millis",
            },
            popularity_score: { type: "float" },
          },
        },
      },
    });

    await esClient.indices.putAlias({
      index: "products",
      name: "products_alias",
    });

    console.log("Products index and alias created successfully");
  } catch (error) {
    console.error("Error setting up Elasticsearch indices:", error);
    throw error;
  }
};

export default setupElasticsearchIndices;
