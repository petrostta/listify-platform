import express from "express";
import searchController from "../controllers/searchController.js";

const searchRouter = express.Router();
searchRouter.get("/search", searchController.searchProducts);
searchRouter.get("/suggestions", searchController.getSuggestions);
export default searchRouter;
