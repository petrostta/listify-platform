import esClient from "../config/esClient.js";
import setupElasticsearchIndices from "../config/setupElasticsearch.js";
import dotenv from "dotenv";

dotenv.config();

async function recreateIndex() {
  try {
    console.log("Checking Elasticsearch connection...");
    await esClient.ping();
    console.log("Connected to Elasticsearch");

    const indexExists = (await esClient.indices.exists({ index: "products" }))
      .body;
    console.log("Index exists:", indexExists);

    if (indexExists) {
      console.log("Products index already exists");
      const response = await esClient.count({ index: "products" });
      console.log(`Current document count: ${response.body.count}`);
      return;
    }

    console.log("Creating products index...");
    await setupElasticsearchIndices();
    console.log("Products index created successfully!");

    const newIndexExists = (
      await esClient.indices.exists({ index: "products" })
    ).body;
    if (newIndexExists) {
      console.log("Index verification successful");
    } else {
      console.error("Index creation failed");
    }
  } catch (error) {
    console.error("Error recreating index:", error);
    if (error.meta?.body) {
      console.error(
        "ES Error details:",
        JSON.stringify(error.meta.body, null, 2)
      );
    }
  }
}

recreateIndex()
  .then(() => {
    console.log("Script completed");
    process.exit(0);
  })
  .catch((err) => {
    console.error("Script failed:", err);
    process.exit(1);
  });
