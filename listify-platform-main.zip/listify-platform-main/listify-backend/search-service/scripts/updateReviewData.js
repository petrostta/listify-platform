import esClient from "../config/esClient.js";
import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

async function updateAllProductReviews() {
  try {
    console.log("Starting review data migration for all products...");

    // Get all products from Elasticsearch
    const { body } = await esClient.search({
      index: "products",
      body: {
        query: { match_all: {} },
        _source: ["uuid"],
        size: 1000,
      },
    });

    const products = body.hits.hits;
    console.log(`Found ${products.length} products to update with review data`);

    let successCount = 0;
    let errorCount = 0;
    let skippedCount = 0;

    // Process each product
    for (let i = 0; i < products.length; i += 10) {
      const batch = products.slice(i, i + 10);

      console.log(
        `Processing batch ${i / 10 + 1} of ${Math.ceil(products.length / 10)}`
      );

      // Process batch with Promise.all for parallel execution
      const batchResults = await Promise.allSettled(
        batch.map(async (product) => {
          const productId = product._source.uuid;

          try {
            // Get review data from review service
            const reviewResponse = await axios.get(
              `http://nginx-proxy/api/reviews/product/${productId}/count-simple`,
              { timeout: 3000 }
            );

            if (
              !reviewResponse.data ||
              (reviewResponse.data.count === 0 &&
                reviewResponse.data.averageRating === 0)
            ) {
              skippedCount++;
              console.log(
                `Product ${productId}: No review data available (skipping)`
              );
              return;
            }

            // Update the product with review data
            await esClient.update({
              index: "products", // Use your actual index name
              id: productId,
              body: {
                doc: {
                  rating: reviewResponse.data.averageRating || 0,
                  reviewCount: reviewResponse.data.count || 0,
                  updated_at: new Date().toISOString(),
                },
              },
            });

            successCount++;
            console.log(
              `Updated product ${productId}: ${reviewResponse.data.averageRating}★ (${reviewResponse.data.count} reviews)`
            );
          } catch (error) {
            errorCount++;
            console.error(
              `Error updating review data for product ${productId}:`,
              error.message
            );
          }
        })
      );

      // small delay between batches to prevent overloading the service
      if (i + 10 < products.length) {
        console.log("Waiting 500ms before next batch...");
        await new Promise((resolve) => setTimeout(resolve, 500));
      }
    }

    console.log(`
    
    `);
  } catch (error) {
    console.error("Migration failed:", error);
  }
}

// Run the migration
updateAllProductReviews()
  .then(() => {
    console.log("Migration script completed");
    process.exit(0);
  })
  .catch((err) => {
    console.error("Migration script failed:", err);
    process.exit(1);
  });
