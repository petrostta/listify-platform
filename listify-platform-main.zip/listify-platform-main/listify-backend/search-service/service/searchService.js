import amqp from "amqplib";
import dotenv from "dotenv";
import esClient from "../config/esClient.js";
import redis from "../config/redis.js";

dotenv.config();

let channel;
let connection;
const exchangeName = "product_data_events";

export const connectRabbitMQ = async (retries = 5, delay = 2000) => {
  let attempt = 0;
  while (attempt < retries) {
    try {
      console.log(
        `Connecting to RabbitMQ (attempt ${attempt + 1}/${retries})...`
      );
      connection = await amqp.connect(process.env.RABBITMQ_URI);

      connection.on("error", (err) => {
        console.error("RabbitMQ connection error:", err.message);
      });

      connection.on("close", () => {
        console.warn(
          "RabbitMQ connection closed unexpectedly, will attempt to reconnect..."
        );
        setTimeout(() => connectRabbitMQ(), 5000);
      });

      channel = await connection.createChannel();

      await channel.assertExchange(exchangeName, "topic", { durable: true });
      const { queue } = await channel.assertQueue(
        "search_service_product_queue",
        { durable: true }
      );

      await channel.bindQueue(queue, exchangeName, "PRODUCT_CREATED");
      await channel.bindQueue(queue, exchangeName, "PRODUCT_UPDATED");
      await channel.bindQueue(queue, exchangeName, "PRODUCT_DELETED");

      console.log("Listening for product events");

      channel.consume(queue, async (msg) => {
        try {
          const event = JSON.parse(msg.content.toString());

          if (!event?.type || !event.productId) {
            console.warn("Ignoring malformed event:", event);
            channel.ack(msg);
            return;
          }

          console.log(
            `Processing ${event.type} event for product ${event.productId}`
          );
          await handleProductEvent(event);
          console.log(
            `Successfully processed ${event.type} event for product ${event.productId}`
          );
          channel.ack(msg);
        } catch (err) {
          console.error("Error processing message:", err);
          channel.ack(msg);
        }
      });

      await setupReviewEventListener();

      return;
    } catch (err) {
      attempt++;
      console.error(
        `RabbitMQ connect failed (attempt ${attempt}/${retries}):`,
        err.message
      );

      if (attempt < retries) {
        console.log(`Retrying connection in ${delay / 1000} seconds...`);
        await new Promise((r) => setTimeout(r, delay));
        delay *= 2;
      } else {
        console.error(
          "Could not connect to RabbitMQ after multiple attempts, exiting"
        );
        process.exit(1);
      }
    }
  }
};

const handleProductEvent = async (event) => {
  try {
    let targetIndex = "products";

    try {
      const aliasExists = await esClient.indices.existsAlias({
        name: "products_alias",
      });
      if (aliasExists.body) {
        targetIndex = "products_alias";
      }
    } catch (aliasError) {
      console.warn("Could not check for alias, using default index");
    }

    switch (event.type) {
      case "PRODUCT_CREATED":
      case "PRODUCT_UPDATED":
        console.log(`Processing ${event.type} for product ${event.productId}`);
        console.log("Raw event data:", JSON.stringify(event, null, 2));

        const sellerData =
          typeof event.seller === "string"
            ? { id: event.seller, name: "Unknown Seller" }
            : {
                id:
                  event.seller?.id ||
                  event.seller?.uuid ||
                  event.seller ||
                  "unknown",
                name:
                  event.seller?.name ||
                  event.seller?.businessName ||
                  "Unknown Seller",
              };

        const formatPictures = (pictures) => {
          if (!Array.isArray(pictures)) return [];

          return pictures.map((pic) => ({
            key: String(pic.key || pic._id || ""),
            url: String(pic.url || ""),
            altText: String(pic.altText || pic.alt || ""),
            _id: String(pic._id || pic.id || ""),
            isMain: Boolean(pic.isMain || false),
          }));
        };

        const formatVariants = (variants) => {
          if (!Array.isArray(variants)) return [];

          return variants.map((variant) => ({
            uuid: String(variant.uuid || variant.id || ""),
            name: String(variant.name || ""),
            description: String(variant.description || ""),
            price: parseFloat(variant.price) || 0,
            original_price: parseInt(variant.original_price) || 0,
            discount: parseInt(variant.discount) || 0,
            stock: parseInt(variant.stock) || 0,
            attributes: Array.isArray(variant.attributes)
              ? variant.attributes.map((attr) => ({
                  key: String(attr.key || ""),
                  value: String(attr.value || ""),
                }))
              : {},
            pictures: formatPictures(variant.pictures || []),
          }));
        };

        const formatAttributes = (attributes) => {
          if (Array.isArray(attributes)) {
            const attrObj = {};
            attributes.forEach((attr) => {
              if (attr.key && attr.value) {
                attrObj[attr.key] = attr.value;
              }
            });
            return attrObj;
          }
          return attributes || {};
        };

        const indexDocument = {
          uuid: String(event.productId),
          name: String(event.name || "Untitled Product"),
          description: String(event.description || ""),
          category: String(event.category || "General"),

          original_price: parseFloat(event.original_price) || 0,
          price: parseFloat(event.price || event.original_price) || 0,
          discount: parseFloat(event.discount) || 0,
          stock: parseInt(event.stock) || 0,

          isAvailable: Boolean(event.isAvailable !== false),

          pictures: formatPictures(event.pictures),
          variants: formatVariants(event.variants),

          attributes: formatAttributes(event.attributes),

          variantAttributes: Array.isArray(event.variantAttributes)
            ? event.variantAttributes.map((attr) => String(attr))
            : [],

          seller: sellerData,

          rating: 0,
          reviewCount: 0,

          createdAt: event.createdAt
            ? new Date(event.createdAt).toISOString()
            : new Date().toISOString(),
          updatedAt: event.updatedAt
            ? new Date(event.updatedAt).toISOString()
            : new Date().toISOString(),
          indexed_at: new Date().toISOString(),

          popularity_score: parseFloat(event.popularity_score) || 0,
        };

        console.log(
          "Formatted document for indexing:",
          JSON.stringify(indexDocument, null, 2)
        );

        await esClient.index({
          index: targetIndex,
          id: event.productId,
          body: indexDocument,
        });

        console.log(
          `${event.type} - Successfully indexed product ${event.productId} in ${targetIndex}`
        );
        break;

      case "PRODUCT_DELETED":
        try {
          await esClient.delete({
            index: targetIndex,
            id: event.productId,
          });
          console.log(
            `PRODUCT_DELETED - Removed product ${event.productId} from ${targetIndex}`
          );
        } catch (deleteError) {
          if (deleteError.meta?.statusCode === 404) {
            console.log(
              `Product ${event.productId} not found in index (already deleted)`
            );
          } else {
            throw deleteError;
          }
        }
        break;

      default:
        console.warn(`Unhandled event type: ${event.type}`);
    }

    await clearSearchCache(event.productId);
  } catch (error) {
    console.error(
      `Error handling ${event.type} event for product ${event.productId}:`,
      error
    );

    if (error.meta?.body?.error) {
      console.error(
        "Elasticsearch error details:",
        JSON.stringify(error.meta.body.error, null, 2)
      );
      console.error("Error type:", error.meta.body.error.type);
      console.error("Error reason:", error.meta.body.error.reason);

      if (error.meta.body.error.caused_by) {
        console.error(
          "Caused by:",
          JSON.stringify(error.meta.body.error.caused_by, null, 2)
        );
      }
    }

    throw error;
  }
};

const setupReviewEventListener = async () => {
  try {
    if (!channel) {
      console.warn("Cannot set up review event listener - no RabbitMQ channel");
      return;
    }

    const reviewExchange = "review_events";
    await channel.assertExchange(reviewExchange, "topic", { durable: true });

    const { queue } = await channel.assertQueue("search-service-review-queue", {
      durable: true,
    });

    await channel.bindQueue(queue, reviewExchange, "REVIEW_CREATED");
    await channel.bindQueue(queue, reviewExchange, "REVIEW_UPDATED");
    await channel.bindQueue(queue, reviewExchange, "REVIEW_DELETED");

    console.log("Listening for review events to update product ratings");

    channel.consume(queue, async (msg) => {
      if (!msg) return;

      try {
        const event = JSON.parse(msg.content.toString());
        if (!event?.productId) {
          channel.ack(msg);
          return;
        }

        console.log(`Processing review event for product ${event.productId}`);
        const reviewData = {
          averageRating: event.averageRating || 0,
          count: event.reviewCount || 0,
        };

        await esClient.update({
          index: "products_alias",
          id: event.productId,
          body: {
            doc: {
              rating: reviewData.averageRating,
              reviewCount: reviewData.count,
              updated_at: new Date().toISOString(),
            },
          },
        });

        console.log(
          `Updated review data for product ${event.productId} in search index`
        );
        await clearSearchCache(event.productId);

        channel.ack(msg);
      } catch (error) {
        console.error("Error processing review event:", error);
        channel.ack(msg);
      }
    });
  } catch (error) {
    console.error("Failed to set up review event listener:", error);
  }
};

const clearSearchCache = async (uuid) => {
  try {
    console.log(`Clearing search cache for product ${uuid}`);

    const searchKeys = await redis.keys("search:*");
    if (searchKeys.length) {
      await redis.del(searchKeys);
      console.log(`Cleared ${searchKeys.length} search cache keys`);
    }

    const suggestionKeys = await redis.keys("suggestions:*");
    if (suggestionKeys.length) {
      await redis.del(suggestionKeys);
      console.log(`Cleared ${suggestionKeys.length} suggestion cache keys`);
    }
  } catch (err) {
    console.warn("Could not clear cache:", err);
  }
};

export { handleProductEvent, clearSearchCache, setupReviewEventListener };
