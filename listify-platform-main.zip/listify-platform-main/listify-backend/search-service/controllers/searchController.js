import esClient from "../config/esClient.js";
import redis from "../config/redis.js";
import crypto from "crypto";

// Generate cache key for search queries
const generateCacheKey = (params) => {
  const normalizedParams = {
    q: params.q || "",
    category: params.category || "",
    minPrice: params.minPrice || "",
    maxPrice: params.maxPrice || "",
    sortField: params.sortField || "price",
    sortOrder: params.sortOrder || "desc",
    page: parseInt(params.page) || 1,
    limit: parseInt(params.limit) || 10,
  };

  const paramsString = JSON.stringify(normalizedParams);
  return `search:${crypto
    .createHash("md5")
    .update(paramsString)
    .digest("hex")}`;
};

// Validate search parameters
const validateSearchParams = (params) => {
  const errors = [];
  const validSortFields = [
    "price",
    "name",
    "createdAt",
    "rating",
    "original_price",
    "discount",
    "reviewCount",
  ];
  const validSortOrders = ["asc", "desc"];

  if (params.sortField && !validSortFields.includes(params.sortField)) {
    errors.push(`Invalid sort field: ${params.sortField}`);
  }

  if (params.sortOrder && !validSortOrders.includes(params.sortOrder)) {
    errors.push(`Invalid sort order: ${params.sortOrder}`);
  }

  if (params.minPrice && isNaN(parseFloat(params.minPrice))) {
    errors.push("Minimum price must be a number");
  }

  if (params.maxPrice && isNaN(parseFloat(params.maxPrice))) {
    errors.push("Maximum price must be a number");
  }

  if (
    params.page &&
    (isNaN(parseInt(params.page)) || parseInt(params.page) < 1)
  ) {
    errors.push("Page must be a positive integer");
  }

  if (
    params.limit &&
    (isNaN(parseInt(params.limit)) ||
      parseInt(params.limit) < 1 ||
      parseInt(params.limit) > 100)
  ) {
    errors.push("Limit must be between 1 and 100");
  }

  return errors;
};

// Build Elasticsearch query - FIXED to use synonym fields
const buildSearchQuery = (q, filters = {}) => {
  const esQuery = {
    bool: {
      must: [],
      filter: [],
      should: [],
      minimum_should_match: q ? 1 : 0,
    },
  };

  if (q) {
    esQuery.bool.should.push(
      { match: { name: { query: q, boost: 4 } } },
      { match_phrase_prefix: { name: { query: q, boost: 5 } } },

      { match: { "name.synonym": { query: q, boost: 3 } } },
      { match: { "description.synonym": { query: q, boost: 1.5 } } },
      { match: { "category.synonym": { query: q, boost: 2.5 } } }
    );
  } else {
    esQuery.bool.must.push({ match_all: {} });
  }

  // Add category filter
  if (filters.category) {
    if (filters.category.includes(",")) {
      const categories = filters.category
        .split(",")
        .map((c) => c.trim())
        .filter(Boolean);
      esQuery.bool.filter.push({
        bool: {
          should: [
            { terms: { "category.keyword": categories } },
            { terms: { category: categories } },
          ],
          minimum_should_match: 1,
        },
      });
    } else {
      esQuery.bool.filter.push({
        bool: {
          should: [
            { term: { "category.keyword": filters.category } },
            { match: { category: filters.category } },
          ],
          minimum_should_match: 1,
        },
      });
    }
  }

  // Add price range filter that accounts for discounts
  if (filters.minPrice || filters.maxPrice) {
    const scriptFilter = {
      script: {
        script: {
          source:
            "double final_price = doc['original_price'].value * (1 - (doc['discount'].value / 100)); return final_price >= params.min && final_price <= params.max",
          params: {
            min: filters.minPrice ? parseFloat(filters.minPrice) : 0,
            max: filters.maxPrice ? parseFloat(filters.maxPrice) : 100000,
          },
        },
      },
    };
    esQuery.bool.filter.push(scriptFilter);
  }

  // availability filter
  if (filters.isAvailable !== undefined) {
    esQuery.bool.filter.push({
      term: { isAvailable: filters.isAvailable === "true" },
    });
  }

  return esQuery;
};

// relevance boosting
const applyRelevanceBoost = (baseQuery) => {
  return {
    function_score: {
      query: baseQuery,
      functions: [
        { filter: { exists: { field: "discount" } }, weight: 1.2 },
        {
          field_value_factor: {
            field: "stock",
            factor: 0.001,
            modifier: "log1p",
            missing: 1,
          },
        },
        {
          field_value_factor: {
            field: "reviewCount",
            factor: 0.1,
            modifier: "log1p",
            missing: 1,
          },
        },
        {
          filter: { range: { indexed_at: { gte: "now-30d/d" } } },
          weight: 1.05,
        },
      ],
      score_mode: "sum",
      boost_mode: "multiply",
    },
  };
};

// Search products endpoint
const searchProducts = async (req, res) => {
  try {
    const {
      q,
      category,
      minPrice,
      maxPrice,
      sortField,
      sortOrder,
      page,
      limit,
      all,
    } = req.query;

    // Validate parameters
    const validationErrors = validateSearchParams(req.query);
    if (validationErrors.length > 0) {
      return res.status(400).json({ success: false, errors: validationErrors });
    }

    const hasQuery = q || category || all === "true";
    if (!hasQuery) {
      return res.status(400).json({
        success: false,
        message: "Please provide a search query, category, or 'all' parameter",
      });
    }

    // Build query
    let esQuery = buildSearchQuery(q, {
      category,
      minPrice,
      maxPrice,
      isAvailable: "true",
    });
    esQuery = applyRelevanceBoost(esQuery);

    // Setup pagination
    const currentPage = parseInt(page) || 1;
    const itemsPerPage = parseInt(limit) || 12;
    const from = (currentPage - 1) * itemsPerPage;

    // Handle sorting
    let sort;
    if (sortField === "price") {
      sort = [
        {
          _script: {
            type: "number",
            script: {
              source:
                "doc['original_price'].value * (1 - (doc['discount'].value / 100))",
              lang: "painless",
            },
            order: sortOrder || "desc",
          },
        },
      ];
    } else {
      const fieldMapping = {
        name: "name.keyword",
        createdAt: "createdAt",
        rating: "rating",
        discount: "discount",
        reviewCount: "reviewCount",
        original_price: "original_price",
      };

      const esSortField = fieldMapping[sortField] || "rating";
      sort = [{ [esSortField]: { order: sortOrder || "desc" } }];
    }

    const { body } = await esClient.search({
      index: "products",
      body: {
        query: esQuery,
        sort,
        from,
        size: itemsPerPage,
      },
    });

    const products = body.hits.hits.map((hit) => {
      const product = { ...hit._source };

      product.rating = product.rating || 0;
      product.reviewCount = product.reviewCount || 0;

      product.relevanceScore = hit._score;

      return product;
    });

    const total = body.hits.total.value;
    const totalPages = Math.ceil(total / itemsPerPage);

    const response = {
      success: true,
      products,
      pagination: {
        page: currentPage,
        limit: itemsPerPage,
        total,
        pages: totalPages,
      },
    };

    return res.json(response);
  } catch (error) {
    console.error("Search error:", error);

    if (error.meta?.body?.error?.type) {
      return res.status(400).json({
        success: false,
        message: "Invalid search query",
        error: error.meta.body.error.type,
      });
    }

    res.status(500).json({
      success: false,
      message: "An error occurred while processing your search",
    });
  }
};

// Get search suggestions for autocomplete
const getSuggestions = async (req, res) => {
  try {
    const { q } = req.query;
    if (!q) return res.json([]);

    const cacheKey = `suggestions:${q.toLowerCase()}`;
    const cachedSuggestions = await redis.get(cacheKey);
    if (cachedSuggestions) {
      return res.json(JSON.parse(cachedSuggestions));
    }

    const { body } = await esClient.search({
      index: "products",
      body: {
        query: {
          bool: {
            should: [
              { prefix: { name: { value: q, boost: 10 } } },
              { prefix: { "name.synonym": { value: q, boost: 8 } } },
              { fuzzy: { name: { value: q, fuzziness: "AUTO", boost: 5 } } },
              ...(q.length < 4
                ? [{ wildcard: { name: { value: `*${q}*`, boost: 2 } } }]
                : []),
            ],
            minimum_should_match: 1,
          },
        },
        size: 5,
      },
    });

    const suggestions = body.hits.hits.map((hit) => hit._source.name);

    await redis.setex(cacheKey, 900, JSON.stringify(suggestions));

    res.json(suggestions);
  } catch (error) {
    console.error("Suggestions error:", error);
    res.status(500).json({ message: "Error fetching suggestions" });
  }
};

export default {
  searchProducts,
  getSuggestions,
};
