import { EventEmitter } from "events";
import amqplib from "amqplib";
import Order from "../models/order.js";
import redis from "../config/redis.js";

class OrderSaga extends EventEmitter {
  constructor() {
    super();
    this.channel = null;
    this.connection = null;
    this.sagaStates = new Map();
    this.initialize();
  }

  async initialize() {
    await this.setupEventListeners();
  }

  async setupEventListeners() {
    try {
      this.connection = await amqplib.connect(process.env.RABBITMQ_URL);

      this.connection.on("error", (err) => {
        console.error("Order Saga RabbitMQ connection error:", err.message);
      });

      this.connection.on("close", () => {
        console.warn(
          "Order Saga RabbitMQ connection closed, attempting to reconnect..."
        );
        setTimeout(() => this.setupEventListeners(), 5000);
      });

      this.channel = await this.connection.createChannel();
      await this.setupInventoryEventListeners();
      await this.setupPaymentEventListeners();

      console.log(
        "Order saga event listeners connected with enhanced choreography"
      );
    } catch (error) {
      console.error("Error setting up order saga listeners:", error);
      setTimeout(() => this.setupEventListeners(), 5000);
    }
  }

  async setupInventoryEventListeners() {
    await this.channel.assertExchange("inventory_events", "topic", {
      durable: true,
    });

    const { queue } = await this.channel.assertQueue(
      "order_saga_inventory_queue",
      { durable: true, arguments: { "x-message-ttl": 300000 } }
    );

    const routingKeys = [
      "INVENTORY_RESERVED",
      "INVENTORY_RESERVATION_FAILED",
      "INVENTORY_RELEASED",
    ];

    for (const routingKey of routingKeys) {
      await this.channel.bindQueue(queue, "inventory_events", routingKey);
    }

    this.channel.consume(
      queue,
      async (msg) => {
        if (!msg) return;

        try {
          const event = JSON.parse(msg.content.toString());
          await this.handleInventoryEvent(event);
          this.channel.ack(msg);
        } catch (error) {
          console.error("Error processing inventory event:", error);
          this.channel.nack(msg, false, false);
        }
      },
      { prefetch: 10 }
    );
  }

  async setupPaymentEventListeners() {
    await this.channel.assertExchange("payment_events", "topic", {
      durable: true,
    });

    const paymentQueue = await this.channel.assertQueue(
      "order_saga_payment_queue",
      { durable: true, arguments: { "x-message-ttl": 300000 } }
    );

    const paymentRoutingKeys = [
      "PAYMENT_SUCCESSFUL",
      "PAYMENT_FAILED",
      "PAYMENT_REFUNDED",
    ];

    for (const routingKey of paymentRoutingKeys) {
      await this.channel.bindQueue(
        paymentQueue.queue,
        "payment_events",
        routingKey
      );
    }

    this.channel.consume(
      paymentQueue.queue,
      async (msg) => {
        if (!msg) return;

        try {
          const event = JSON.parse(msg.content.toString());
          await this.handlePaymentEvent(event);
          this.channel.ack(msg);
        } catch (error) {
          console.error("Error processing payment event:", error);
          this.channel.nack(msg, false, false);
        }
      },
      { prefetch: 10 }
    );
  }

  async processOrder(orderData) {
    const sagaId = `saga_${orderData.orderId}_${Date.now()}`;

    try {
      this.sagaStates.set(sagaId, {
        orderId: orderData.orderId,
        status: "STARTED",
        steps: [],
        compensations: [],
        pendingReservations: orderData.orderItems.length,
        completedReservations: 0,
        failedReservations: [],
        startTime: Date.now(),
        timeoutMs: 300000,
        retryCount: 0,
        maxRetries: 3,
      });

      console.log(
        `[SAGA:${sagaId}] Starting distributed order processing for ${orderData.orderId}`
      );

      setTimeout(() => this.checkSagaTimeout(sagaId), 300000);

      await this.reserveInventory(sagaId, orderData);
    } catch (error) {
      console.error(`[SAGA:${sagaId}] Error in order saga:`, error);
      await this.compensate(sagaId, orderData, error);
    }
  }

  async checkSagaTimeout(sagaId) {
    const sagaState = this.sagaStates.get(sagaId);
    if (
      sagaState &&
      sagaState.status !== "COMPLETED" &&
      sagaState.status !== "COMPENSATED"
    ) {
      console.warn(
        `[SAGA:${sagaId}] Saga timeout exceeded, initiating compensation`
      );
      await this.compensate(
        sagaId,
        { orderId: sagaState.orderId },
        new Error("Saga timeout")
      );
    }
  }

  async reserveInventory(sagaId, orderData) {
    const sagaState = this.sagaStates.get(sagaId);
    sagaState.status = "RESERVING_INVENTORY";

    console.log(
      `[SAGA:${sagaId}] Publishing inventory reservation events for ${orderData.orderItems.length} items`
    );

    for (const item of orderData.orderItems) {
      const inventoryEvent = {
        type: "INVENTORY_RESERVE_REQUEST",
        productId: item.productId,
        variantId: item.variantId,
        quantity: item.quantity,
        orderId: orderData.orderId,
        sagaId: sagaId,
        timestamp: new Date().toISOString(),
        correlationId: `${sagaId}_${item.productId}`,
      };

      await this.publishSagaEvent(
        "inventory_events",
        "INVENTORY_RESERVE_REQUEST",
        inventoryEvent
      );
    }
  }

  async handleInventoryEvent(event) {
    const sagaId = event.sagaId;
    if (!sagaId || !this.sagaStates.has(sagaId)) {
      console.warn(`Received inventory event for unknown saga: ${sagaId}`);
      return;
    }

    const sagaState = this.sagaStates.get(sagaId);

    switch (event.type) {
      case "INVENTORY_RESERVED":
        console.log(
          `[SAGA:${sagaId}] Inventory reserved for product ${event.productId}`
        );
        sagaState.completedReservations++;
        sagaState.steps.push({
          type: "INVENTORY_RESERVED",
          productId: event.productId,
          variantId: event.variantId,
          quantity: event.quantity,
          timestamp: new Date().toISOString(),
        });

        if (sagaState.completedReservations === sagaState.pendingReservations) {
          console.log(
            `[SAGA:${sagaId}] All inventory reserved, completing reservation phase`
          );
          await this.completeInventoryReservation(sagaId, sagaState.orderId);
        }
        break;

      case "INVENTORY_RESERVATION_FAILED":
        console.log(
          `[SAGA:${sagaId}] Inventory reservation failed for product ${event.productId}: ${event.reason}`
        );
        sagaState.failedReservations.push({
          productId: event.productId,
          variantId: event.variantId,
          reason: event.reason,
          timestamp: new Date().toISOString(),
        });

        if (
          this.isRetryableError(event.reason) &&
          sagaState.retryCount < sagaState.maxRetries
        ) {
          await this.retryInventoryReservation(sagaId, event);
        } else {
          await this.compensate(
            sagaId,
            { orderId: sagaState.orderId },
            new Error(event.reason)
          );
        }
        break;

      case "INVENTORY_RELEASED":
        console.log(
          `[SAGA:${sagaId}] Inventory released for product ${event.productId}`
        );
        break;
    }
  }

  isRetryableError(reason) {
    const retryableErrors = [
      "temporary_unavailable",
      "database_timeout",
      "network_error",
    ];
    return retryableErrors.some((error) =>
      reason.toLowerCase().includes(error)
    );
  }

  async retryInventoryReservation(sagaId, failedEvent) {
    const sagaState = this.sagaStates.get(sagaId);
    sagaState.retryCount++;

    console.log(
      `[SAGA:${sagaId}] Retrying inventory reservation (attempt ${sagaState.retryCount})`
    );

    const delay = Math.pow(2, sagaState.retryCount) * 1000;
    setTimeout(async () => {
      const retryEvent = {
        ...failedEvent,
        type: "INVENTORY_RESERVE_REQUEST",
        retryAttempt: sagaState.retryCount,
        timestamp: new Date().toISOString(),
      };

      await this.publishSagaEvent(
        "inventory_events",
        "INVENTORY_RESERVE_REQUEST",
        retryEvent
      );
    }, delay);
  }

  async handlePaymentEvent(event) {
    console.log(
      `[SAGA] Received payment event: ${event.type} for order ${event.orderId}`
    );

    if (event.sagaId && this.sagaStates.has(event.sagaId)) {
      const sagaState = this.sagaStates.get(event.sagaId);
      sagaState.steps.push({
        type: event.type,
        timestamp: new Date().toISOString(),
        paymentId: event.paymentId,
      });
    }
  }

  async completeInventoryReservation(sagaId, orderId) {
    try {
      const sagaState = this.sagaStates.get(sagaId);
      sagaState.status = "INVENTORY_COMPLETED";

      await Order.findOneAndUpdate(
        { orderId },
        {
          status: "PAID",
          sagaState: "INVENTORY_UPDATED",
          "sagaMetadata.sagaId": sagaId,
          "sagaMetadata.completedAt": new Date(),
          "sagaMetadata.steps": sagaState.steps,
        },
        { new: true }
      );

      await redis.del(`order:${orderId}`);

      const orderEvent = {
        type: "ORDER_INVENTORY_CONFIRMED",
        orderId: orderId,
        sagaId: sagaId,
        timestamp: new Date().toISOString(),
        totalSteps: sagaState.steps.length,
      };

      await this.publishSagaEvent(
        "order_events",
        "ORDER_INVENTORY_CONFIRMED",
        orderEvent
      );

      sagaState.status = "COMPLETED";
      this.sagaStates.delete(sagaId);

      console.log(
        `[SAGA:${sagaId}] Order ${orderId} saga completed successfully in ${
          Date.now() - sagaState.startTime
        }ms`
      );
    } catch (error) {
      await this.compensate(sagaId, { orderId }, error);
    }
  }

  async compensate(sagaId, orderData, error) {
    try {
      const sagaState = this.sagaStates.get(sagaId);
      if (!sagaState) return;

      console.log(
        `[SAGA:${sagaId}] Starting distributed compensation for order ${orderData.orderId}: ${error.message}`
      );
      sagaState.status = "COMPENSATING";

      const compensationEvents = [];

      for (const step of sagaState.steps) {
        if (step.type === "INVENTORY_RESERVED") {
          const compensationEvent = {
            type: "INVENTORY_RELEASE_REQUEST",
            productId: step.productId,
            variantId: step.variantId,
            quantity: step.quantity,
            orderId: orderData.orderId,
            sagaId: sagaId,
            reason: "saga_compensation",
            originalStep: step,
            timestamp: new Date().toISOString(),
          };

          compensationEvents.push(compensationEvent);
        }
      }

      for (const event of compensationEvents) {
        await this.publishSagaEvent(
          "inventory_events",
          "INVENTORY_RELEASE_REQUEST",
          event
        );
      }

      await Order.findOneAndUpdate(
        { orderId: orderData.orderId },
        {
          status: "FAILED",
          sagaState: "COMPENSATED",
          cancellationReason: error.message,
          "sagaMetadata.sagaId": sagaId,
          "sagaMetadata.compensatedAt": new Date(),
          "sagaMetadata.compensationEvents": compensationEvents.length,
          "sagaMetadata.errorReason": error.message,
        },
        { new: true }
      );

      await redis.del(`order:${orderData.orderId}`);

      this.sagaStates.delete(sagaId);

      console.log(
        `[SAGA:${sagaId}] Order ${orderData.orderId} compensated successfully with ${compensationEvents.length} compensation events`
      );
    } catch (compensationError) {
      console.error(
        `[SAGA:${sagaId}] Error during compensation:`,
        compensationError
      );
    }
  }

  async publishSagaEvent(exchange, routingKey, eventData) {
    if (!this.channel) {
      throw new Error("RabbitMQ channel not available");
    }

    try {
      const enhancedEvent = {
        ...eventData,
        sagaVersion: "2.0",
        correlationId:
          eventData.correlationId || `${eventData.sagaId}_${Date.now()}`,
        source: "order-saga-service",
        eventId: `evt_${Date.now()}_${Math.random()
          .toString(36)
          .substring(2, 11)}`,
      };

      return this.channel.publish(
        exchange,
        routingKey,
        Buffer.from(JSON.stringify(enhancedEvent)),
        {
          persistent: true,
          messageId: enhancedEvent.eventId,
          correlationId: enhancedEvent.correlationId,
          timestamp: Date.now(),
        }
      );
    } catch (error) {
      console.error("Error publishing saga event:", error);
      throw error;
    }
  }

  async callWithCircuitBreaker(serviceName, operation) {
    const circuitState = this.circuitStates.get(serviceName) || {
      failures: 0,
      lastFailure: null,
      state: "CLOSED",
    };

    if (circuitState.state === "OPEN") {
      const timeSinceLastFailure = Date.now() - circuitState.lastFailure;
      if (timeSinceLastFailure < 60000) {
        throw new Error(`Circuit breaker open for ${serviceName}`);
      } else {
        circuitState.state = "HALF_OPEN";
      }
    }

    try {
      const result = await operation();

      if (circuitState.state === "HALF_OPEN") {
        circuitState.state = "CLOSED";
        circuitState.failures = 0;
      }

      this.circuitStates.set(serviceName, circuitState);
      return result;
    } catch (error) {
      circuitState.failures++;
      circuitState.lastFailure = Date.now();

      if (circuitState.failures >= 5) {
        circuitState.state = "OPEN";
      }

      this.circuitStates.set(serviceName, circuitState);
      throw error;
    }
  }
}

export const orderSaga = new OrderSaga();
