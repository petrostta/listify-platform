import amqlib from "amqplib";
import OrderController from "../controllers/orderController.js";
import orderModel from "../models/order.js";
import ProductCache from "../models/productCache.js";
import { publishOrderEvent } from "./eventPublisher.js";

let channel;
let connection;

export const connectEventListeners = async (retries = 5, delay = 2000) => {
  let attempt = 0;
  while (attempt < retries) {
    try {
      console.log(
        `Connecting to RabbitMQ listeners (attempt ${
          attempt + 1
        }/${retries})...`
      );

      connection = await amqlib.connect(process.env.RABBITMQ_URL);

      connection.on("error", (err) => {
        console.error("RabbitMQ listener connection error:", err.message);
      });

      connection.on("close", () => {
        console.warn(
          "RabbitMQ listener connection closed unexpectedly, reconnecting..."
        );
        setTimeout(() => connectEventListeners(), 5000);
      });

      channel = await connection.createChannel();

      await setupCartCheckoutListener(channel);
      await setupPaymentEventListener(channel);
      await setupProductEventListener(channel);

      console.log("Order service event listeners connected successfully");
      return true;
    } catch (error) {
      attempt++;
      console.error(
        `RabbitMQ connection failed (attempt ${attempt}/${retries}):`,
        error.message
      );

      if (channel) {
        try {
          await channel.close();
        } catch (e) {
          console.error("Error closing channel:", e);
        }
        channel = null;
      }

      if (connection) {
        try {
          await connection.close();
        } catch (e) {
          console.error("Error closing connection:", e);
        }
        connection = null;
      }

      if (attempt < retries) {
        console.log(`Retrying in ${delay / 1000} seconds...`);
        await new Promise((res) => setTimeout(res, delay));
        delay *= 2;
      } else {
        console.error("Could not connect to RabbitMQ after multiple attempts");
        return false;
      }
    }
  }
};

async function setupProductEventListener(channel) {
  const exchange = "product_data_events";
  await channel.assertExchange(exchange, "topic", { durable: true });
  const { queue } = await channel.assertQueue("order_service_product_queue", {
    durable: true,
  });

  await channel.bindQueue(queue, exchange, "PRODUCT_CREATED");
  await channel.bindQueue(queue, exchange, "PRODUCT_UPDATED");
  await channel.bindQueue(queue, exchange, "PRODUCT_DELETED");

  channel.consume(queue, async (msg) => {
    try {
      const productData = JSON.parse(msg.content.toString());

      switch (productData.type) {
        case "PRODUCT_CREATED":
        case "PRODUCT_UPDATED":
          await updateProductCache(productData);
          break;
        case "PRODUCT_DELETED":
          await deleteProductCache(productData.productId);
          break;
      }

      channel.ack(msg);
    } catch (error) {
      console.error("Error processing product event:", error);
      channel.ack(msg);
    }
  });
}

async function updateProductCache(productData) {
  try {
    await ProductCache.findOneAndUpdate(
      { productId: productData.productId },
      {
        name: productData.name,
        seller: productData.seller,
        lastUpdated: new Date(),
      },
      { upsert: true }
    );
    console.log(`Updated product cache for ${productData.productId}`);
  } catch (error) {
    console.error("Error updating product cache:", error);
  }
}

async function deleteProductCache(productId) {
  try {
    await ProductCache.findOneAndDelete({ productId });
    console.log(`Deleted product cache for ${productId}`);
  } catch (error) {
    console.error("Error deleting product cache:", error);
  }
}

async function setupCartCheckoutListener(channel) {
  const exchange = "cart_events";
  const routingKey = "EVENT_CART_CHECKOUT";
  const queue = "order_service_checkout_queue";

  await channel.assertExchange(exchange, "topic", { durable: false });
  const { queue: queueName } = await channel.assertQueue(queue, {
    durable: false,
  });
  await channel.bindQueue(queueName, exchange, routingKey);

  console.log(
    `Listening for cart checkout events on ${exchange}/${routingKey}`
  );

  channel.consume(queueName, async (msg) => {
    if (!msg) return;

    try {
      const checkoutEvent = JSON.parse(msg.content.toString());
      const order = await processCartCheckout(checkoutEvent);

      if (order) {
        console.log(`Created order ${order.orderId} from cart checkout`);
      }

      channel.ack(msg);
    } catch (error) {
      console.error("Error processing cart checkout event:", error);
      channel.nack(msg, false, true);
    }
  });
}

async function setupPaymentEventListener(channel) {
  const exchange = "payment_events";
  const routingKey = "#";
  const queue = "order_service_payment_queue";

  await channel.assertExchange(exchange, "topic", { durable: true });
  const { queue: queueName } = await channel.assertQueue(queue, {
    durable: true,
  });
  await channel.bindQueue(queueName, exchange, routingKey);

  console.log(`Listening for payment events on ${exchange}/${routingKey}`);

  channel.consume(queueName, async (msg) => {
    if (!msg) return;

    try {
      const paymentEvent = JSON.parse(msg.content.toString());

      if (paymentEvent.type === "PAYMENT_SUCCESSFUL") {
        await OrderController.processPaymentConfirmation({
          orderId: paymentEvent.orderId,
          paymentId: paymentEvent.paymentId,
          status: "SUCCESSFUL",
        });
      } else if (paymentEvent.type === "PAYMENT_FAILED") {
        await OrderController.processPaymentConfirmation({
          orderId: paymentEvent.orderId,
          paymentId: paymentEvent.paymentId,
          status: "FAILED",
        });
      } else if (paymentEvent.type === "PAYMENT_REFUNDED") {
        const order = await orderModel.findOne({
          orderId: paymentEvent.orderId,
        });

        if (order) {
          order.status = "CANCELLED";
          order.sagaCompensation.paymentRefunded = true;
          order.sagaState = "COMPENSATED";
          await order.save();
        }
      }

      channel.ack(msg);
    } catch (error) {
      console.error("Error processing payment event:", error);
      channel.nack(msg, false, false);
    }
  });
}

async function processCartCheckout(checkoutEvent) {
  try {
    const { uuid, user, sessionId, items, subtotal } = checkoutEvent;

    const shippingInfo = {
      fullName: "Default User",
      addressLine1: "123 Main St",
      city: "Sample City",
      state: "Sample State",
      postalCode: "12345",
      country: "Sample Country",
    };

    const billingInfo = { ...shippingInfo };

    const orderItems = items.map((item) => {
      const orderItem = {
        productId: item.productId,
        name: item.name || `Product ${item.productId}`,
        price: item.price,
        quantity: item.quantity,
      };

      if (
        item.variantId &&
        typeof item.variantId === "string" &&
        item.variantId.trim() !== ""
      ) {
        orderItem.variantId = item.variantId.trim();
      }

      return orderItem;
    });

    const order = new orderModel({
      userId: user || sessionId,
      orderItems,
      shippingInfo,
      billingInfo,
      totalAmount: subtotal,
      status: "PENDING",
      sagaState: "ORDER_CREATED",
      paymentInfo: { status: "PENDING" },
    });

    await order.save();
    await publishOrderEvent("ORDER_CREATED", order);

    return order;
  } catch (error) {
    console.error("Error processing cart checkout:", error);
    return null;
  }
}
