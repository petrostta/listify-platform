import amqplib from "amqplib";
import dotenv from "dotenv";

dotenv.config();

let inventoryChannel;
let inventoryConnection;

export const connectInventoryMQ = async (retries = 5, delay = 2000) => {
  let attempt = 0;
  while (attempt < retries) {
    try {
      console.log(
        `Connecting to RabbitMQ for inventory events (attempt ${
          attempt + 1
        }/${retries})...`
      );

      inventoryConnection = await amqplib.connect(process.env.RABBITMQ_URL);

      inventoryConnection.on("error", (err) => {
        console.error("Inventory RabbitMQ connection error:", err.message);
      });

      inventoryConnection.on("close", () => {
        console.warn(
          "Inventory RabbitMQ connection closed, attempting to reconnect..."
        );
        inventoryChannel = null;
        setTimeout(() => connectInventoryMQ(), 5000);
      });

      inventoryChannel = await inventoryConnection.createChannel();

      await inventoryChannel.assertExchange("inventory_events", "topic", {
        durable: true,
      });

      console.log("Order service connected to RabbitMQ for inventory events");
      return true;
    } catch (error) {
      attempt++;
      console.error(
        `Inventory RabbitMQ connection failed (attempt ${attempt}/${retries}):`,
        error.message
      );

      if (attempt < retries) {
        console.log(`Retrying in ${delay / 1000} seconds...`);
        await new Promise((res) => setTimeout(res, delay));
        delay *= 2;
      } else {
        console.error(
          "Could not connect to inventory RabbitMQ after multiple attempts"
        );
        throw error;
      }
    }
  }
};

export const publishInventoryEvent = async (eventType, inventoryData) => {
  if (!inventoryChannel) {
    console.error(
      "Inventory RabbitMQ channel not available, attempting to connect..."
    );
    try {
      await connectInventoryMQ();
      if (!inventoryChannel) {
        console.error("Failed to establish inventory channel");
        return false;
      }
    } catch (error) {
      console.error("Error connecting to inventory RabbitMQ:", error);
      return false;
    }
  }

  try {
    const eventPayload = {
      type: eventType,
      productId: inventoryData.productId,
      variantId: inventoryData.variantId,
      quantity: inventoryData.quantity,
      orderId: inventoryData.orderId,
      sagaId: inventoryData.sagaId,
      reason: inventoryData.reason,
      timestamp: new Date().toISOString(),
    };

    console.log(
      `Publishing ${eventType} inventory event for product ${inventoryData.productId}`
    );

    const published = inventoryChannel.publish(
      "inventory_events",
      eventType,
      Buffer.from(JSON.stringify(eventPayload)),
      { persistent: true }
    );

    if (published) {
      console.log(
        `Published ${eventType} inventory event for product ${inventoryData.productId}`
      );
      return true;
    } else {
      console.warn(
        `Channel buffer full, ${eventType} inventory event not published`
      );
      return false;
    }
  } catch (error) {
    console.error("Error publishing inventory event:", error);
    return false;
  }
};
