import amqlib from "amqplib";

let channel;
let connection;
const exchangeName = "order_events";

export const connectRabbitMQ = async () => {
  try {
    connection = await amqlib.connect(process.env.RABBITMQ_URL);

    connection.on("error", (err) => {
      console.error("RabbitMQ connection error:", err.message);
      setTimeout(connectRabbitMQ, 5000);
    });

    connection.on("close", () => {
      console.warn("RabbitMQ connection closed, attempting to reconnect...");
      setTimeout(connectRabbitMQ, 5000);
    });

    channel = await connection.createChannel();
    await channel.assertExchange(exchangeName, "topic", { durable: true });
    console.log("Connected to RabbitMQ for order events");
  } catch (error) {
    console.error("RabbitMQ connection failed, retrying in 5s:", error);
    setTimeout(connectRabbitMQ, 5000);
  }
};

export const publishOrderEvent = async (eventType, payload) => {
  if (!channel) {
    console.error("RabbitMQ not connected. Attempting to reconnect...");
    await connectRabbitMQ();
    if (!channel) throw new Error("RabbitMQ connection failed");
  }

  const eventPayload = {
    type: eventType,
    orderId: payload.orderId,
    userId: payload.userId,
    status: payload.status,
    items: payload.orderItems,
    totalAmount: payload.totalAmount,
    timestamp: new Date().toISOString(),
  };

  try {
    channel.publish(
      exchangeName,
      eventType,
      Buffer.from(JSON.stringify(eventPayload))
    );

    console.log(`Published ${eventType} event for order ${payload.orderId}`);
    return true;
  } catch (error) {
    console.error(`Failed to publish ${eventType} event:`, error);
    return false;
  }
};
