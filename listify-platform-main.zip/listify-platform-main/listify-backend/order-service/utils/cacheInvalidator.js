import redis from "../config/redis.js";

export class CacheInvalidator {
  static async invalidateProductCaches(productId, sellerId) {
    try {
      console.log(
        `[ORDER-CACHE] Invalidating caches for product ${productId} after order change`
      );

      await redis.del(`product:${productId}`);
      await redis.del(`product_combined:${productId}`);

      if (sellerId) {
        const sellerKeys = await redis.keys(`products:seller:${sellerId}:*`);
        if (sellerKeys.length > 0) {
          await redis.del(sellerKeys);
        }
      }

      const listKeys = await redis.keys(`products:list:*`);
      if (listKeys.length > 0) {
        await redis.del(listKeys);
      }

      console.log(
        `[ORDER-CACHE] Cache invalidation completed for product ${productId}`
      );
    } catch (error) {
      console.error(
        `[ORDER-CACHE] Error invalidating caches for product ${productId}:`,
        error
      );
    }
  }

  static async invalidateOrderCaches(orderId, userId) {
    try {
      await redis.del(`order:${orderId}`);

      const userOrderKeys = await redis.keys(`orders:user:${userId}:*`);
      if (userOrderKeys.length > 0) {
        await redis.del(userOrderKeys);
      }

      console.log(
        `[ORDER-CACHE] Order caches invalidated for order ${orderId}`
      );
    } catch (error) {
      console.error(`[ORDER-CACHE] Error invalidating order caches:`, error);
    }
  }
}
