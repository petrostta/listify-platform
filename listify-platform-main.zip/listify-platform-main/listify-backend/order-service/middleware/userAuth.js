import jwt from "jsonwebtoken";

const userAuth = (req, res, next) => {
  const token = req.cookies?.jwt || req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "No token, authorization denied" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.type === "service") {
      console.log(`[SAGA:AUTH] Validated service token from ${decoded.uuid}`);
      req.user = decoded;
      return next();
    }

    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ message: "Token is not valid" });
  }
};

export default userAuth;
