import express from "express";
import OrderController from "../controllers/orderController.js";
import userAuth from "../middleware/userAuth.js";

const orderRouter = express.Router();

orderRouter.get("/:orderId", OrderController.getOrder);

orderRouter.post("/", userAuth, OrderController.createOrder);
orderRouter.put("/:orderId", userAuth, OrderController.updateOrder);
orderRouter.post("/:orderId/cancel", userAuth, OrderController.cancelOrder);
orderRouter.get("/user/:userId", userAuth, OrderController.getUserOrders);

orderRouter.get("/seller/:sellerId", userAuth, OrderController.getSellerOrders);

export default orderRouter;
