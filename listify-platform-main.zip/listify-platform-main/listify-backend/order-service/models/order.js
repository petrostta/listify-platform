import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const orderItemSchema = new mongoose.Schema({
  productId: { type: String, required: true },
  variantId: { type: String },
  name: { type: String, required: true },
  price: { type: Number, required: true },
  quantity: { type: Number, required: true },
});

const addressSchema = new mongoose.Schema({
  fullName: { type: String, required: true },
  addressLine1: { type: String, required: true },
  addressLine2: { type: String },
  city: { type: String, required: true },
  postalCode: { type: String, required: true },
  country: { type: String, required: true },
});

const sagaStepSchema = new mongoose.Schema({
  type: { type: String, required: true },
  timestamp: { type: Date, required: true },
  productId: { type: String },
  variantId: { type: String },
  quantity: { type: Number },
  paymentId: { type: String }
});

const orderSchema = new mongoose.Schema(
  {
    orderId: {
      type: String,
      default: uuidv4,
      unique: true,
    },
    userId: {
      type: String,
      required: true,
    },
    orderItems: {
      type: [orderItemSchema],
      required: true,
    },
    shippingInfo: {
      type: addressSchema,
      required: true,
    },
    billingInfo: {
      type: addressSchema,
      required: true,
    },
    totalAmount: {
      type: Number,
      required: true,
    },
    status: {
      type: String,
      enum: [
        "PENDING",
        "PAYMENT_PROCESSING",
        "PAID",
        "PREPARING",
        "SHIPPED",
        "DELIVERED",
        "CANCELLED",
        "FAILED",
      ],
      default: "PENDING",
    },
    paymentInfo: {
      paymentId: { type: String },
      status: {
        type: String,
        enum: ["PENDING", "PROCESSING", "SUCCESSFUL", "FAILED", "REFUNDED"],
        default: "PENDING",
      },
    },
    sagaState: {
      type: String,
      enum: [
        "ORDER_CREATED",
        "PAYMENT_INITIATED",
        "PAYMENT_COMPLETED",
        "INVENTORY_UPDATED",
        "COMPLETED",
        "FAILED",
        "COMPENSATING",
        "COMPENSATED",
      ],
      default: "ORDER_CREATED",
    },
    sagaCompensation: {
      paymentRefunded: { type: Boolean, default: false },
      inventoryReleased: { type: Boolean, default: false },
    },
    sagaMetadata: {
      sagaId: { type: String },
      startedAt: { type: Date, default: Date.now },
      completedAt: { type: Date },
      compensatedAt: { type: Date },
      steps: [sagaStepSchema],
      compensationEvents: { type: Number, default: 0 },
      errorReason: { type: String },
      retryCount: { type: Number, default: 0 }
    },
    cancellationReason: { type: String },
  },
  {
    timestamps: true,
  }
);

orderSchema.index({ userId: 1, status: 1 });
orderSchema.index({ "sagaMetadata.sagaId": 1 });
orderSchema.index({ orderId: 1 }, { unique: true });

const orderModel =
  mongoose.models.order || mongoose.model("order", orderSchema);
export default orderModel;