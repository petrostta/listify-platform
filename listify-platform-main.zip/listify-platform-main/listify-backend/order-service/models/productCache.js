import mongoose from "mongoose";

const productCacheSchema = new mongoose.Schema({
  productId: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  seller: { type: String, required: true },
  lastUpdated: { type: Date, default: Date.now },
});

export default mongoose.model("ProductCache", productCacheSchema);
