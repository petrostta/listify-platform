import orderModel from "../models/order.js";
import { publishOrderEvent } from "../utils/eventPublisher.js";
import ProductCache from "../models/productCache.js";
import redis from "../config/redis.js";
import { CacheInvalidator } from "../utils/cacheInvalidator.js";

export default class OrderController {
  static async createOrder(req, res) {
    try {
      const { userId, orderItems, shippingInfo, billingInfo, totalAmount } =
        req.body;

      if (
        !userId ||
        !orderItems ||
        !shippingInfo ||
        !billingInfo ||
        !totalAmount
      ) {
        return res
          .status(400)
          .json({ message: "Missing required order information" });
      }

      if (!Array.isArray(orderItems) || orderItems.length === 0) {
        return res
          .status(400)
          .json({ message: "Order must contain at least one item" });
      }

      // Validate products exist in cache
      for (const item of orderItems) {
        const product = await ProductCache.findOne({
          productId: item.productId,
        });
        if (!product) {
          console.warn(
            `Product ${item.productId} not found in cache, order may fail during inventory reservation`
          );
        }
      }

      const order = new orderModel({
        userId,
        orderItems,
        shippingInfo,
        billingInfo,
        totalAmount,
        status: "PENDING",
        sagaState: "ORDER_CREATED",
        paymentInfo: { status: "PENDING" },
      });

      await order.save();

      // Cache the order
      await redis.set(
        `order:${order.orderId}`,
        JSON.stringify(order),
        "EX",
        3600
      );

      await publishOrderEvent("ORDER_CREATED", order);

      console.log(`Order ${order.orderId} created, waiting for payment...`);

      return res.status(201).json({
        message: "Order created successfully",
        orderId: order.orderId,
        status: order.status,
      });
    } catch (error) {
      console.error("Error creating order:", error);
      return res
        .status(500)
        .json({ message: "Failed to create order", error: error.message });
    }
  }

  static async getOrder(req, res) {
    try {
      const { orderId } = req.params;

      const cachedOrder = await redis.get(`order:${orderId}`);
      if (cachedOrder) {
        return res.json(JSON.parse(cachedOrder));
      }

      const order = await orderModel.findOne({ orderId });
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      await redis.set(`order:${orderId}`, JSON.stringify(order), "EX", 3600);
      return res.json(order);
    } catch (error) {
      console.error("Error getting order:", error);
      return res
        .status(500)
        .json({ message: "Failed to retrieve order", error: error.message });
    }
  }

  static async updateOrder(req, res) {
    try {
      const { orderId } = req.params;
      const { status, paymentInfo } = req.body;

      const order = await orderModel.findOne({ orderId });
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      if (status) {
        const validStatuses = [
          "PENDING",
          "PAYMENT_PROCESSING",
          "PAID",
          "PREPARING",
          "SHIPPED",
          "DELIVERED",
          "CANCELLED",
        ];
        if (!validStatuses.includes(status)) {
          return res.status(400).json({ message: "Invalid order status" });
        }
        order.status = status;
      }

      if (paymentInfo) {
        order.paymentInfo = { ...order.paymentInfo, ...paymentInfo };
      }

      await order.save();
      await redis.del(`order:${orderId}`);
      await publishOrderEvent("ORDER_UPDATED", order);

      return res.json(order);
    } catch (error) {
      console.error("Error updating order:", error);
      return res
        .status(500)
        .json({ message: "Failed to update order", error: error.message });
    }
  }

  static async cancelOrder(req, res) {
    try {
      const { orderId } = req.params;
      const { reason } = req.body;

      const order = await orderModel.findOne({ orderId });
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      if (!["PENDING", "PAYMENT_PROCESSING", "PAID"].includes(order.status)) {
        return res.status(400).json({
          message: `Orders in ${order.status} status cannot be cancelled!`,
        });
      }

      if (order.status === "PAID") {
        console.log(
          `[CANCEL] Releasing inventory for cancelled order ${orderId}`
        );
        await OrderController.releaseOrderInventory(order);
      }

      order.status = "CANCELLED";
      order.sagaState = "COMPENSATED";
      order.cancellationReason = reason || "Cancelled by user";

      await order.save();
      await redis.del(`order:${orderId}`);

      await CacheInvalidator.invalidateOrderCaches(orderId, order.userId);

      await publishOrderEvent("ORDER_CANCELLED", order);

      return res.json({ message: "Order cancelled successfully", order });
    } catch (error) {
      console.error("Error cancelling order:", error);
      return res
        .status(500)
        .json({ message: "Failed to cancel order", error: error.message });
    }
  }

  static async getUserOrders(req, res) {
    try {
      const { userId } = req.params;
      const { page = 1, limit = 10, status } = req.query;

      const pageNumber = parseInt(page);
      const limitNumber = parseInt(limit);

      const query = { userId };
      if (status) {
        if (status.includes(",")) {
          query.status = { $in: status.split(",") };
        } else {
          query.status = status;
        }
      }

      const orders = await orderModel
        .find(query)
        .sort({ createdAt: -1 })
        .skip((pageNumber - 1) * limitNumber)
        .limit(limitNumber);

      const totalOrders = await orderModel.countDocuments(query);

      return res.json({
        orders,
        pagination: {
          total: totalOrders,
          page: pageNumber,
          pages: Math.ceil(totalOrders / limitNumber),
        },
      });
    } catch (error) {
      console.error("Error getting user orders:", error);
      return res
        .status(500)
        .json({ message: "Failed to retrieve orders", error: error.message });
    }
  }

  static async getSellerOrders(req, res) {
    try {
      const { sellerId } = req.params;
      const { page = 1, limit = 10, status } = req.query;

      const pageNumber = parseInt(page);
      const limitNumber = parseInt(limit);

      const sellerProducts = await ProductCache.find({
        seller: sellerId,
      }).select("productId");
      const sellerProductIds = sellerProducts.map((p) => p.productId);

      if (!sellerProductIds || sellerProductIds.length === 0) {
        return res.json({
          orders: [],
          pagination: {
            total: 0,
            page: pageNumber,
            pages: 0,
            limit: limitNumber,
          },
        });
      }

      const matchStage = { "orderItems.productId": { $in: sellerProductIds } };
      if (status && status !== "all") {
        if (status.includes(",")) {
          matchStage.status = { $in: status.split(",") };
        } else {
          matchStage.status = status;
        }
      }

      const orders = await orderModel
        .find(matchStage)
        .sort({ createdAt: -1 })
        .skip((pageNumber - 1) * limitNumber)
        .limit(limitNumber);

      const total = await orderModel.countDocuments(matchStage);

      res.json({
        orders,
        pagination: {
          total,
          page: pageNumber,
          pages: Math.ceil(total / limitNumber),
          limit: limitNumber,
        },
      });
    } catch (error) {
      console.error("Error fetching seller orders:", error);
      res.status(500).json({ message: error.message });
    }
  }

  static async processPaymentConfirmation(paymentEvent) {
    try {
      const { orderId, paymentId, status } = paymentEvent;

      console.log(
        `[PAYMENT:CONFIRM] Processing payment confirmation for order ${orderId}: ${status}`
      );

      const order = await orderModel.findOne({ orderId });
      if (!order) {
        console.error(`Order not found for payment confirmation: ${orderId}`);
        return false;
      }

      order.paymentInfo = { paymentId, status };

      if (status === "SUCCESSFUL") {
        console.log(
          `[PAYMENT:CONFIRM] Payment successful, reserving inventory for order ${orderId}`
        );

        order.status = "PAYMENT_PROCESSING";
        order.sagaState = "PAYMENT_COMPLETED";

        await order.save();

        await CacheInvalidator.invalidateOrderCaches(orderId, order.userId);

        const success = await OrderController.reserveOrderInventory(order);

        if (success) {
          order.status = "PAID";
          order.sagaState = "INVENTORY_UPDATED";
          await order.save();

          // Invalidate caches again after status change
          await CacheInvalidator.invalidateOrderCaches(orderId, order.userId);

          console.log(
            `[PAYMENT:CONFIRM] Order ${orderId} marked as PAID with inventory reserved`
          );
        } else {
          order.status = "FAILED";
          order.sagaState = "FAILED";
          order.cancellationReason = "Inventory reservation failed";
          await order.save();

          await CacheInvalidator.invalidateOrderCaches(orderId, order.userId);

          console.log(
            `[PAYMENT:CONFIRM] Order ${orderId} failed due to inventory issues`
          );
        }
      } else if (status === "FAILED") {
        order.status = "FAILED";
        order.sagaState = "FAILED";
        order.cancellationReason = "Payment failed";
        await order.save();

        await CacheInvalidator.invalidateOrderCaches(orderId, order.userId);

        console.log(`[PAYMENT:CONFIRM] Order ${orderId} marked as FAILED`);
      }

      await order.save();
      await redis.del(`order:${orderId}`);
      await publishOrderEvent("ORDER_UPDATED", order);

      console.log(
        `[PAYMENT:CONFIRM] Order ${orderId} updated successfully - Status: ${order.status}`
      );
      return true;
    } catch (error) {
      console.error(
        `[PAYMENT:CONFIRM] Error processing payment confirmation:`,
        error
      );
      return false;
    }
  }

  // Helper util
  static async reserveOrderInventory(order) {
    try {
      console.log(
        `[INVENTORY:RESERVE] Starting inventory reservation for order ${order.orderId}`
      );

      for (const item of order.orderItems) {
        const success = await OrderController.reserveItemInventory(
          item,
          order.orderId
        );
        if (!success) {
          console.error(
            `[INVENTORY:RESERVE] Failed to reserve inventory for product ${item.productId}`
          );
          // If any item fails, release all previously reserved items
          await OrderController.releaseOrderInventory(order);
          return false;
        }
      }

      console.log(
        `[INVENTORY:RESERVE] Successfully reserved inventory for order ${order.orderId}`
      );
      return true;
    } catch (error) {
      console.error(
        `[INVENTORY:RESERVE] Error reserving inventory for order ${order.orderId}:`,
        error
      );
      return false;
    }
  }

  // Helper util
  static async releaseOrderInventory(order) {
    try {
      console.log(
        `[INVENTORY:RELEASE] Starting inventory release for order ${order.orderId}`
      );

      for (const item of order.orderItems) {
        await OrderController.releaseItemInventory(item, order.orderId);
      }

      console.log(
        `[INVENTORY:RELEASE] Successfully released inventory for order ${order.orderId}`
      );
      return true;
    } catch (error) {
      console.error(
        `[INVENTORY:RELEASE] Error releasing inventory for order ${order.orderId}:`,
        error
      );
      return false;
    }
  }

  // Helper util
  static async reserveItemInventory(item, orderId) {
    try {
      const inventoryEvent = {
        type: "INVENTORY_RESERVE_REQUEST",
        productId: item.productId,
        variantId: item.variantId || `${item.productId}-default`,
        quantity: item.quantity,
        orderId: orderId,
        sagaId: `manual_${orderId}_${Date.now()}`,
      };

      const { publishInventoryEvent } = await import(
        "../utils/productEventPublisher.js"
      );

      const success = await publishInventoryEvent(
        "INVENTORY_RESERVE_REQUEST",
        inventoryEvent
      );

      if (success) {
        const productInfo = await ProductCache.findOne({
          productId: item.productId,
        });
        await CacheInvalidator.invalidateProductCaches(
          item.productId,
          productInfo?.seller
        );
      }

      return success;
    } catch (error) {
      console.error(
        `Error reserving inventory for item ${item.productId}:`,
        error
      );
      return false;
    }
  }

  // Helper util
  static async releaseItemInventory(item, orderId) {
    try {
      const inventoryEvent = {
        type: "INVENTORY_RELEASE_REQUEST",
        productId: item.productId,
        variantId: item.variantId || `${item.productId}-default`,
        quantity: item.quantity,
        orderId: orderId,
        sagaId: `release_${orderId}_${Date.now()}`,
      };

      const { publishInventoryEvent } = await import(
        "../utils/productEventPublisher.js"
      );

      const success = await publishInventoryEvent(
        "INVENTORY_RELEASE_REQUEST",
        inventoryEvent
      );

      if (success) {
        const productInfo = await ProductCache.findOne({
          productId: item.productId,
        });
        await CacheInvalidator.invalidateProductCaches(
          item.productId,
          productInfo?.seller
        );
      }

      return success;
    } catch (error) {
      console.error(
        `Error releasing inventory for item ${item.productId}:`,
        error
      );
      return false;
    }
  }
}
