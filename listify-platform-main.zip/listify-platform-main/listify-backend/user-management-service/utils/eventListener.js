import amqp from "amqplib";
import userProfileModel from "../models/UserProfile.js";
import sellerProfileModel from "../models/SellerProfile.js";

let connection;
let channel;

export const connectEventListener = async () => {
  try {
    connection = await amqp.connect(process.env.RABBITMQ_URI);
    channel = await connection.createChannel();

    await setupUserProfileCreatedListener();
    await setupSellerProfileCreatedListener();
    await setupUserAddressUpdateListener();

    console.log("Connected to RabbitMQ & Queues initialized");
    return true;
  } catch (error) {
    console.error("RabbitMQ Connection Error:", error);
    setTimeout(connectEventListener, 5000);
    return false;
  }
};

const setupUserProfileCreatedListener = async () => {
  await channel.assertQueue("USER_PROFILE_CREATED");
  channel.consume("USER_PROFILE_CREATED", async (msg) => {
    try {
      const { uuid, first_name, last_name, phone_number } = JSON.parse(
        msg.content.toString()
      );

      await userProfileModel.create({
        uuid,
        first_name,
        last_name,
        phone_number,
      });

      console.log(`User Profile Created for UUID: ${uuid}`);
      channel.ack(msg);
    } catch (error) {
      console.error("Error processing USER_PROFILE_CREATED event:", error);
      channel.nack(msg);
    }
  });
};

const setupSellerProfileCreatedListener = async () => {
  await channel.assertQueue("SELLER_PROFILE_CREATED");
  channel.consume("SELLER_PROFILE_CREATED", async (msg) => {
    try {
      const { uuid, business_Name, contact_email } = JSON.parse(
        msg.content.toString()
      );

      await sellerProfileModel.create({
        uuid,
        business_Name,
        contact_email,
      });

      console.log(`Seller Profile Created for UUID: ${uuid}`);
      channel.ack(msg);
    } catch (error) {
      console.error("Error processing SELLER_PROFILE_CREATED event:", error);
      channel.nack(msg);
    }
  });
};

const setupUserAddressUpdateListener = async () => {
  await channel.assertQueue("USER_UPDATE_ADDRESS");
  channel.consume("USER_UPDATE_ADDRESS", async (msg) => {
    try {
      const { uuid, address } = JSON.parse(msg.content.toString());

      const user = await userProfileModel.findOne({ uuid });
      if (!user) {
        console.error(`User Profile not found for UUID: ${uuid}`);
        channel.ack(msg);
        return;
      }

      user.address = address;
      await user.save();

      console.log(`Address updated for UUID: ${uuid}`);
      channel.ack(msg);
    } catch (error) {
      console.error("Error processing USER_UPDATE_ADDRESS event:", error);
      channel.nack(msg);
    }
  });
};

export const closeConnection = async () => {
  if (channel) await channel.close();
  if (connection) await connection.close();
};
