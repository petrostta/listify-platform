import express from "express";
import cookieParser from "cookie-parser";
import userRouter from "./routes/userProfileRoutes.js";
import sellerRouter from "./routes/sellerProfileRoutes.js";
import cors from "cors";
import dotenv from "dotenv";
import { connectDB } from "./config/db.js";
import { connectEventListener } from "./utils/eventListener.js";

dotenv.config();

const app = express();
const port = process.env.PORT || 4000;

app.use(express.json());
app.use(cookieParser());

connectDB();

app.use("/api/users", userRouter);
app.use("/api/sellers", sellerRouter);

connectEventListener().then(() => {
  app.listen(port, () =>
    console.log(`User Management Service running on port ${port}`)
  );
});

process.on("SIGTERM", async () => {
  console.log("SIGTERM received, shutting down gracefully");
  process.exit(0);
});
