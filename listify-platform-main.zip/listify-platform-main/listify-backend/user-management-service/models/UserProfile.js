import mongoose from "mongoose";

const userProfileSchema = new mongoose.Schema({
  uuid: { type: String, required: true, unique: true },
  first_name: { type: String, required: true },
  last_name: { type: String, required: true },
  phone_number: { type: String, required: false },
  address: {
    street: { type: String },
    city: { type: String },
    country: { type: String },
    zipCode: { type: String },
  },
  createdAt: { type: Date, default: Date.now },
});

const userProfileModel =
  mongoose.models.userProfile ||
  mongoose.model("userProfile", userProfileSchema);

export default userProfileModel;
