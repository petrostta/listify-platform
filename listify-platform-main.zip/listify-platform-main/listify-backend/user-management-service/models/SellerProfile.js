import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const sellerSchema = new mongoose.Schema({
  uuid: { type: String, default: uuidv4, unique: true },
  description: { type: String, required: false },
  business_Name: { type: String, required: true },
  businessAddress: {
    street: { type: String },
    city: { type: String },
    country: { type: String },
    zipCode: { type: String },
  },
  contact_number: { type: String, required: false },
  contact_email: { type: String, required: true },
  website: { type: String, required: false, default: "" },
  createdAt: { type: Date, default: Date.now },
});
const sellerModel =
  mongoose.models.seller || mongoose.model("seller", sellerSchema);

export default sellerModel;
