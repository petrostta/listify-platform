import userController from "../controllers/userProfileController.js";
import authUserMiddleware from "../middleware/authUserMiddleware.js";
import express from "express";

const userRouter = express.Router();

userRouter.get("/me", authUserMiddleware, (req, res) => {
  res.status(200).json({
    uuid: req.user.uuid,
    first_name: req.user.first_name,
    last_name: req.user.last_name,
    phone_number: req.user.phone_number,
    address: req.user.address,
    createdAt: req.user.createdAt,
  });
});

userRouter.get("/:uuid", authUserMiddleware, userController.getUserProfile);

userRouter.put("/:uuid", authUserMiddleware, userController.updateUserProfile);

export default userRouter;
