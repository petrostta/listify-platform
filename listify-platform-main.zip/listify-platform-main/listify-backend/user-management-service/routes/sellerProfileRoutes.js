import express from "express";
import sellerController from "../controllers/sellerProfileController.js";
import authSellerMiddleware from "../middleware/authSellerMiddleware.js";

const sellerRouter = express.Router();

sellerRouter.get("/me", authSellerMiddleware, (req, res) => {
  res.status(200).json({
    uuid: req.user.uuid,
    business_Name: req.user.business_Name,
    contact_number: req.user.contact_number,
    contact_email: req.user.contact_email,
    description: req.user.description,
    website: req.user.website,
    businessAddress: req.user.businessAddress,
    createdAt: req.user.createdAt,
  });
});

sellerRouter.get("/:uuid", sellerController.getSellerProfile);

sellerRouter.put("/:uuid", sellerController.updateSellerProfile);

sellerRouter.put(
  "/profile",
  authSellerMiddleware,
  sellerController.updateSellerProfile
);



export default sellerRouter;
