import jwt from "jsonwebtoken";
import sellerModel from "../models/SellerProfile.js";

const authSellerMiddleware = async (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "No token, authorization denied" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    req.user = await sellerModel.findOne({ uuid: decoded.uuid });

    if (!req.user) {
      console.log(`Seller with uuid ${decoded.uuid} not found`);
      return res.status(404).json({ message: "Seller not found" });
    }

    next();
  } catch (error) {
    console.error("Token verification error:", error);
    res.status(401).json({ message: "Token is not valid" });
  }
};

export default authSellerMiddleware;
