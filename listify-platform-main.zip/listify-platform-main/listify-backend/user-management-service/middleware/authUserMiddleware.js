import jwt from "jsonwebtoken";
import userModel from "../models/UserProfile.js";

const authUserMiddleware = async (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "No token, authorization denied" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    req.user = await userModel.findOne({ uuid: decoded.uuid });

    if (!req.user) {
      console.log(`User with uuid ${decoded.uuid} not found`);
      return res.status(404).json({ message: "User not found" });
    }

    next();
  } catch (error) {
    console.error("Token verification error:", error);
    res.status(401).json({ message: "Token is not valid" });
  }
};

export default authUserMiddleware;
