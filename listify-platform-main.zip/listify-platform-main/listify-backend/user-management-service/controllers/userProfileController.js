import UserProfile from "../models/UserProfile.js";

export const updateUserProfile = async (req, res) => {
  try {
    const updated = await UserProfile.findOneAndUpdate(
      { uuid: req.params.uuid },
      req.body,
      { new: true }
    );
    res.json(updated);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const getUserProfile = async (req, res) => {
  try {
    const profile = await UserProfile.findOne({ uuid: req.params.uuid });
    res.json(profile);
  } catch (error) {
    res.status(404).json({ error: "Profile not found" });
  }
};

export default { updateUserProfile, getUserProfile };
