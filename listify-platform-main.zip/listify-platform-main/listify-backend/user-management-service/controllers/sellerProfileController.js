import SellerProfile from "../models/SellerProfile.js";

const updateSellerProfile = async (req, res) => {
  try {
    const updated = await SellerProfile.findOneAndUpdate(
      { uuid: req.params.uuid },
      req.body,
      { new: true }
    );
    res.json(updated);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

const getSellerProfile = async (req, res) => {
  try {
    const profile = await SellerProfile.findOne({ uuid: req.params.uuid });
    res.json(profile);
  } catch (error) {
    res.status(404).json({ error: "Profile not found" });
  }
};

export default { updateSellerProfile, getSellerProfile };
