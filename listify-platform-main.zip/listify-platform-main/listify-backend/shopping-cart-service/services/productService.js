import { EventEmitter } from "events";
import amqlib from "amqplib";
import redis from "../config/redis.js";
import ProductCache from "../models/productCache.js";

class ProductService extends EventEmitter {
  constructor() {
    super();
    this.channel = null;
    this.connection = null;
    this.initialize();
  }

  async initialize() {
    await this.setupEventListeners();
    await this.setupInventoryEventListeners();
  }

  async setupEventListeners() {
    try {
      this.connection = await amqlib.connect(process.env.RABBITMQ_URL);

      this.connection.on("error", (err) => {
        console.error("RabbitMQ connection error:", err.message);
      });

      this.connection.on("close", () => {
        console.warn("RabbitMQ connection closed, attempting to reconnect...");
        setTimeout(() => this.setupEventListeners(), 5000);
      });

      this.channel = await this.connection.createChannel();

      await this.channel.assertExchange("product_data_events", "topic", {
        durable: true,
      });
      const { queue } = await this.channel.assertQueue(
        "cart_service_product_queue",
        { durable: true }
      );

      await this.channel.bindQueue(
        queue,
        "product_data_events",
        "PRODUCT_CREATED"
      );
      await this.channel.bindQueue(
        queue,
        "product_data_events",
        "PRODUCT_UPDATED"
      );
      await this.channel.bindQueue(
        queue,
        "product_data_events",
        "PRODUCT_DELETED"
      );

      this.channel.consume(queue, async (msg) => {
        if (!msg) return;

        try {
          const event = JSON.parse(msg.content.toString());
          await this.handleProductEvent(event);
          this.channel.ack(msg);
        } catch (error) {
          console.error("Error processing product event:", error);
          this.channel.ack(msg);
        }
      });

      console.log("Cart service product event listeners connected");
    } catch (error) {
      console.error("Error setting up event listeners:", error);
      setTimeout(() => this.setupEventListeners(), 5000);
    }
  }

  async setupInventoryEventListeners() {
    try {
      if (!this.channel) {
        console.error("Channel not available for inventory listeners");
        return;
      }

      await this.channel.assertExchange("inventory_events", "topic", {
        durable: true,
      });

      const { queue } = await this.channel.assertQueue(
        "cart_service_inventory_queue",
        { durable: true }
      );

      await this.channel.bindQueue(
        queue,
        "inventory_events",
        "INVENTORY_RESERVED"
      );
      await this.channel.bindQueue(
        queue,
        "inventory_events",
        "INVENTORY_RELEASED"
      );
      await this.channel.bindQueue(
        queue,
        "inventory_events",
        "INVENTORY_UPDATED"
      );

      this.channel.consume(queue, async (msg) => {
        if (!msg) return;

        try {
          const event = JSON.parse(msg.content.toString());
          await this.handleInventoryEvent(event);
          this.channel.ack(msg);
        } catch (error) {
          console.error("Error processing inventory event:", error);
          this.channel.ack(msg);
        }
      });

      console.log("Cart service inventory event listeners connected");
    } catch (error) {
      console.error("Error setting up inventory event listeners:", error);
    }
  }

  async handleInventoryEvent(event) {
    try {
      console.log(
        `[CART-CACHE] Processing inventory event: ${event.type} for product ${event.productId}`
      );

      switch (event.type) {
        case "INVENTORY_RESERVED":
        case "INVENTORY_RELEASED":
        case "INVENTORY_UPDATED":
          await this.updateProductStock(event);
          break;
      }
    } catch (error) {
      console.error("Error handling inventory event:", error);
    }
  }

  async updateProductStock(inventoryEvent) {
    try {
      const { productId, variantId, quantity, type } = inventoryEvent;

      console.log(
        `[CART-CACHE] Updating stock for product ${productId}, variant ${variantId}, quantity ${quantity}, type ${type}`
      );

      const product = await ProductCache.findOne({ productId });
      if (!product) {
        console.warn(
          `Product ${productId} not found in cart cache for inventory update`
        );
        return;
      }

      let stockChange = 0;
      if (type === "INVENTORY_RESERVED") {
        stockChange = -quantity;
      } else if (type === "INVENTORY_RELEASED") {
        stockChange = quantity;
      } else if (
        type === "INVENTORY_UPDATED" &&
        inventoryEvent.newStock !== undefined
      ) {
        if (variantId && product.variants && product.variants.length > 0) {
          const variantIndex = product.variants.findIndex(
            (v) => v.uuid === variantId
          );
          if (variantIndex >= 0) {
            product.variants[variantIndex].stock = inventoryEvent.newStock;
            await product.save();
            console.log(
              `[CART-CACHE] Updated variant ${variantId} stock to ${inventoryEvent.newStock} for product ${productId}`
            );
          } else {
            console.warn(
              `[CART-CACHE] Variant ${variantId} not found for product ${productId}`
            );
          }
        } else {
          product.stock = inventoryEvent.newStock;
          await product.save();
          console.log(
            `[CART-CACHE] Updated product ${productId} stock to ${inventoryEvent.newStock}`
          );
        }

        await redis.hset(
          "products",
          productId,
          JSON.stringify(product.toObject())
        );
        return;
      }

      if (stockChange !== 0) {
        let updated = false;

        if (variantId && product.variants && product.variants.length > 0) {
          console.log(
            `[CART-CACHE] Looking for variant ${variantId} in ${product.variants.length} variants`
          );

          const variantIndex = product.variants.findIndex(
            (v) => v.uuid === variantId
          );

          if (variantIndex >= 0) {
            const oldStock = product.variants[variantIndex].stock;
            product.variants[variantIndex].stock = Math.max(
              0,
              product.variants[variantIndex].stock + stockChange
            );
            console.log(
              `[CART-CACHE] ${type}: Updated variant ${variantId} stock from ${oldStock} to ${product.variants[variantIndex].stock} for product ${productId}`
            );
            updated = true;
          } else {
            console.warn(
              `[CART-CACHE] Variant ${variantId} not found in product ${productId} variants`
            );
            console.log(
              `[CART-CACHE] Available variants:`,
              product.variants.map((v) => ({ uuid: v.uuid, stock: v.stock }))
            );

            const oldStock = product.stock;
            product.stock = Math.max(0, product.stock + stockChange);
            console.log(
              `[CART-CACHE] ${type}: Fallback - Updated product ${productId} main stock from ${oldStock} to ${product.stock}`
            );
            updated = true;
          }
        } else {
          const oldStock = product.stock;
          product.stock = Math.max(0, product.stock + stockChange);
          console.log(
            `[CART-CACHE] ${type}: Updated product ${productId} stock from ${oldStock} to ${product.stock}`
          );
          updated = true;
        }

        if (updated) {
          product.lastUpdated = new Date();
          await product.save();

          await redis.hset(
            "products",
            productId,
            JSON.stringify(product.toObject())
          );

          console.log(
            `[CART-CACHE] Successfully saved updated stock for product ${productId}`
          );
        }
      }
    } catch (error) {
      console.error("Error updating product stock in cart cache:", error);
    }
  }

  async handleProductEvent(event) {
    switch (event.type) {
      case "PRODUCT_CREATED":
      case "PRODUCT_UPDATED":
        await this.updateProductCache(event);
        break;
      case "PRODUCT_DELETED":
        await this.removeProductCache(event.productId);
        break;
    }
  }

  async updateProductCache(productData) {
    try {
      const updatedProduct = await ProductCache.findOneAndUpdate(
        { productId: productData.productId },
        {
          name: productData.name,
          description: productData.description,
          category: productData.category,
          original_price: productData.original_price,
          discount: productData.discount,
          stock: productData.stock,
          isAvailable: productData.isAvailable,
          pictures: productData.pictures,
          variants: productData.variants,
          seller: productData.seller,
          lastUpdated: new Date(),
        },
        { upsert: true, new: true }
      );

      await redis.hset(
        "products",
        productData.productId,
        JSON.stringify(updatedProduct.toObject())
      );

      console.log(`Updated product cache for ${productData.productId}`);
    } catch (error) {
      console.error("Error updating product cache:", error);
    }
  }

  async removeProductCache(productId) {
    try {
      await ProductCache.findOneAndDelete({ productId });
      await redis.hdel("products", productId);
      console.log(`Removed product cache for ${productId}`);
    } catch (error) {
      console.error("Error removing product cache:", error);
    }
  }

  async getProduct(productId, forceRefresh = false) {
    try {
      if (!forceRefresh) {
        let product = await redis.hget("products", productId);
        if (product) {
          return JSON.parse(product);
        }
      }

      const cachedProduct = await ProductCache.findOne({ productId });
      if (cachedProduct) {
        const productData = cachedProduct.toObject();
        await redis.hset("products", productId, JSON.stringify(productData));
        return productData;
      }

      console.warn(`Product ${productId} not found in cache`);
      return null;
    } catch (error) {
      console.error("Error getting product:", error);
      return null;
    }
  }

  async validateCartItem(item, forceRefresh = false) {
    const product = await this.getProduct(item.productId, forceRefresh);

    if (!product) {
      return { valid: false, error: "Product not found" };
    }

    if (!product.isAvailable) {
      return { valid: false, error: "Product is not available" };
    }

    const variant = product.variants?.find((v) => v.uuid === item.variantId);
    const stock = variant?.stock ?? product.stock;
    const originalPrice = variant
      ? variant.original_price
      : product.original_price;
    const discount = variant ? variant.discount : product.discount;
    const price =
      discount > 0 ? originalPrice * (1 - discount / 100) : originalPrice;

    if (item.quantity > stock) {
      return {
        valid: false,
        error: `Insufficient stock. Only ${stock} items available.`,
        stock,
      };
    }

    return {
      valid: stock >= item.quantity,
      price,
      stock,
      product,
    };
  }
}

export const productService = new ProductService();
