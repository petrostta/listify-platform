import express from "express";
import cartController from "../controllers/cartController.js";
import checkUserAuth from "../middleware/checkUserAuth.js";

const cartRouter = express.Router();

cartRouter.get("/", checkUserAuth, cartController.getCart);
cartRouter.post("/items", checkUserAuth, cartController.addItem);
cartRouter.put("/items/:itemId", checkUserAuth, cartController.updateItem);
cartRouter.delete("/", checkUserAuth, cartController.emptyCart);
cartRouter.delete("/items/:itemId", checkUserAuth, cartController.removeItem);

export default cartRouter;
