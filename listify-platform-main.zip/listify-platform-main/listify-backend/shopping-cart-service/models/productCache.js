import mongoose from "mongoose";

const productCacheSchema = new mongoose.Schema({
  productId: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  description: { type: String },
  category: { type: String, index: true },
  original_price: { type: Number, required: true },
  discount: { type: Number, default: 0 },
  stock: { type: Number, required: true, index: true },
  isAvailable: { type: Boolean, required: true, index: true },
  pictures: [
    {
      url: String,
      key: String,
    },
  ],
  variants: [
    {
      uuid: { type: String, index: true },
      original_price: Number,
      discount: Number,
      stock: Number,
      attributes: mongoose.Schema.Types.Mixed,
    },
  ],
  seller: { type: String, required: true, index: true },
  lastUpdated: { type: Date, default: Date.now, index: true },
});

productCacheSchema.index({ productId: 1 }, { unique: true });
productCacheSchema.index({ isAvailable: 1, stock: 1 });
productCacheSchema.index({ seller: 1, isAvailable: 1 });
productCacheSchema.index({ category: 1, isAvailable: 1 });
productCacheSchema.index({ "variants.uuid": 1 }, { sparse: true });

export default mongoose.model("ProductCache", productCacheSchema);
