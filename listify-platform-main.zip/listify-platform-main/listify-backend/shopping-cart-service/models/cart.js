import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const cartItemSchema = new mongoose.Schema({
  productId: { type: String, required: true, index: true },
  variantId: { type: String, index: true },
  quantity: {
    type: Number,
    required: true,
    min: [1, "Quantity can not be less than 1"],
  },
  price: { type: Number, required: true },
  addedAt: { type: Date, default: Date.now },
  selectedAttributes: [
    {
      key: { type: String, required: true },
      value: { type: String, required: true },
    },
  ],
});

const cartSchema = new mongoose.Schema({
  uuid: { type: String, default: uuidv4, unique: true },
  user: { type: String, required: true, index: true, unique: true },
  items: [cartItemSchema],
  metadata: {
    userAgent: String,
    ipAddress: String,
    lastActivity: { type: Date, index: true },
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

cartSchema.index({ user: 1 }, { unique: true });
cartSchema.index({ "metadata.lastActivity": 1 });
cartSchema.index({ createdAt: 1 });
cartSchema.index({ "items.productId": 1 });
cartSchema.index({ "items.variantId": 1 }, { sparse: true });

cartSchema.index({ user: 1, "items.productId": 1 });
cartSchema.index({ user: 1, updatedAt: -1 });

cartSchema.pre("save", function (next) {
  this.updatedAt = Date.now();
  this.metadata.lastActivity = new Date();
  next();
});

const cartModel = mongoose.models.Cart || mongoose.model("Cart", cartSchema);
export default cartModel;
