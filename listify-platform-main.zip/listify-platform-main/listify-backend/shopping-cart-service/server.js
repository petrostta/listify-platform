import express from "express";
import cartRouter from "./routes/cartRoutes.js";
import dotenv from "dotenv";
import { connectDB } from "./config/db.js";
import redis from "./config/redis.js";
import { connectRabbitMQ, getChannel } from "./utils/eventPublisher.js";
import mongoose from "mongoose";
import cookieParser from "cookie-parser";

dotenv.config();
const app = express();
const port = process.env.PORT || 2000;

app.use(express.json());
app.use(cookieParser());

connectDB();
app.use("/api/cart", cartRouter);

connectRabbitMQ()
  .then(() => {
    console.log("Connected to RabbitMQ");
  })
  .catch((error) => {
    console.error("RabbitMQ connection failed:", error);
  });

app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    redis: redis.status,
    db: mongoose.connection.readyState === 1 ? "connected" : "disconnected",
    rabbitmq: getChannel() ? "connected" : "disconnected",
  });
});

app.listen(port, () => {
  console.log(`Cart service running on port ${port}`);
});
