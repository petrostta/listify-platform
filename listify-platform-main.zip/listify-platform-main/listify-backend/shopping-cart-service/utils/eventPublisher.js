import amqlib from "amqplib";

let channel;
let connection;
const exchangeName = "cart_events";

export const connectRabbitMQ = async (retries = 5, delay = 2000) => {
  let attempt = 0;

  while (attempt < retries) {
    try {
      connection = await amqlib.connect(process.env.RABBITMQ_URL);

      connection.on("error", (err) => {
        console.error("RabbitMQ connection error:", err.message);
      });

      connection.on("close", () => {
        console.warn("RabbitMQ connection closed, attempting to reconnect...");
        channel = null;
        setTimeout(() => connectRabbitMQ(), 5000);
      });

      channel = await connection.createChannel();
      await channel.assertExchange(exchangeName, "topic", { durable: false });
      return channel;
    } catch (error) {
      attempt++;
      console.error(
        `RabbitMQ connection failed (attempt ${attempt}/${retries}):`,
        error.message
      );

      if (attempt < retries) {
        await new Promise((resolve) => setTimeout(resolve, delay));
        delay *= 2;
      } else {
        console.error("Failed to connect to RabbitMQ after multiple attempts");
        throw error;
      }
    }
  }
};

export const publishCartEvent = (eventType, payload) => {
  if (!channel) {
    throw new Error("RabbitMQ not connected");
  }

  try {
    const message = {
      ...payload,
      timestamp: new Date().toISOString(),
    };

    return channel.publish(
      exchangeName,
      eventType,
      Buffer.from(JSON.stringify(message))
    );
  } catch (error) {
    console.error(`Error publishing ${eventType} event:`, error);
    return false;
  }
};

export const getChannel = () => channel;
