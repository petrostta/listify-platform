import Cart from "../models/cart.js";
import { productService } from "../services/productService.js";
import { publishCartEvent } from "../utils/eventPublisher.js";
import redis from "../config/redis.js";
import mongoose from "mongoose";

const CART_MAX_ITEMS = 20;

export default class CartController {
  static async getCart(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const cart = await CartController.getOrCreateCart(req);
      res.json(await CartController.enrichCart(cart));
    } catch (error) {
      CartController.handleError(res, error);
    }
  }

  static async addItem(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const { items } = req.body;
      const cart = await CartController.getOrCreateCart(req);

      if (cart.items.length + items.length > CART_MAX_ITEMS) {
        return res.status(400).json({
          message: `Cart cannot have more than ${CART_MAX_ITEMS} items`,
        });
      }

      try {
        for (const item of items) {
          const existingItemIndex = cart.items.findIndex(
            (cartItem) =>
              cartItem.productId === item.productId &&
              (cartItem.variantId === item.variantId ||
                (!cartItem.variantId && !item.variantId))
          );

          if (existingItemIndex >= 0) {
            const newTotalQuantity =
              cart.items[existingItemIndex].quantity + item.quantity;

            const validationResult = await productService.validateCartItem({
              ...item,
              quantity: newTotalQuantity,
            });

            if (!validationResult.valid) {
              return res.status(400).json({
                message:
                  validationResult.error ||
                  `Only ${validationResult.stock} items available in stock`,
              });
            }

            cart.items[existingItemIndex].quantity = newTotalQuantity;
          } else {
            const validationResult = await productService.validateCartItem(
              item
            );

            if (!validationResult.valid) {
              return res.status(400).json({
                message: validationResult.error || "Invalid item",
              });
            }

            cart.items.push({
              productId: item.productId,
              variantId: item.variantId,
              quantity: item.quantity,
              price: validationResult.price,
              addedAt: new Date(),
              selectedAttributes: item.selectedAttributes || [],
            });
          }
        }
      } catch (error) {
        console.error("Error validating cart items:", error);
        return res.status(400).json({
          message: "Error validating cart items",
          error: error.message,
        });
      }

      const updatedCart = await Cart.findOneAndUpdate(
        { user: req.user.id },
        {
          $set: {
            items: cart.items,
            updatedAt: new Date(),
            "metadata.lastActivity": new Date(),
          },
        },
        { new: true }
      );

      const redisKey = `cart:user:${req.user.id}`;
      await redis.setex(redisKey, 3600, JSON.stringify(updatedCart));

      const enrichedCart = await CartController.enrichCart(updatedCart);
      return res.status(200).json(enrichedCart);
    } catch (error) {
      console.error("Error adding item to cart:", error);
      return res.status(500).json({
        message: "Failed to add item to cart",
        error: error.message,
      });
    }
  }

  static async updateItem(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const { itemId } = req.params;
      const { quantity } = req.body;

      const cart = await CartController.getOrCreateCart(req);

      const item = cart.items.find(
        (itm) => itm._id.toString() === itemId || itm.id === itemId
      );

      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }

      if (quantity > 0) {
        const itemToValidate = { ...item, quantity };

        const validation = await productService.validateCartItem(
          itemToValidate
        );
        if (!validation.valid) {
          return res.status(400).json({
            message:
              validation.error ||
              `Only ${validation.stock} items available in stock`,
          });
        }
      }

      let update;
      if (quantity <= 0) {
        update = {
          $pull: {
            items: {
              _id: item._id,
            },
          },
        };
      } else {
        const baseQuery = { user: req.user.id, "items._id": item._id };
        update = { $set: { "items.$.quantity": quantity } };

        const updatedCart = await Cart.findOneAndUpdate(baseQuery, update, {
          new: true,
          runValidators: true,
        });

        if (!updatedCart) {
          return res.status(404).json({ message: "Cart item not found" });
        }

        await CartController.saveCart(req, updatedCart);
        publishCartEvent("EVENT_CART_UPDATED", updatedCart);
        return res.json(await CartController.enrichCart(updatedCart));
      }

      const updatedCart = await Cart.findOneAndUpdate(
        { user: req.user.id },
        update,
        {
          new: true,
          runValidators: true,
        }
      );

      if (!updatedCart) {
        return res.status(404).json({ message: "Item not found" });
      }

      await CartController.saveCart(req, updatedCart);
      publishCartEvent("EVENT_CART_UPDATED", updatedCart);
      res.json(await CartController.enrichCart(updatedCart));
    } catch (error) {
      console.error("Error in updateItem:", error);
      CartController.handleError(res, error);
    }
  }

  static async getOrCreateCart(req) {
    if (!req.user) {
      throw new Error("Authentication required");
    }

    const userId = req.user.id;
    const redisKey = `cart:user:${userId}`;

    try {
      const cachedCart = await redis.get(redisKey);
      if (cachedCart) {
        return JSON.parse(cachedCart);
      }

      const cart = await Cart.findOneAndUpdate(
        { user: userId },
        {
          $set: {
            metadata: {
              userAgent: req.headers["user-agent"],
              ipAddress: req.ip,
              lastActivity: new Date(),
            },
          },
        },
        { new: true, upsert: true }
      );

      await redis.setex(redisKey, 3600, JSON.stringify(cart));
      return cart;
    } catch (error) {
      console.error("Error in getOrCreateCart:", error);
      return { items: [], subtotal: 0 };
    }
  }

  static async clearCartData(req) {
    if (!req.user) {
      throw new Error("Authentication required");
    }

    const userId = req.user.id;
    const redisKey = `cart:user:${userId}`;

    await Cart.findOneAndDelete({ user: userId });
    await redis.del(redisKey);
  }

  static async cartCheckout(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const cart = await CartController.getOrCreateCart(req);
      if (!cart || !cart.items.length) {
        return res.status(400).json({ message: "Cart is empty" });
      }

      const enrichedCart = await CartController.enrichCart(cart);

      const checkoutPayload = {
        uuid: cart.uuid || "checkout_" + Date.now(),
        user: req.user.id,
        items: enrichedCart.items.map((item) => ({
          productId: item.productId,
          variantId: item.variantId,
          quantity: item.quantity,
          price: item.price,
          name: item.name || `Product ${item.productId}`,
          selectedAttributes: item.selectedAttributes || [],
        })),
        subtotal: enrichedCart.subtotal,
        timestamp: new Date().toISOString(),
      };

      publishCartEvent("EVENT_CART_CHECKOUT", checkoutPayload);
      await CartController.clearCartData(req);
      res.json({ message: "Checkout initiated", payload: checkoutPayload });
    } catch (error) {
      CartController.handleError(res, error);
    }
  }

  static async emptyCart(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const userId = req.user.id;
      const redisKey = `cart:user:${userId}`;

      const cart = await Cart.findOneAndDelete({ user: userId });
      if (!cart) {
        return res.status(404).json({ message: "Cart not found" });
      }

      await redis.del(redisKey);
      res.json({ message: "Cart emptied" });
    } catch (error) {
      CartController.handleError(res, error);
    }
  }

  static async removeItem(req, res) {
    req.body.quantity = 0;
    return CartController.updateItem(req, res);
  }

  static async processCartItem(cart, item) {
    try {
      const validation = await productService.validateCartItem(item);

      if (!validation.valid) {
        throw new Error(validation.error);
      }

      const existingItemIndex = cart.items.findIndex(
        (cartItem) =>
          cartItem.productId === item.productId &&
          (cartItem.variantId === item.variantId ||
            (!cartItem.variantId && !item.variantId))
      );

      if (existingItemIndex > -1) {
        cart.items[existingItemIndex].quantity = item.quantity;
        if (item.variantId) {
          cart.items[existingItemIndex].variantId = item.variantId;
        }
      } else {
        cart.items.push({
          productId: item.productId,
          variantId: item.variantId,
          quantity: item.quantity,
          price: validation.price,
          selectedAttributes: item.selectedAttributes || [],
        });
      }

      return cart;
    } catch (error) {
      throw error;
    }
  }

  static async enrichCart(cart) {
    if (!cart || !cart.items || !Array.isArray(cart.items)) {
      console.warn("Invalid cart format received:", cart);
      return cart;
    }

    const cartObj = cart.toObject
      ? cart.toObject()
      : JSON.parse(JSON.stringify(cart));

    const enrichedItems = await Promise.all(
      cartObj.items.map(async (item) => {
        try {
          const product = await productService.getProduct(item.productId);

          if (!product) {
            console.warn(`Product not found for ID: ${item.productId}`);
            return item;
          }

          let variant = null;
          if (item.variantId && product.variants) {
            variant = product.variants.find((v) => v.uuid === item.variantId);
          }

          let originalPrice = variant
            ? variant.original_price
            : product.original_price;
          let discount = variant ? variant.discount : product.discount;

          let finalPrice = originalPrice;
          if (discount && discount > 0) {
            finalPrice = originalPrice * (1 - discount / 100);
          }

          item.price = finalPrice;

          return {
            ...item,
            product: {
              uuid: product.uuid,
              name: product.name,
              pictures: product.pictures || [],
              stock: product.stock,
              discount: product.discount,
              original_price: product.original_price,
            },
            variant: variant
              ? {
                  uuid: variant.uuid,
                  original_price: variant.original_price,
                  discount: variant.discount,
                  attributes: variant.attributes || [],
                  stock: variant.stock,
                }
              : null,
          };
        } catch (error) {
          console.error(`Error enriching cart item ${item.productId}:`, error);
          return item;
        }
      })
    );

    const subtotal = enrichedItems.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );

    return {
      ...cartObj,
      items: enrichedItems,
      subtotal,
    };
  }

  static async saveCart(req, cart) {
    try {
      if (!req.user) {
        throw new Error("Authentication required");
      }

      const redisKey = `cart:user:${req.user.id}`;
      await redis.setex(redisKey, 3600, JSON.stringify(cart));
    } catch (error) {
      console.error("Error saving cart to Redis:", error);
    }
  }

  static handleError(res, error) {
    console.error("Cart controller error:", error);

    if (error.message === "Authentication required") {
      return res.status(401).json({
        message: "Authentication required",
      });
    }

    if (error.name === "ValidationError") {
      return res.status(400).json({
        message: "Invalid cart data",
        details: error.message,
      });
    }

    res.status(500).json({
      message: "Internal server error",
      details: error.message,
    });
  }
}
