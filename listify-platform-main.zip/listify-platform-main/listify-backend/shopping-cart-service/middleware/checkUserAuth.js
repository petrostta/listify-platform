import jwt from "jsonwebtoken";

const checkUserAuth = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader?.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const token = authHeader.split(" ")[1];

  jwt.verify(token, process.env.JWT_SECRET, (error, decoded) => {
    if (error) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    req.user = { id: decoded.uuid };
    next();
  });
};

export default checkUserAuth;
