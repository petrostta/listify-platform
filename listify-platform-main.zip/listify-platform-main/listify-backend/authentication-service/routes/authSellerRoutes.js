import express from "express";
import authSellerController from "../controllers/authSellerController.js";
import jwt from "jsonwebtoken";
import Seller from "../models/seller.js";
import sellerAuth from "../middleware/sellerAuth.js";

const sellerRouter = express.Router();

sellerRouter.post("/register", authSellerController.registerSeller);

sellerRouter.post("/login", authSellerController.loginSeller);

sellerRouter.post("/logout", authSellerController.logoutSeller);

sellerRouter.put("/password", sellerAuth, authSellerController.updatePassword);

sellerRouter.put("/email", sellerAuth, authSellerController.updateEmail);

sellerRouter.get("/check-seller", async (req, res) => {
  try {
    const token = req.cookies?.SID || req.headers.authorization?.split(" ")[1];
    if (!token) return res.json({ isSeller: false });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const isSeller = decoded.type === "seller";

    res.json({
      isSeller,
      sellerUuid: isSeller ? decoded.uuid : null,
    });
  } catch (error) {
    res.json({ isSeller: false });
  }
});
export default sellerRouter;
