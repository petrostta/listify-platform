import express from "express";
import authUserController from "../controllers/authUserController.js";
import userAuth from "../middleware/userAuth.js";

const userRouter = express.Router();

userRouter.post("/register", authUserController.registerUser);

userRouter.post("/login", authUserController.loginUser);

userRouter.post("/logout", authUserController.logoutUser);

userRouter.put("/password", userAuth, authUserController.updatePassword);

userRouter.put("/email", userAuth, authUserController.updateEmail);

export default userRouter;
