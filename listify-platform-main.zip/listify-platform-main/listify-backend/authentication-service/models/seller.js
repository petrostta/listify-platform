import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const sellerAuthenticationSchema = new mongoose.Schema({
  uuid: { type: String, default: uuidv4, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});

const authSellerModel =
  mongoose.models.seller ||
  mongoose.model("seller", sellerAuthenticationSchema);

export default authSellerModel;
