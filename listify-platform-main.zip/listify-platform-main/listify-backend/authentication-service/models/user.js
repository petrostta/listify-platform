import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const userAuthenticationSchema = new mongoose.Schema({
  uuid: { type: String, default: uuidv4, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});

const authUserModel =
  mongoose.models.user || mongoose.model("user", userAuthenticationSchema);

export default authUserModel;
