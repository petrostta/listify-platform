import authUserModel from "../models/user.js";
import bcrypt from "bcrypt";
import validator from "validator";
import jwt from "jsonwebtoken";
import { publishUserProfileEvent } from "../utils/eventPublisher.js";

const registerUser = async (req, res) => {
  try {
    const { email, password, first_name, last_name, phone_number } = req.body;

    const existingUser = await authUserModel.findOne({ email });

    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    if (!validator.isEmail(email)) {
      return res.status(400).json({ message: "Invalid email" });
    }

    const passwordPolicy =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+[\]{}|;:,.<>?]).{8,}$/;
    const noIdenticalCharachters = /(.)\1{2,}/;

    if (
      !password ||
      !passwordPolicy.test(password) ||
      noIdenticalCharachters.test(password)
    ) {
      return res.status(400).json({ message: "Password is too weak" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = new authUserModel({ email, password: hashedPassword });

    await user.save();

    publishUserProfileEvent({
      uuid: user.uuid,
      first_name,
      last_name,
      phone_number,
    });

    res.status(201).json({ uuid: user.uuid, email: user.email });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    console.log("Login attempt for email:", email);

    const user = await authUserModel.findOne({ email });
    console.log("User found for login:", user ? "YES" : "NO");

    if (!user) {
      return res.status(404).json({ message: "Invalid Credentials" });
    }

    console.log("Comparing login password for user:", user.uuid);
    const isMatch = await bcrypt.compare(password, user.password);
    console.log("Login password matches:", isMatch);

    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign(
      { uuid: user.uuid, type: "user" },
      process.env.JWT_SECRET,
      { expiresIn: "24h" }
    );

    res.cookie("SID", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 24 * 60 * 60 * 1000,
    });

    res.json({ token, uuid: user.uuid });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

const logoutUser = async (req, res) => {
  try {
    res.clearCookie("SID", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
    });
    res.status(200).json({ message: "Logout successful" });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

const updatePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        message: "Current password and new password are required",
      });
    }

    const user = await authUserModel.findOne({ uuid: req.user.uuid });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const isMatch = await bcrypt.compare(currentPassword, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Current password is incorrect" });
    }

    const isSamePassword = await bcrypt.compare(newPassword, user.password);
    if (isSamePassword) {
      return res.status(400).json({
        message: "New password cannot be the same as current password",
      });
    }

    const passwordPolicy =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-[\]{}|;:,.<>?]).{8,}$/;
    const noIdenticalCharacters = /(.)\1{2,}/;

    if (
      !passwordPolicy.test(newPassword) ||
      noIdenticalCharacters.test(newPassword)
    ) {
      return res.status(400).json({
        message: "Password does not meet the requirements.",
      });
    }

    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();

    return res.status(200).json({
      message: "Password updated successfully.",
      success: true,
    });
  } catch (error) {
    console.error("Error updating password:", error);
    return res.status(500).json({
      message: "Server error",
      error: error.message,
    });
  }
};

const updateEmail = async (req, res) => {
  try {
    const { newEmail } = req.body;
    const email = newEmail?.toLowerCase().trim();

    if (!validator.isEmail(email)) {
      return res
        .status(400)
        .json({ message: "Please provide a valid email address" });
    }

    const user = await authUserModel.findOne({ uuid: req.user.uuid });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    if (user.email.toLowerCase() === email) {
      return res
        .status(400)
        .json({ message: "This is already your current email address" });
    }

    const existingUser = await authUserModel.findOne({ email });
    if (existingUser && existingUser.uuid !== user.uuid) {
      return res
        .status(400)
        .json({ message: "This email address is already in use" });
    }

    const oldEmail = user.email;
    user.email = email;
    await user.save();

    return res.status(200).json({
      message: "Email updated successfully",
      newEmail: email,
      success: true,
    });
  } catch (error) {
    console.error("Error updating email:", error);
    return res
      .status(500)
      .json({ message: "Server error", error: error.message });
  }
};

export default {
  registerUser,
  loginUser,
  logoutUser,
  updateEmail,
  updatePassword,
};
