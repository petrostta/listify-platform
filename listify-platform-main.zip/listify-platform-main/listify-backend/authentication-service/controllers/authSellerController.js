import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import validator from "validator";
import authSellerModel from "../models/seller.js";
import { publishSellerProfileEvent } from "../utils/eventPublisher.js";

const registerSeller = async (req, res) => {
  const { email, password, business_Name, contact_email } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const existingSeller = await authSellerModel.findOne({ email });

    if (existingSeller) {
      return res.status(400).json({ message: "Seller already exists" });
    }

    const emailValidator = validator.isEmail(email);

    if (!emailValidator) {
      return res.status(400).json({ message: "Invalid email" });
    }

    const passwordPolicy =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+[\]{}|;:,.<>?]).{8,}$/;
    const noIdenticalCharachters = /(.)\1{2,}/;

    if (
      !password ||
      !passwordPolicy.test(password) ||
      noIdenticalCharachters.test(password)
    ) {
      return res.status(400).json({ message: "Password is too weak" });
    }

    const seller = new authSellerModel({
      email,
      password: hashedPassword,
    });

    await seller.save();

    publishSellerProfileEvent({
      uuid: seller.uuid,
      business_Name,
      contact_email,
    });

    res.status(201).json({ uuid: seller.uuid, email: seller.email });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Server error", error: error.message });
  }
};

const loginSeller = async (req, res) => {
  try {
    const { email, password } = req.body;

    const seller = await authSellerModel.findOne({ email });
    if (!seller) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, seller.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign(
      {
        uuid: seller.uuid,
        type: "seller",
        role: "seller",
      },
      process.env.JWT_SECRET,
      { expiresIn: "24h" }
    );

    res.cookie("SID", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
    });

    res.json({ token, uuid: seller.uuid });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

const logoutSeller = async (req, res) => {
  try {
    res.clearCookie("SID", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
    });
    res.status(200).json({ message: "Logout successful" });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Server error", error: error.message });
  }
};

const updatePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        message: "Current password and new password are required",
      });
    }

    const seller = await authSellerModel.findOne({ uuid: req.seller.uuid });

    if (!seller) {
      return res.status(404).json({ message: "Seller not found" });
    }

    const isMatch = await bcrypt.compare(currentPassword, seller.password);

    if (!isMatch) {
      return res.status(400).json({ message: "Current password is incorrect" });
    }

    const isSamePassword = await bcrypt.compare(newPassword, seller.password);

    if (isSamePassword) {
      return res.status(400).json({
        message: "New password can not be the same as current password",
      });
    }

    const passwordPolicy =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-[\]{}|;:,.<>?]).{8,}$/;
    const noIdenticalCharacters = /(.)\1{2,}/;

    if (
      !passwordPolicy.test(newPassword) ||
      noIdenticalCharacters.test(newPassword)
    ) {
      return res.status(400).json({
        message: "Password does not meet the requirements.",
      });
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);

    seller.password = hashedNewPassword;

    const saveResult = await seller.save();

    const updatedSeller = await authSellerModel.findOne({
      uuid: req.seller.uuid,
    });
    const verifyNewPassword = await bcrypt.compare(
      newPassword,
      updatedSeller.password
    );

    return res.status(200).json({
      message: "Password updated successfully.",
      success: true,
    });
  } catch (error) {
    console.error("Error updating password:", error);
    return res.status(500).json({
      message: "Server error",
      error: error.message,
    });
  }
};

const updateEmail = async (req, res) => {
  try {
    const { newEmail } = req.body;
    const email = newEmail?.toLowerCase().trim();

    if (!validator.isEmail(email)) {
      return res
        .status(400)
        .json({ message: "Please provide a valid email address" });
    }

    const seller = await authSellerModel.findOne({ uuid: req.seller.uuid });

    if (!seller) {
      return res.status(404).json({ message: "Seller not found" });
    }

    if (seller.email.toLowerCase() === email) {
      return res
        .status(400)
        .json({ message: "This is already your current email address" });
    }

    const existingSeller = await authSellerModel.findOne({ email });
    if (existingSeller && existingSeller.uuid !== seller.uuid) {
      return res
        .status(400)
        .json({ message: "This email address is already in use" });
    }

    const oldEmail = seller.email;
    seller.email = email;
    await seller.save();

    return res.status(200).json({
      message: "Email updated successfully",
      newEmail: email,
      success: true,
    });
  } catch (error) {
    console.error("Error updating email:", error);
    return res
      .status(500)
      .json({ message: "Server error", error: error.message });
  }
};

export default {
  registerSeller,
  loginSeller,
  logoutSeller,
  updateEmail,
  updatePassword,
};
