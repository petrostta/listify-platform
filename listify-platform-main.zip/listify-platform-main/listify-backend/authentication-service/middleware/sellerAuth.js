import jwt from "jsonwebtoken";

const sellerAuth = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    const token =
      authHeader && authHeader.startsWith("Bearer ")
        ? authHeader.slice(7)
        : req.cookies?.jwt;

    if (!token) {
      return res
        .status(401)
        .json({ message: "No token, authorization denied" });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.type !== "seller") {
      return res.status(401).json({ message: "Invalid seller token" });
    }

    req.seller = decoded;
    next();
  } catch (error) {
    console.error("Seller auth middleware error:", error);
    return res.status(401).json({ message: "Token is not valid" });
  }
};

export default sellerAuth;
