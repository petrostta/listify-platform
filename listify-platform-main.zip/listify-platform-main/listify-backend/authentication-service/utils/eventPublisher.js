import amqp from "amqplib";

let channel;
let connection;

export const connectAuthMQ = async () => {
  try {
    connection = await amqp.connect(process.env.RABBITMQ_URI);
    channel = await connection.createChannel();

    await channel.assertQueue("USER_PROFILE_CREATED");
    await channel.assertQueue("SELLER_PROFILE_CREATED");

    console.log("Connected to RabbitMQ");
    return channel;
  } catch (error) {
    console.error("RabbitMQ Connection Error:", error);
    setTimeout(connectAuthMQ, 5000);
  }
};

export const publishUserProfileEvent = (userData) => {
  if (!channel) {
    throw new Error("RabbitMQ channel not initialized");
  }

  return channel.sendToQueue(
    "USER_PROFILE_CREATED",
    Buffer.from(JSON.stringify(userData))
  );
};

export const publishSellerProfileEvent = (sellerData) => {
  if (!channel) {
    throw new Error("RabbitMQ channel not initialized");
  }

  return channel.sendToQueue(
    "SELLER_PROFILE_CREATED",
    Buffer.from(JSON.stringify(sellerData))
  );
};

export const getChannel = () => channel;
