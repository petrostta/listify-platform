import express from "express";
import cookieParser from "cookie-parser";
import authUserRoutes from "./routes/authUserRoutes.js";
import authSellerRoutes from "./routes/authSellerRoutes.js";
import dotenv from "dotenv";
import cors from "cors";
import { connectDB } from "./config/db.js";
import { connectAuthMQ } from "./utils/eventPublisher.js";

dotenv.config();

const app = express();
const port = process.env.PORT || 3100;

app.use(express.json());
app.use(cookieParser());

connectDB();

app.use("/api/users", authUserRoutes);
app.use("/api/sellers", authSellerRoutes);

connectAuthMQ().then(() => {
  app.listen(port, () =>
    console.log(`Authentication Service running on port ${port}`)
  );
});
