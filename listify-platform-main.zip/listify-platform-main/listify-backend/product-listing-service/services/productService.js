import { EventEmitter } from "events";
import amqplib from "amqplib";
import Product from "../models/product.js";
import redis from "../config/redis.js";
import {
  publishInventoryEvent,
  publishProductEvent,
} from "../utils/productEventPublisher.js";
import dotenv from "dotenv";

dotenv.config();

export class ProductService extends EventEmitter {
  constructor() {
    super();
    this.connection = null;
    this.channel = null;
  }

  async initialize() {
    try {
      console.log("Initializing ProductService...");
      await this.setupInventoryEventListeners();
      console.log("ProductService initialized successfully");
    } catch (error) {
      console.error("ProductService initialization failed:", error);
      throw error;
    }
  }

  async setupInventoryEventListeners() {
    try {
      console.log("Setting up product service inventory event listeners...");

      this.connection = await amqplib.connect(process.env.RABBITMQ_URL);

      this.connection.on("error", (err) => {
        console.error(
          "Product Service RabbitMQ connection error:",
          err.message
        );
      });

      this.connection.on("close", () => {
        console.warn(
          "Product Service RabbitMQ connection closed, attempting to reconnect..."
        );
        setTimeout(() => this.setupInventoryEventListeners(), 5000);
      });

      this.channel = await this.connection.createChannel();

      await this.channel.assertExchange("inventory_events", "topic", {
        durable: true,
      });
      const { queue } = await this.channel.assertQueue(
        "product_service_inventory_queue",
        { durable: true }
      );

      await this.channel.bindQueue(
        queue,
        "inventory_events",
        "INVENTORY_RESERVE_REQUEST"
      );
      await this.channel.bindQueue(
        queue,
        "inventory_events",
        "INVENTORY_RELEASE_REQUEST"
      );

      this.channel.consume(queue, async (msg) => {
        if (!msg) return;

        try {
          const event = JSON.parse(msg.content.toString());
          console.log(
            `[PRODUCT-SERVICE] Received inventory event: ${event.type} for product ${event.productId}`
          );
          await this.handleInventoryEvent(event);
          this.channel.ack(msg);
        } catch (error) {
          console.error("Error processing inventory event:", error);
          this.channel.ack(msg);
        }
      });

      console.log("Product service inventory event listeners connected");
    } catch (error) {
      console.error(
        "Error setting up product service inventory listeners:",
        error
      );
      setTimeout(() => this.setupInventoryEventListeners(), 5000);
    }
  }

  async handleInventoryEvent(event) {
    console.log(
      `[PRODUCT-SERVICE] Processing ${event.type} for product ${event.productId}`
    );

    switch (event.type) {
      case "INVENTORY_RESERVE_REQUEST":
        await this.handleInventoryReservation(event);
        break;
      case "INVENTORY_RELEASE_REQUEST":
        await this.handleInventoryRelease(event);
        break;
      default:
        console.warn(`Unhandled inventory event type: ${event.type}`);
    }
  }

  async handleInventoryReservation(event) {
    try {
      const { productId, variantId, quantity, orderId, sagaId } = event;

      console.log(
        `[INVENTORY:RESERVE] Processing reservation - product: ${productId}, variant: ${
          variantId || "none"
        }, quantity: ${quantity}`
      );

      if (!quantity || quantity <= 0) {
        console.error(`Invalid quantity: ${quantity}`);
        await publishInventoryEvent("INVENTORY_RESERVATION_FAILED", {
          productId,
          variantId,
          quantity,
          orderId,
          sagaId,
          reason: "Invalid quantity",
        });
        return;
      }

      const product = await Product.findOne({ uuid: productId });
      if (!product) {
        console.error(`Product not found: ${productId}`);
        await publishInventoryEvent("INVENTORY_RESERVATION_FAILED", {
          productId,
          variantId,
          quantity,
          orderId,
          sagaId,
          reason: "Product not found",
        });
        return;
      }

      let stockReduced = false;
      let newStock = 0;

      if (variantId && variantId !== `${productId}-default`) {
        const variant = product.variants.find((v) => v.uuid === variantId);
        if (!variant) {
          console.error(`Variant not found: ${variantId}`);
          await publishInventoryEvent("INVENTORY_RESERVATION_FAILED", {
            productId,
            variantId,
            quantity,
            orderId,
            sagaId,
            reason: "Variant not found",
          });
          return;
        }

        if (variant.stock < quantity) {
          console.error(
            `Insufficient variant stock: ${variant.stock} < ${quantity}`
          );
          await publishInventoryEvent("INVENTORY_RESERVATION_FAILED", {
            productId,
            variantId,
            quantity,
            orderId,
            sagaId,
            reason: "Insufficient stock",
          });
          return;
        }

        console.log(
          `Reducing variant stock: ${variant.stock} - ${quantity} = ${
            variant.stock - quantity
          }`
        );
        variant.stock -= quantity;
        newStock = variant.stock;
        stockReduced = true;
      } else {
        if (product.stock < quantity) {
          console.error(
            `Insufficient product stock: ${product.stock} < ${quantity}`
          );
          await publishInventoryEvent("INVENTORY_RESERVATION_FAILED", {
            productId,
            variantId,
            quantity,
            orderId,
            sagaId,
            reason: "Insufficient stock",
          });
          return;
        }

        console.log(
          `Reducing product stock: ${product.stock} - ${quantity} = ${
            product.stock - quantity
          }`
        );
        product.stock -= quantity;
        newStock = product.stock;
        stockReduced = true;
      }

      if (stockReduced) {
        await product.save();

        await this.invalidateProductCaches(productId, product.seller);

        await publishInventoryEvent("INVENTORY_RESERVED", {
          productId,
          variantId,
          quantity,
          newStock,
          orderId,
          sagaId,
        });

        await publishProductEvent("PRODUCT_STOCK_UPDATED", {
          ...product.toObject(),
          uuid: product.uuid,
        });

        console.log(
          `[INVENTORY:RESERVE] Successfully reserved ${quantity} units for product ${productId} (new stock: ${newStock})`
        );
      }
    } catch (error) {
      console.error("Error handling inventory reservation:", error);

      await publishInventoryEvent("INVENTORY_RESERVATION_FAILED", {
        productId: event.productId,
        variantId: event.variantId,
        quantity: event.quantity,
        orderId: event.orderId,
        sagaId: event.sagaId,
        reason: error.message,
      });
    }
  }

  async handleInventoryRelease(event) {
    try {
      const { productId, variantId, quantity, orderId, sagaId } = event;

      console.log(
        `[INVENTORY:RELEASE] Processing release - product: ${productId}, variant: ${
          variantId || "none"
        }, quantity: ${quantity}`
      );

      const product = await Product.findOne({ uuid: productId });
      if (!product) {
        console.warn(`[INVENTORY:RELEASE] Product not found: ${productId}`);
        return;
      }

      let stockRestored = false;
      let newStock = 0;

      if (variantId && variantId !== `${productId}-default`) {
        const variant = product.variants.find((v) => v.uuid === variantId);
        if (variant) {
          console.log(
            `Restoring variant stock: ${variant.stock} + ${quantity} = ${
              variant.stock + quantity
            }`
          );
          variant.stock += quantity;
          newStock = variant.stock;
          stockRestored = true;
        }
      } else {
        console.log(
          `Restoring product stock: ${product.stock} + ${quantity} = ${
            product.stock + quantity
          }`
        );
        product.stock += quantity;
        newStock = product.stock;
        stockRestored = true;
      }

      if (stockRestored) {
        await product.save();

        await this.invalidateProductCaches(productId, product.seller);

        await publishInventoryEvent("INVENTORY_RELEASED", {
          productId,
          variantId,
          quantity,
          newStock,
          orderId,
          sagaId,
        });

        await publishProductEvent("PRODUCT_STOCK_UPDATED", {
          ...product.toObject(),
          uuid: product.uuid,
        });

        console.log(
          `[INVENTORY:RELEASE] Successfully released ${quantity} units for product ${productId} (new stock: ${newStock})`
        );
      }
    } catch (error) {
      console.error("Error handling inventory release:", error);
    }
  }

  async invalidateProductCaches(productId, sellerId) {
    try {
      console.log(
        `[CACHE:INVALIDATE] Clearing caches for product ${productId}`
      );

      await redis.del(`product:${productId}`);

      await redis.del(`product_combined:${productId}`);

      const sellerKeys = await redis.keys(`products:seller:${sellerId}:*`);
      if (sellerKeys.length > 0) {
        await redis.del(sellerKeys);
        console.log(
          `[CACHE:INVALIDATE] Cleared ${sellerKeys.length} seller cache entries`
        );
      }

      const listKeys = await redis.keys(`products:list:*`);
      if (listKeys.length > 0) {
        await redis.del(listKeys);
        console.log(
          `[CACHE:INVALIDATE] Cleared ${listKeys.length} product list cache entries`
        );
      }

      const searchKeys = await redis.keys(`search:*${productId}*`);
      if (searchKeys.length > 0) {
        await redis.del(searchKeys);
        console.log(
          `[CACHE:INVALIDATE] Cleared ${searchKeys.length} search cache entries`
        );
      }

      console.log(
        `[CACHE:INVALIDATE] Successfully invalidated all caches for product ${productId}`
      );
    } catch (error) {
      console.error(
        `[CACHE:INVALIDATE] Error invalidating caches for product ${productId}:`,
        error
      );
    }
  }

  async handleProductEvent(event) {
    switch (event.type) {
      case "PRODUCT_CREATED":
      case "PRODUCT_UPDATED":
        await redis.setex(`product:${event.uuid}`, 3600, JSON.stringify(event));
        break;
      case "PRODUCT_DELETED":
        await redis.del(`product:${event.uuid}`);
        break;
    }
  }
}

// export
export const productService = new ProductService();
