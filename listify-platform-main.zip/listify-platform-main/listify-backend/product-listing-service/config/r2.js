import {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import dotenv from "dotenv";

dotenv.config();

const s3Client = new S3Client({
  region: "auto",
  endpoint: process.env.R2_ENDPOINT,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY,
    secretAccessKey: process.env.R2_SECRET_KEY,
  },
});

const bucketName = process.env.R2_BUCKET_NAME;

export const generateUploadURL = async (key, contentType, expiresIn = 3600) => {
  try {
    const command = new PutObjectCommand({
      Bucket: bucketName,
      Key: key,
      ContentType: contentType,
    });

    const signedUrl = await getSignedUrl(s3Client, command, { expiresIn });

    console.log(`Generated upload URL for ${key}`);
    return signedUrl;
  } catch (error) {
    console.error(`Error generating upload URL for ${key}:`, error);
    throw error;
  }
};

export const deleteObject = async (key) => {
  try {
    const command = new DeleteObjectCommand({
      Bucket: bucketName,
      Key: key,
    });

    await s3Client.send(command);
    console.log(`Successfully deleted object: ${key}`);
  } catch (error) {
    console.error(`Error deleting object ${key}:`, error);
    throw error;
  }
};

export const getPublicUrl = (key) => {
  return `${process.env.R2_PUBLIC_URL}/${key}`;
};

export default {
  generateUploadURL,
  deleteObject,
  getPublicUrl,
  s3Client,
};
