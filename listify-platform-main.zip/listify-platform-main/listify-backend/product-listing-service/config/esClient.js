import { Client as ESClient } from "@elastic/elasticsearch";
import dotenv from "dotenv";

dotenv.config();

const esClient = new ESClient({
  node: process.env.ES_NODE,
  ssl: {
    rejectUnauthorized: false,
  },
  sniffOnStart: false,
  sniffInterval: false,
  sniffOnConnectionFault: false,
});

export default esClient;
