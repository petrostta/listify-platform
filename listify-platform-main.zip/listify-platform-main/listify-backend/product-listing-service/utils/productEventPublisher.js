import amqplib from "amqplib";
import dotenv from "dotenv";

dotenv.config();

let channel;
let connection;

export const connectProductMQ = async (retries = 5, delay = 2000) => {
  let attempt = 0;
  while (attempt < retries) {
    try {
      console.log(
        `Connecting to RabbitMQ (attempt ${attempt + 1}/${retries})...`
      );

      connection = await amqplib.connect(process.env.RABBITMQ_URL);

      connection.on("error", (err) => {
        console.error("RabbitMQ connection error:", err.message);
      });

      connection.on("close", () => {
        console.warn("RabbitMQ connection closed, attempting to reconnect...");
        channel = null;
        setTimeout(() => connectProductMQ(), 5000);
      });

      channel = await connection.createChannel();

      // Create exchanges for different event types
      await channel.assertExchange("product_data_events", "topic", {
        durable: true,
      });
      await channel.assertExchange("inventory_events", "topic", {
        durable: true,
      });

      console.log("Product service connected to RabbitMQ");
      return true;
    } catch (error) {
      attempt++;
      console.error(
        `RabbitMQ connection failed (attempt ${attempt}/${retries}):`,
        error.message
      );

      if (channel) {
        try {
          await channel.close();
        } catch (e) {
          console.error("Error closing channel:", e);
        }
        channel = null;
      }

      if (connection) {
        try {
          await connection.close();
        } catch (e) {
          console.error("Error closing connection:", e);
        }
        connection = null;
      }

      if (attempt < retries) {
        console.log(`Retrying in ${delay / 1000} seconds...`);
        await new Promise((res) => setTimeout(res, delay));
        delay *= 2;
      } else {
        console.error(
          "Could not connect to RabbitMQ after multiple attempts, exiting."
        );
        process.exit(1);
      }
    }
  }
};

export const publishProductEvent = async (eventType, product) => {
  if (!channel) {
    console.error("RabbitMQ channel is not available");
    try {
      console.log("Attempting to reconnect to RabbitMQ...");
      await connectProductMQ();
      if (!channel) {
        console.error("Failed to reconnect, event not published");
        return false;
      }
    } catch (error) {
      console.error("Error reconnecting to RabbitMQ:", error);
      return false;
    }
  }

  if (!product || !product.uuid) {
    console.error("Cannot publish event: Invalid product data", product);
    return false;
  }

  try {
    const eventPayload = {
      type: eventType,
      productId: product.uuid,
      name: product.name,
      description: product.description,
      category: product.category,
      original_price: product.original_price,
      discount: product.discount,
      stock: product.stock,
      isAvailable: product.isAvailable,
      pictures: product.pictures,
      variants: product.variants,
      seller: product.seller,
      timestamp: new Date().toISOString(),
    };

    console.log(`Publishing ${eventType} event for product ${product.uuid}`);

    const published = channel.publish(
      "product_data_events",
      eventType,
      Buffer.from(JSON.stringify(eventPayload)),
      { persistent: true }
    );

    if (published) {
      console.log(`Published ${eventType} event for product ${product.uuid}`);
      return true;
    } else {
      console.warn(
        `Channel buffer full, ${eventType} event for product ${product.uuid} not published`
      );
      return false;
    }
  } catch (error) {
    console.error(`Error publishing ${eventType} event:`, error);

    if (
      error.message.includes("channel closed") ||
      error.message.includes("connection closed")
    ) {
      channel = null;
    }

    return false;
  }
};

export const publishInventoryEvent = async (eventType, inventoryData) => {
  if (!channel) {
    console.error("RabbitMQ channel not available");
    return false;
  }

  try {
    const eventPayload = {
      type: eventType,
      productId: inventoryData.productId,
      variantId: inventoryData.variantId,
      quantity: inventoryData.quantity,
      newStock: inventoryData.newStock,
      orderId: inventoryData.orderId,
      sagaId: inventoryData.sagaId,
      reason: inventoryData.reason,
      timestamp: new Date().toISOString(),
    };

    console.log(
      `Publishing ${eventType} inventory event for product ${inventoryData.productId}`
    );

    return channel.publish(
      "inventory_events",
      eventType,
      Buffer.from(JSON.stringify(eventPayload)),
      { persistent: true }
    );
  } catch (error) {
    console.error("Error publishing inventory event:", error);
    return false;
  }
};
