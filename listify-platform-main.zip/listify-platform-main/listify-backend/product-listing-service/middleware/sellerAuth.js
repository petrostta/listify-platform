import jwt from "jsonwebtoken";

const sellerAuth = async (req, res, next) => {
  try {
    const token = req.cookies?.SID || req.headers.authorization?.split(" ")[1];

    if (!token) throw new Error("Authentication required");

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.type !== "seller") {
      throw new Error("Seller privileges required");
    }

    req.seller = decoded;
    next();
  } catch (error) {
    res.status(401).json({ message: error.message });
  }
};

export default sellerAuth;
