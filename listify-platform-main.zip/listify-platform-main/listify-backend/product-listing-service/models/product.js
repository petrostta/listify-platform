import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const variantSchema = new mongoose.Schema(
  {
    uuid: { type: String, default: uuidv4, unique: true },
    original_price: { type: Number, required: true },
    discount: { type: Number, default: 0 },
    description: String,
    stock: { type: Number, required: true },
    pictures: [
      {
        key: { type: String, required: true },
        url: { type: String, required: true },
        altText: String,
        width: Number,
        height: Number,
      },
    ],
    attributes: [
      {
        key: { type: String, required: true },
        value: { type: String, required: true },
      },
    ],
  },
  { _id: false }
);

const productSchema = new mongoose.Schema({
  uuid: { type: String, default: uuidv4, unique: true },
  name: { type: String, required: true, index: true },
  description: { type: String, required: true },
  original_price: { type: Number, required: true },
  discount: { type: Number, default: 0 },
  pictures: [
    {
      key: { type: String, required: true },
      url: { type: String, required: true },
      altText: String,
      width: Number,
      height: Number,
    },
  ],
  stock: { type: Number, required: true },
  seller: { type: String, required: true, index: true },
  category: { type: String, required: true, index: true },
  isAvailable: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  variants: [variantSchema],
  attributes: [
    {
      key: { type: String, required: true },
      value: { type: String, required: true },
    },
  ],
  variantAttributes: [{ type: String }],

  variants: [variantSchema],
});

productSchema.pre("save", function (next) {
  this.updatedAt = Date.now();
  next();
});

productSchema.virtual("calculatedPrice").get(function () {
  return this.original_price * (1 - this.discount / 100);
});

productSchema.index({ seller: 1, category: 1 });
productSchema.index({ calculatedPrice: 1 });
productSchema.index({ createdAt: -1 });

export default mongoose.model("Product", productSchema);
