import express from "express";
import productController from "../controllers/productController.js";
import sellerAuth from "../middleware/sellerAuth.js";
import redis from "../config/redis.js";

const productRouter = express.Router();

//internal routes
productRouter.post(
  "/:productId/upload-url",
  sellerAuth,
  productController.generateImageUploadUrl
);

productRouter.post(
  "/:productId/images",
  sellerAuth,
  productController.deleteProductImage
);

productRouter.post("/:id/invalidate-cache", async (req, res) => {
  const productId = req.params.id;
  try {
    await redis.del(`product:${productId}`);
    await redis.del(`product_combined:${productId}`);
    res.json({ message: "Cache invalidated" });
  } catch (err) {
    res.status(500).json({ message: "Failed to invalidate cache" });
  }
});

//public routes
productRouter.get("/", productController.getAllProducts);

productRouter.post("/", sellerAuth, productController.createProduct);
productRouter.put("/:id", sellerAuth, productController.updateProduct);
productRouter.delete("/:id", sellerAuth, productController.deleteProduct);
productRouter.get(
  "/seller/",
  sellerAuth,
  productController.getProductBySellers
);

productRouter.get(
  "/seller/:sellerId/ids",
  sellerAuth,
  productController.getSellerProductIds
);

productRouter.get("/:id", productController.getProduct);
productRouter.get("/:id/combined", productController.getProductWithReviews);

export default productRouter;
