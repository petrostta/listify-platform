import express from "express";
import productRouter from "./routes/productRoutes.js";
import cors from "cors";
import dotenv from "dotenv";
import { connectDB } from "./config/db.js";
import { connectProductMQ } from "./utils/productEventPublisher.js";
import { ProductService } from "./services/productService.js";

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

connectDB();
connectProductMQ();

const productService = new ProductService();
productService
  .initialize()
  .then(() => {
    console.log("Product service inventory management initialized");
  })
  .catch((error) => {
    console.error("Failed to initialize product service:", error);
  });

app.use("/api/products", productRouter);

app.get("/", (req, res) => {
  res.send("Product Listing Service running with inventory management");
});

app.listen(port, () => {
  console.log(`Product Listing Service running on port ${port}`);
  console.log("Inventory management enabled");
});
