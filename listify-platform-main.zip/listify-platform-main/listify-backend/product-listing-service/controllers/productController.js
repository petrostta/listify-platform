import Product from "../models/product.js";
import { generateUploadURL, deleteObject } from "../config/r2.js";
import { v4 as uuidv4 } from "uuid";
import { publishProductEvent } from "../utils/productEventPublisher.js";
import redis from "../config/redis.js";

const validateProductOwnership = async (productId, sellerId) => {
  const product = await Product.findOne({ uuid: productId, seller: sellerId });
  if (!product) throw new Error("Product not found or authorized");
  return product;
};

const generateImageUploadUrl = async (req, res) => {
  try {
    const { productId } = req.params;
    const { fileType } = req.body;
    const sellerId = req.seller.uuid;

    if (productId !== "temp") {
      await validateProductOwnership(productId, sellerId);
    }

    const fileName = `products/${uuidv4()}.${fileType}`;
    const url = await generateUploadURL(fileName, fileType);

    res.json({
      uploadUrl: url,
      fileKey: fileName,
      publicUrl: `${process.env.R2_PUBLIC_URL}/${fileName}`,
    });
  } catch (error) {
    console.error("Error generating upload URL:", error);
    res.status(400).json({ message: error.message });
  }
};

const createProduct = async (req, res) => {
  try {
    const { seller } = req;
    const productData = {
      ...req.body,
      seller: seller.uuid,
      pictures: req.body.pictures.map((img) => ({
        ...img,
        url: `${process.env.R2_PUBLIC_URL}/${img.key}`,
      })),
      variantAttributes: req.body.variantAttributes || [],
    };

    const product = new Product(productData);
    await product.save();

    await publishProductEvent("PRODUCT_CREATED", product);
    res.status(201).json(product);
  } catch (error) {
    console.error("Error creating product:", error);
    res.status(400).json({ message: error.message });
  }
};

const getAllProducts = async (req, res) => {
  try {
    const {
      limit = 10,
      page = 1,
      category = null,
      sort = "createdAt",
      order = "desc",
    } = req.query;

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const cacheKey = `products:list:${limitNum}:${pageNum}:${
      category || "all"
    }:${sort}:${order}`;

    try {
      const cachedData = await redis.get(cacheKey);
      if (cachedData) {
        return res.json(JSON.parse(cachedData));
      }
    } catch (cacheError) {
      console.error("Redis cache error:", cacheError);
    }

    const query = { isAvailable: true };
    if (category) {
      query.category = category;
    }

    const sortOptions = {};
    sortOptions[sort] = order === "desc" ? -1 : 1;

    const productsPromise = Product.find(query)
      .select(
        "uuid name description category original_price discount stock pictures"
      )
      .sort(sortOptions)
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum)
      .lean();

    const countPromise = Product.countDocuments(query);
    const [products, total] = await Promise.all([
      productsPromise,
      countPromise,
    ]);

    const productsWithDefaults = products.map((product) => ({
      ...product,
      rating: 0,
      reviewCount: 0,
    }));

    const response = {
      products: productsWithDefaults,
      page: pageNum,
      limit: limitNum,
      total,
      totalPages: Math.ceil(total / limitNum),
    };

    await redis.setex(cacheKey, 300, JSON.stringify(response));
    res.json(response);
  } catch (error) {
    console.error("Error fetching all products:", error);
    res.status(500).json({ message: error.message });
  }
};

const updateProduct = async (req, res) => {
  try {
    const { seller } = req;
    const existingProduct = await Product.findOne({
      uuid: req.params.id,
      seller: seller.uuid,
    });

    if (!existingProduct) throw new Error("Product not found or authorized");

    const updatedData = {
      ...req.body,
      pictures: req.body.pictures?.map((img) => ({
        ...img,
        url: `${process.env.R2_PUBLIC_URL}/${img.key}`,
      })),
    };

    if (updatedData.variants) {
      updatedData.variants = updatedData.variants.map((variant) => ({
        ...variant,
        pictures: variant.pictures?.map((img) => ({
          ...img,
          url: `${process.env.R2_PUBLIC_URL}/${img.key}`,
        })),
      }));
    }

    const newImageKeys = new Set([
      ...(updatedData.pictures || []).map((img) => img.key),
      ...(updatedData.variants || []).flatMap((variant) =>
        (variant.pictures || []).map((img) => img.key)
      ),
    ]);

    const oldImageKeys = [
      ...(existingProduct.pictures || []).map((img) => img.key),
      ...(existingProduct.variants || []).flatMap((variant) =>
        (variant.pictures || []).map((img) => img.key)
      ),
    ];

    const imagesToDelete = oldImageKeys.filter((key) => !newImageKeys.has(key));

    const product = await Product.findOneAndUpdate(
      { uuid: req.params.id, seller: seller.uuid },
      updatedData,
      { new: true, runValidators: true }
    );

    if (imagesToDelete.length > 0) {
      try {
        await Promise.all(imagesToDelete.map((key) => deleteObject(key)));
        console.log(
          `Deleted ${imagesToDelete.length} unused images from R2 storage`
        );
      } catch (deleteError) {
        console.error("Error deleting unused images:", deleteError);
      }
    }

    await redis.del(`product:${product.uuid}`);

    const sellerCacheKeys = await redis.keys(
      `products:seller:${seller.uuid}:*`
    );
    if (sellerCacheKeys.length > 0) {
      await redis.del(sellerCacheKeys);
    }

    await publishProductEvent("PRODUCT_UPDATED", product);
    res.json(product);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

const deleteProductImage = async (req, res) => {
  try {
    const { productId } = req.params;
    const { imageKey } = req.body;
    const sellerId = req.seller.uuid;

    await validateProductOwnership(productId, sellerId);
    await deleteObject(imageKey);

    const product = await Product.findOneAndUpdate(
      { uuid: productId },
      { $pull: { pictures: { key: imageKey } } },
      { new: true }
    );
    res.json(product);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

const getSellerProductIds = async (req, res) => {
  try {
    const { sellerId } = req.params;
    const productIds = await Product.find(
      { seller: sellerId },
      { uuid: 1, _id: 0 }
    ).lean();

    const ids = productIds.map((product) => product.uuid);
    res.json({ productIds: ids });
  } catch (error) {
    console.error("Error getting seller product IDs:", error);
    res.status(500).json({
      message: "Failed to retrieve product IDs",
      error: error.message,
    });
  }
};

const getProduct = async (req, res) => {
  try {
    const productId = req.params.id;
    const cacheKey = `product:${productId}`;

    let cachedProduct;
    try {
      cachedProduct = await redis.get(cacheKey);
      if (cachedProduct) {
        return res.json(JSON.parse(cachedProduct));
      }
    } catch (redisError) {
      if (redisError.message.includes("WRONGTYPE")) {
        try {
          const hashData = await redis.hgetall(cacheKey);
          if (hashData && Object.keys(hashData).length > 0) {
            await redis.del(cacheKey);
          }
        } catch (e) {
          console.error("Error handling Redis hash:", e);
        }
      } else {
        console.error("Redis error:", redisError);
      }
    }

    const product = await Product.findOne({ uuid: productId });
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    await redis.setex(cacheKey, 3600, JSON.stringify(product));
    return res.json(product);
  } catch (error) {
    console.error("Error in getProduct:", error);
    return res.status(400).json({ message: error.message });
  }
};

const deleteProduct = async (req, res) => {
  try {
    const { seller } = req;
    console.log(`Starting product deletion process for ${req.params.id}`);

    const product = await Product.findOneAndDelete({
      uuid: req.params.id,
      seller: seller.uuid,
    });

    if (!product) {
      console.log(
        `Product ${req.params.id} not found or not owned by seller ${seller.uuid}`
      );
      return res
        .status(404)
        .json({ message: "Product not found or authorized" });
    }

    console.log(`MongoDB: Deleted product ${product.uuid}`);

    try {
      const allImageKeys = [
        ...product.pictures.map((img) => img.key),
        ...product.variants.flatMap((v) => v.pictures.map((img) => img.key)),
      ];

      await Promise.all(allImageKeys.map((key) => deleteObject(key)));
      console.log(
        `R2: Deleted ${allImageKeys.length} images for product ${product.uuid}`
      );
    } catch (r2Error) {
      console.error(`R2 deletion error for product ${product.uuid}:`, r2Error);
    }
    try {
      await redis.del(`product:${product.uuid}`);
      const sellerKeys = await redis.keys(`products:seller:${seller.uuid}:*`);
      if (sellerKeys.length) await redis.del(sellerKeys);
      console.log(`Redis: Cleared cache for product ${product.uuid}`);
    } catch (redisError) {
      console.error(`Redis cache clearing error:`, redisError);
    }

    try {
      const published = await publishProductEvent("PRODUCT_DELETED", product);
      if (published) {
        console.log(
          `RabbitMQ: Published PRODUCT_DELETED event for ${product.uuid}`
        );
      } else {
        console.error(
          `RabbitMQ: Failed to publish PRODUCT_DELETED event for ${product.uuid}`
        );
      }
    } catch (mqError) {
      console.error(`RabbitMQ publishing error:`, mqError);
    }

    res.json({ message: "Product deleted successfully" });
  } catch (error) {
    console.error("Error deleting product:", error);
    res.status(500).json({ message: error.message });
  }
};

const getProductBySellers = async (req, res) => {
  try {
    const { seller } = req;
    const { page = 1, limit = 10 } = req.query;
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const cacheKey = `products:seller:${seller.uuid}:page:${pageNum}:limit:${limitNum}`;

    const cachedData = await redis.get(cacheKey);
    if (cachedData) {
      return res.json(JSON.parse(cachedData));
    }

    const productsPromise = Product.find({ seller: seller.uuid })
      .select(
        "uuid name description category original_price discount stock pictures isAvailable createdAt"
      )
      .sort({ createdAt: -1 })
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum)
      .lean();

    const countPromise = Product.countDocuments({ seller: seller.uuid });
    const [products, total] = await Promise.all([
      productsPromise,
      countPromise,
    ]);

    const response = {
      total,
      page: pageNum,
      totalPages: Math.ceil(total / limitNum),
      products,
    };

    await redis.setex(cacheKey, 300, JSON.stringify(response));
    res.json(response);
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({ message: error.message });
  }
};

const getProductWithReviews = async (req, res) => {
  try {
    const productId = req.params.id;
    const forceRefresh = req.query.forceRefresh === "true";
    const cacheKey = `product_combined:${productId}`;

    if (!forceRefresh) {
      try {
        const cachedData = await redis.get(cacheKey);
        if (cachedData) {
          return res.json(JSON.parse(cachedData));
        }
      } catch (cacheError) {
        console.warn("Cache error:", cacheError);
      }
    }

    const [product, relatedProducts] = await Promise.all([
      Product.findOne({ uuid: productId }).lean(),
      fetchRelatedProducts(productId),
    ]);

    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    const reviewStats = {
      averageRating: 0,
      totalReviews: 0,
    };

    const result = { product, reviewStats, relatedProducts };
    await redis.setex(cacheKey, 300, JSON.stringify(result));
    return res.json(result);
  } catch (error) {
    console.error("Error in getProductWithReviews:", error);
    return res.status(500).json({ message: error.message });
  }
};

const fetchRelatedProducts = async (productId) => {
  try {
    const product = await Product.findOne(
      { uuid: productId },
      { category: 1 }
    ).lean();

    if (!product || !product.category) return [];

    const relatedProducts = await Product.find({
      category: product.category,
      uuid: { $ne: productId },
      isAvailable: true,
    })
      .limit(4)
      .select("uuid name original_price discount pictures category")
      .lean();

    return relatedProducts;
  } catch (error) {
    console.error("Error fetching related products:", error);
    return [];
  }
};

export default {
  createProduct,
  generateImageUploadUrl,
  updateProduct,
  deleteProductImage,
  getProduct,
  deleteProduct,
  getProductBySellers,
  getProductWithReviews,
  getSellerProductIds,
  getAllProducts,
};
