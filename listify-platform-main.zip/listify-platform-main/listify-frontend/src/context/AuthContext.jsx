import { useState, useEffect, createContext } from "react";
import axios from "axios";
import LoginPopup from "../components/Loginpopup";

const AuthContext = createContext();

const API_BASE_URL = "http://localhost:8080/api";

const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginModalTab, setLoginModalTab] = useState("Login");

  const loadUserData = async (authToken = token) => {
    if (!authToken) {
      setUser(null);
      setIsAuthenticated(false);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const response = await axios.get(`${API_BASE_URL}/users/me`, {
        headers: { Authorization: `Bearer ${authToken}` },
      });

      if (response.data && response.data.uuid) {
        setUser(response.data);
        setIsAuthenticated(true);
        localStorage.setItem("userData", JSON.stringify(response.data));
      } else {
        handleAuthFailure();
      }
    } catch (error) {
      handleAuthFailure();
    } finally {
      setLoading(false);
    }
  };

  const handleAuthFailure = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem("token");
    localStorage.removeItem("userData");
    setToken("");
  };

  useEffect(() => {
    const initAuth = async () => {
      if (!token) {
        setLoading(false);
        return;
      }

      const cachedUser = localStorage.getItem("userData");
      if (cachedUser) {
        try {
          const userData = JSON.parse(cachedUser);
          setUser(userData);
          setIsAuthenticated(true);
          setLoading(false);

          // Refresh user data in the background to ensure it's current
          loadUserData();
        } catch (e) {
          localStorage.removeItem("userData");
          await loadUserData();
        }
      } else {
        await loadUserData();
      }
    };

    initAuth();
  }, [token]);

  const login = async (userData, newToken) => {
    localStorage.setItem("token", newToken);
    setToken(newToken);

    if (userData && userData.uuid) {
      setUser(userData);
      setIsAuthenticated(true);
      localStorage.setItem("userData", JSON.stringify(userData));
    } else {
      await loadUserData(newToken);
    }

    setShowLoginModal(false);
  };

  const logout = async () => {
    try {
      if (token) {
        await axios.post(
          `${API_BASE_URL}/auth/users/logout`,
          {},
          { headers: { Authorization: `Bearer ${token}` } }
        );
      }
    } catch (error) {
      console.error("Error during logout:", error);
    } finally {
      localStorage.removeItem("token");
      localStorage.removeItem("userData");
      localStorage.removeItem("cartData");
      localStorage.removeItem("cartTimestamp");

      setToken("");
      setUser(null);
      setIsAuthenticated(false);
    }
  };

  const openLoginModal = (tab = "Login") => {
    setLoginModalTab(tab);
    setShowLoginModal(true);
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        user,
        loading,
        token,
        login,
        logout,
        refreshUser: loadUserData,
        showLoginModal,
        setShowLoginModal,
        openLoginModal,
        loginModalTab,
      }}
    >
      {children}
      {showLoginModal && (
        <LoginPopup
          setShowLogin={setShowLoginModal}
          initialState={loginModalTab}
        />
      )}
    </AuthContext.Provider>
  );
};

export { AuthContext, AuthProvider };
