import React, {
  createContext,
  useState,
  useEffect,
  useContext,
  useRef,
} from "react";
import axios from "axios";
import { AuthContext } from "./AuthContext";
import Toast from "../components/shared/Toast";

export const CartContext = createContext();

const API_BASE_URL = "http://localhost:8080/api";

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState({ items: [], subtotal: 0 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [toast, setToast] = useState({
    show: false,
    message: "",
    type: "error",
  });

  const {
    isAuthenticated,
    token,
    loading: authLoading,
    user,
  } = useContext(AuthContext);

  // Track if initial fetch has been performed
  const initialFetchDone = useRef(false);
  // Track ongoing requests to prevent duplicates
  const fetchInProgress = useRef(false);

  // Function to show a toast notification
  const showToast = (message, type = "error") => {
    setToast({ show: true, message, type });
  };

  // Function to hide the toast
  const hideToast = () => {
    setToast({ show: false, message: "", type: "error" });
  };

  // Helper to show login prompt
  const showLoginPrompt = () => {
    showToast("Please log in to use the cart", "info");
    return false;
  };

  const fetchCart = async (force = false) => {
    // Skip fetch if user is not authenticated
    if (!isAuthenticated) {
      setCart({ items: [], subtotal: 0 });
      return;
    }

    // Don't fetch if a request is already in progress
    if (fetchInProgress.current && !force) {
      console.log("Cart fetch already in progress, skipping...");
      return;
    }

    fetchInProgress.current = true;

    try {
      setLoading(true);
      setError(null);

      const endpoint = `${API_BASE_URL}/cart`;
      const config = {
        withCredentials: true,
        headers: { Authorization: `Bearer ${token}` },
      };

      console.log(`Fetching cart for authenticated user`);

      const response = await axios.get(endpoint, config);
      console.log("Cart data from server:", response.data);

      // Set cart from server response
      setCart(response.data);

      // Cache cart data locally
      try {
        localStorage.setItem("cartData", JSON.stringify(response.data));
        localStorage.setItem("cartTimestamp", Date.now().toString());
      } catch (e) {
        console.error("Error caching cart data:", e);
      }
    } catch (err) {
      console.error("Error fetching cart:", err);

      // Try to load from local storage if server request fails
      if (isAuthenticated) {
        const cachedCart = localStorage.getItem("cartData");
        if (cachedCart) {
          try {
            const parsedCart = JSON.parse(cachedCart);
            setCart(parsedCart);
            console.log("Using cached cart data after error:", parsedCart);
          } catch (e) {
            console.error("Error parsing cached cart data:", e);
            setError("Failed to load your cart. Please try again.");
            showToast("Failed to load your cart. Please try again.", "error");
          }
        } else {
          setError("Failed to load your cart. Please try again.");
          showToast("Failed to load your cart. Please try again.", "error");
        }
      }
    } finally {
      setLoading(false);
      fetchInProgress.current = false;
      initialFetchDone.current = true;
    }
  };

  // Add item to cart
  const addToCart = async (
    productId,
    variantId = null,
    quantity = 1,
    selectedAttributes = []
  ) => {
    // Require authentication
    if (!isAuthenticated) {
      return showLoginPrompt();
    }

    try {
      setLoading(true);

      const endpoint = `${API_BASE_URL}/cart/items`;

      console.log(
        `Adding to cart: ${productId}, variant: ${variantId}, qty: ${quantity}, attributes:`,
        selectedAttributes
      );

      const config = {
        withCredentials: true,
        headers: { Authorization: `Bearer ${token}` },
      };

      await axios.post(
        endpoint,
        {
          items: [
            {
              productId,
              variantId,
              quantity,
              selectedAttributes,
            },
          ],
        },
        config
      );

      // Fetch updated cart with force flag to bypass in-progress check
      await fetchCart(true);

      // Open cart drawer after adding
      setIsCartOpen(true);

      // Show success toast
      showToast("Item added to cart successfully!", "success");
      return true;
    } catch (err) {
      console.error("Error adding to cart:", err);

      // Extract the actual error message from the backend
      let errorMessage = "Failed to add item to cart";

      if (err.response) {
        console.error(`Status: ${err.response.status}`);
        console.error(`Error details:`, err.response.data);

        // For stock-related errors, only show toast but don't set error state
        if (
          err.response.data.message &&
          (err.response.data.message.includes("stock") ||
            err.response.data.message.includes("insufficient"))
        ) {
          errorMessage = err.response.data.message;
          showToast(errorMessage, "error");
          return false;
        } else if (
          err.response.data.error &&
          (err.response.data.error.includes("stock") ||
            err.response.data.error.includes("insufficient"))
        ) {
          errorMessage = err.response.data.error;
          showToast(errorMessage, "error");
          return false;
        } else if (
          err.response.data.details &&
          (err.response.data.details.includes("stock") ||
            err.response.data.details.includes("insufficient"))
        ) {
          errorMessage = err.response.data.details;
          showToast(errorMessage, "error");
          return false;
        } else if (err.response.data.message) {
          errorMessage = err.response.data.message;
        }
      }

      // Only set error state for non-stock related errors
      setError(errorMessage);
      showToast(errorMessage, "error");
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Update item quantity
  const updateCartItem = async (itemId, quantity) => {
    // Require authentication
    if (!isAuthenticated) {
      return showLoginPrompt();
    }

    try {
      setLoading(true);

      // If quantity is 0, remove the item
      if (quantity <= 0) {
        return await removeCartItem(itemId);
      }

      console.log(`Updating cart item ${itemId} to quantity ${quantity}`);

      const endpoint = `${API_BASE_URL}/cart/items/${itemId}`;

      try {
        const response = await axios.put(
          endpoint,
          { quantity },
          {
            withCredentials: true,
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        if (response.data) {
          // Directly update cart from response data
          setCart(response.data);
          showToast("Cart updated successfully", "success");
        } else {
          // Fallback to fetching the full cart
          await fetchCart(true);
        }

        return true;
      } catch (err) {
        if (err.response?.status === 400) {
          // For stock issues, only show toast without setting error state
          const errorMessage =
            err.response.data.message || "Cannot update quantity";
          console.error("Stock error:", errorMessage);

          if (
            errorMessage.includes("stock") ||
            errorMessage.includes("insufficient")
          ) {
            showToast(errorMessage, "error");
            return false;
          }

          setError(errorMessage);
          showToast(errorMessage, "error");
        } else {
          const errorMsg = "Failed to update item. Please try again.";
          setError(errorMsg);
          showToast(errorMsg, "error");
        }
        return false;
      }
    } catch (err) {
      console.error("Error updating cart item:", err);
      const errorMsg = "Failed to update item. Please try again.";
      setError(errorMsg);
      showToast(errorMsg, "error");
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Remove item from cart
  const removeCartItem = async (itemId) => {
    // Require authentication
    if (!isAuthenticated) {
      return showLoginPrompt();
    }

    try {
      setLoading(true);

      const endpoint = `${API_BASE_URL}/cart/items/${itemId}`;

      await axios.delete(endpoint, {
        withCredentials: true,
        headers: { Authorization: `Bearer ${token}` },
      });
      await fetchCart(true);
      showToast("Item removed from cart", "success");
      return true;
    } catch (err) {
      console.error("Error removing cart item:", err);
      const errorMsg = "Failed to remove item. Please try again.";
      setError(errorMsg);
      showToast(errorMsg, "error");
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Clear entire cart
  const clearCart = async () => {
    // Require authentication
    if (!isAuthenticated) {
      return showLoginPrompt();
    }

    try {
      setLoading(true);

      const endpoint = `${API_BASE_URL}/cart`;

      await axios.delete(endpoint, {
        withCredentials: true,
        headers: { Authorization: `Bearer ${token}` },
      });
      await fetchCart(true);

      // Also clear local storage cart
      localStorage.removeItem("cartData");
      localStorage.removeItem("cartTimestamp");

      showToast("Cart cleared successfully", "success");
      return true;
    } catch (err) {
      console.error("Error clearing cart:", err);
      const errorMsg = "Failed to clear cart. Please try again.";
      setError(errorMsg);
      showToast(errorMsg, "error");
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Initial cart fetch - only for authenticated users
  useEffect(() => {
    // Only fetch cart when auth loading is complete and user is authenticated
    if (!authLoading) {
      if (isAuthenticated) {
        console.log("User authenticated, fetching cart...");
        fetchCart();
      } else {
        // Clear cart if not authenticated
        console.log("User not authenticated, clearing cart state");
        setCart({ items: [], subtotal: 0 });
        localStorage.removeItem("cartData");
        localStorage.removeItem("cartTimestamp");
      }
    }
  }, [isAuthenticated, token, authLoading]);

  // Clear cart when user logs out
  useEffect(() => {
    if (!isAuthenticated) {
      setCart({ items: [], subtotal: 0 });
      localStorage.removeItem("cartData");
      localStorage.removeItem("cartTimestamp");
    }
  }, [isAuthenticated]);

  const cartItemCount = cart?.items?.length || 0;
  const cartSubtotal = cart?.subtotal || 0;

  const value = {
    cart,
    loading,
    error,
    isCartOpen,
    setIsCartOpen,
    addToCart,
    updateCartItem,
    removeCartItem,
    clearCart,
    cartItemCount,
    cartSubtotal,
    refreshCart: fetchCart,
    showToast,
    hideToast,
    isAuthenticated,
  };

  return (
    <CartContext.Provider value={value}>
      {toast.show && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={hideToast}
          duration={3000}
        />
      )}
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
