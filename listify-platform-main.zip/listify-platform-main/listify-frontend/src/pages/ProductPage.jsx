import React, {
  useState,
  useEffect,
  useContext,
  useRef,
  lazy,
  Suspense,
} from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";
import Navbar from "../components/Navbar/DesktopNavbar";
import MobileNavbar from "../components/Navbar/MobileNavbar";
import LoadingSpinner from "../components/shared/LoadingSpinner";
import ProductBreadcrumbs from "../components/product/ProductBreadcrumbs";
import ProductImageSection from "../components/product/ProductImageSection";
import ProductInfoSection from "../components/product/ProductInfoSection";
import { AuthContext } from "../context/AuthContext";
import { useCart } from "../context/CartContext";

const ProductTabs = lazy(() => import("../components/product/ProductTabs"));
const RelatedProducts = lazy(() =>
  import("../components/product/RelatedProducts")
);

const ProductInfoSkeleton = () => (
  <div className="lg:w-1/2 p-6 lg:border-l border-gray-200 animate-pulse">
    <div className="h-8 bg-gray-200 rounded-md w-3/4 mb-4"></div>
    <div className="flex items-center mb-4">
      <div className="flex space-x-1">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="w-4 h-4 rounded-full bg-gray-200"></div>
        ))}
      </div>
      <div className="h-4 w-24 bg-gray-200 rounded ml-2"></div>
    </div>
    <div className="h-10 bg-gray-200 rounded-md w-1/3 mb-4"></div>
    <div className="h-5 bg-gray-200 rounded-md w-1/2 mb-6"></div>
    <div className="space-y-4">
      <div className="h-12 bg-gray-200 rounded-md w-full"></div>
      <div className="h-12 bg-gray-200 rounded-md w-full"></div>
    </div>
  </div>
);

const ProductTabsSkeleton = () => (
  <div className="animate-pulse">
    <div className="border-b border-gray-200">
      <div className="flex -mb-px">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-10 bg-gray-200 rounded w-24 mx-2"></div>
        ))}
      </div>
    </div>
    <div className="mt-6">
      <div className="h-40 bg-gray-200 rounded-md"></div>
    </div>
  </div>
);

const ProductPage = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [relatedProducts, setRelatedProducts] = useState([]);
  const [reviewStats, setReviewStats] = useState({
    averageRating: 0,
    totalReviews: 0,
  });
  const [reviewUpdateTimestamp, setReviewUpdateTimestamp] = useState(
    Date.now()
  );
  const [reviewStatsKey, setReviewStatsKey] = useState(0);
  const [sellerInfo, setSellerInfo] = useState({
    sellerId: "",
    sellerName: "",
    sellerRating: 0,
  });

  const [infoLoaded, setInfoLoaded] = useState(false);
  const [tabsLoaded, setTabsLoaded] = useState(false);
  const [relatedLoaded, setRelatedLoaded] = useState(false);
  const [loadTimes, setLoadTimes] = useState({
    pageStart: Date.now(),
    mainDataLoaded: 0,
    fullPageLoaded: 0,
  });

  const { isAuthenticated } = useContext(AuthContext);
  const { addToCart: addItemToCart } = useCart();

  const requestInProgress = useRef(false);
  const isMounted = useRef(true);
  const controller = useRef(new AbortController());

  const handleReviewStatsUpdate = (newStats) => {
    setReviewStats(newStats);
    setReviewStatsKey((prev) => prev + 1);
    setReviewUpdateTimestamp(Date.now());
  };

  useEffect(() => {
    setLoadTimes((prev) => ({ ...prev, pageStart: Date.now() }));
    isMounted.current = true;

    if (id) {
      prefetchReviewData(id);
    }

    return () => {
      isMounted.current = false;
      requestInProgress.current = false;

      if (controller.current) {
        controller.current.abort();
        controller.current = new AbortController();
      }
    };
  }, []);

  const prefetchReviewData = async (productId) => {
    try {
      axios.get(
        `http://localhost:8080/api/reviews/product/${productId}/count-simple`,
        { timeout: 3000 }
      );
    } catch (error) {}
  };

  useEffect(() => {
    const fetchProductData = async () => {
      const startTime = Date.now();

      if (requestInProgress.current) {
        return;
      }

      setError(null);
      requestInProgress.current = true;
      controller.current = new AbortController();

      let attempts = 0;
      const maxAttempts = 3;

      while (attempts < maxAttempts) {
        try {
          const response = await axios.get(
            `http://localhost:8080/api/products/${id}/combined`,
            {
              signal: controller.current.signal,
              timeout: 5000,
            }
          );

          if (response.data) {
            setProduct(response.data.product);
            processProductData(response.data.product);
            selectInitialVariant(response.data.product);

            if (response.data.reviewStats) {
              setReviewStats({
                averageRating: parseFloat(
                  response.data.reviewStats.averageRating || 0
                ),
                totalReviews: parseInt(
                  response.data.reviewStats.totalReviews || 0
                ),
              });
            }

            if (response.data.relatedProducts) {
              setRelatedProducts(response.data.relatedProducts);
            }

            setInfoLoaded(true);
            setTabsLoaded(true);
            setRelatedLoaded(true);

            setLoadTimes((prev) => ({
              ...prev,
              mainDataLoaded: Date.now() - startTime,
            }));

            setLoading(false);

            setTimeout(() => {
              if (isMounted.current) {
                refreshDataInBackground(id);
              }
            }, 5000);
          }

          break;
        } catch (err) {
          attempts++;

          if (attempts >= maxAttempts) {
            if (isMounted.current) {
              await tryFallbackFetch(id);
            }
          } else {
            await new Promise((resolve) => setTimeout(resolve, 500));
          }
        }
      }

      requestInProgress.current = false;

      if (isMounted.current) {
        setLoadTimes((prev) => ({
          ...prev,
          fullPageLoaded: Date.now() - prev.pageStart,
        }));
      }
    };

    if (id) {
      fetchProductData();
    }
  }, [id]);

  const refreshDataInBackground = async (productId) => {
    if (!isMounted.current) return;

    try {
      const bgController = new AbortController();
      const response = await axios.get(
        `http://localhost:8080/api/products/${productId}/combined`,
        {
          signal: bgController.signal,
          timeout: 5000,
          headers: {
            "Cache-Control": "max-age=300",
          },
        }
      );

      if (response.data && isMounted.current) {
        sessionStorage.setItem(
          `product:${productId}`,
          JSON.stringify(response.data)
        );
        sessionStorage.setItem(
          `product:${productId}:timestamp`,
          Date.now().toString()
        );
      }
    } catch (error) {}
  };

  const tryFallbackFetch = async (productId) => {
    try {
      const productResponse = await axios.get(
        `http://localhost:8080/api/products/${productId}`,
        { timeout: 3000 }
      );

      if (productResponse.data) {
        const productData = productResponse.data;
        processProductData(productData);
        setProduct(productData);
        selectInitialVariant(productData);
        setInfoLoaded(true);
        setError(null);

        Promise.allSettled([
          fetchReviewStats(productId),
          fetchRelatedProducts(productData.category, productId),
        ]);
      }
    } catch (fallbackError) {}
  };

  const processProductData = (productData) => {
    if (!productData.variants) {
      productData.variants = [];
    }

    if (productData.attributes && productData.attributes.length > 0) {
      const defaultVariant = {
        uuid: `${productData.uuid}-default`,
        original_price: productData.original_price,
        discount: productData.discount,
        description: productData.description,
        stock: productData.stock,
        pictures: productData.pictures || [],
        attributes: productData.attributes || [],
        isDefault: true,
      };

      const hasDefaultVariant = productData.variants.some((v) => v.isDefault);
      if (!hasDefaultVariant) {
        productData.variants.unshift(defaultVariant);
      }
    }

    if (productData.seller) {
      setSellerInfo({
        sellerId: productData.seller.uuid || productData.seller,
        sellerName: productData.seller.name || "Seller",
        sellerRating: 0,
      });
    }
  };

  const selectInitialVariant = (productData) => {
    if (productData.variants && productData.variants.length > 0) {
      const inStockVariant = productData.variants.find((v) => v.stock > 0);
      setSelectedVariant(inStockVariant || productData.variants[0]);
    } else {
      setSelectedVariant(null);
    }
  };

  const fetchReviewStats = async (productId) => {
    try {
      const reviewResponse = await axios.get(
        `http://localhost:8080/api/reviews/product/${productId}/count-simple`,
        { timeout: 3000 }
      );

      if (reviewResponse.data && isMounted.current) {
        const apiReviewStats = reviewResponse.data || {};
        const normalizedReviewStats = {
          averageRating: parseFloat(apiReviewStats.averageRating || 0),
          totalReviews: parseInt(apiReviewStats.count || 0),
        };
        setReviewStats(normalizedReviewStats);
        setTabsLoaded(true);
      }
    } catch (reviewError) {
      if (isMounted.current) {
        setTabsLoaded(true);
      }
    }
  };

  const fetchRelatedProducts = async (category, productId) => {
    try {
      const relatedResponse = await axios.get(
        `http://localhost:8080/api/search/search?category=${encodeURIComponent(
          category
        )}&limit=4`
      );

      if (relatedResponse.data && isMounted.current) {
        const filteredProducts = relatedResponse.data.products
          .filter((p) => p.uuid !== productId)
          .slice(0, 4);
        setRelatedProducts(filteredProducts);
        setRelatedLoaded(true);
      }
    } catch (err) {
      if (isMounted.current) {
        setRelatedLoaded(true);
      }
    }
  };

  const handleVariantChange = (variant) => {
    setSelectedVariant(variant);
  };

  if (loading && !infoLoaded) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (!loading && (error || !product)) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-md p-6 max-w-md w-full">
          <h2 className="text-xl font-semibold text-red-600 mb-2">
            {error || "Product not found"}
          </h2>
          <p className="text-gray-600 mb-4">
            Sorry, we couldn't find the product you're looking for.
          </p>
          <Link
            to="/"
            className="inline-block px-4 py-2 bg-cyan-500 text-white rounded hover:bg-cyan-600"
          >
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="hidden md:block">
        <Navbar />
      </div>
      <div className="md:hidden">
        <MobileNavbar />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <ProductBreadcrumbs product={product} />

        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="lg:flex">
            <ProductImageSection
              productImages={product.pictures || []}
              variantImages={selectedVariant?.pictures || []}
            />

            {infoLoaded ? (
              <ProductInfoSection
                product={product}
                selectedVariant={selectedVariant}
                onVariantChange={handleVariantChange}
                reviewStats={reviewStats}
                sellerInfo={sellerInfo}
                reviewStatsKey={reviewStatsKey}
                addToCart={addItemToCart}
                isAuthenticated={isAuthenticated}
              />
            ) : (
              <ProductInfoSkeleton />
            )}
          </div>

          <div className="px-6 pb-6">
            {tabsLoaded ? (
              <Suspense fallback={<ProductTabsSkeleton />}>
                <ProductTabs
                  product={product}
                  selectedVariant={selectedVariant}
                  onUpdateReviewStats={handleReviewStatsUpdate}
                  reviewUpdateTimestamp={reviewUpdateTimestamp}
                />
              </Suspense>
            ) : (
              <ProductTabsSkeleton />
            )}
          </div>
        </div>

        {relatedProducts.length > 0 && relatedLoaded && (
          <div className="mt-12">
            <Suspense
              fallback={
                <div className="h-64 bg-gray-100 rounded-lg animate-pulse"></div>
              }
            >
              <RelatedProducts products={relatedProducts} />
            </Suspense>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductPage;
