import React, { useState, useEffect, useContext } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faShoppingBag,
  faSpinner,
  faExclamationTriangle,
  faSearch,
} from "@fortawesome/free-solid-svg-icons";
import Navbar from "../components/Navbar/DesktopNavbar";
import MobileNavbar from "../components/Navbar/MobileNavbar";
import OrderItem from "../components/orders/OrderItem";
import OrderDetails from "../components/orders/OrderDetails";
import { AuthContext } from "../context/AuthContext";

const OrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [viewMode, setViewMode] = useState("all");

  const { user } = useContext(AuthContext);

  useEffect(() => {
    fetchOrders();
  }, [currentPage, viewMode]);

  const fetchOrders = async () => {
    if (!user?.uuid) return;

    try {
      setLoading(true);
      setError(null);

      // Add filters based on view mode
      let url = `http://localhost:8080/api/orders/user/${user.uuid}?page=${currentPage}&limit=5`;

      if (viewMode === "active") {
        url += "&status=PENDING,PAYMENT_PROCESSING,PAID,PREPARING,SHIPPED";
      } else if (viewMode === "completed") {
        url += "&status=DELIVERED";
      }

      const response = await axios.get(url, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });

      setOrders(response.data.orders);
      setTotalPages(response.data.pagination.pages);
    } catch (err) {
      console.error("Error fetching orders:", err);
      setError("Failed to load orders. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleViewOrder = (order) => {
    setSelectedOrder(order);
    window.scrollTo(0, 0);
  };

  const handleCloseDetails = () => {
    setSelectedOrder(null);
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleChangeViewMode = (mode) => {
    setViewMode(mode);
    setCurrentPage(1);
  };

  // Filter orders by search term if present
  const filteredOrders = orders.filter((order) =>
    searchTerm
      ? order.orderId.toLowerCase().includes(searchTerm.toLowerCase())
      : true
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="hidden md:block">
        <Navbar />
      </div>
      <div className="md:hidden">
        <MobileNavbar />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">
            {selectedOrder
              ? `Order #${selectedOrder.orderId.substring(0, 8)}...`
              : "My Orders"}
          </h1>
          <p className="text-gray-600 mt-1">
            {selectedOrder
              ? `Placed on ${new Date(
                  selectedOrder.createdAt
                ).toLocaleDateString()}`
              : "Track and manage your orders"}
          </p>
        </div>

        {selectedOrder ? (
          <OrderDetails
            order={selectedOrder}
            onBack={handleCloseDetails}
            onRefresh={fetchOrders}
          />
        ) : (
          <>
            
            <div className="bg-white shadow rounded-lg p-6 mb-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex">
                  <button
                    className={`px-4 py-2 rounded-l-md ${
                      viewMode === "all"
                        ? "bg-cyan-500 text-white"
                        : "bg-gray-100 hover:bg-gray-200"
                    }`}
                    onClick={() => handleChangeViewMode("all")}
                  >
                    All Orders
                  </button>
                  <button
                    className={`px-4 py-2 ${
                      viewMode === "active"
                        ? "bg-cyan-500 text-white"
                        : "bg-gray-100 hover:bg-gray-200"
                    }`}
                    onClick={() => handleChangeViewMode("active")}
                  >
                    Active
                  </button>
                  <button
                    className={`px-4 py-2 rounded-r-md ${
                      viewMode === "completed"
                        ? "bg-cyan-500 text-white"
                        : "bg-gray-100 hover:bg-gray-200"
                    }`}
                    onClick={() => handleChangeViewMode("completed")}
                  >
                    Completed
                  </button>
                </div>

                <div className="relative flex-1 max-w-sm">
                  <input
                    type="text"
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500"
                    placeholder="Search by order number"
                    value={searchTerm}
                    onChange={handleSearchChange}
                  />
                  <div className="absolute left-3 top-2.5 text-gray-400">
                    <FontAwesomeIcon icon={faSearch} />
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white shadow rounded-lg overflow-hidden">
              {loading ? (
                <div className="p-16 flex justify-center">
                  <FontAwesomeIcon
                    icon={faSpinner}
                    spin
                    className="text-cyan-500 text-4xl"
                  />
                </div>
              ) : error ? (
                <div className="p-8 text-center">
                  <FontAwesomeIcon
                    icon={faExclamationTriangle}
                    className="text-red-500 text-4xl mb-4"
                  />
                  <p className="text-gray-700">{error}</p>
                  <button
                    onClick={fetchOrders}
                    className="mt-4 bg-cyan-500 text-white px-4 py-2 rounded-md hover:bg-cyan-600"
                  >
                    Try Again
                  </button>
                </div>
              ) : filteredOrders.length === 0 ? (
                <div className="p-16 text-center">
                  <FontAwesomeIcon
                    icon={faShoppingBag}
                    className="text-gray-300 text-6xl mb-4"
                  />
                  <h3 className="text-xl font-medium text-gray-700 mb-2">
                    No Orders Found
                  </h3>
                  <p className="text-gray-500 mb-6">
                    {searchTerm
                      ? "No orders match your search criteria"
                      : "You haven't placed any orders yet."}
                  </p>
                  <Link
                    to="/"
                    className="bg-cyan-500 text-white px-6 py-2 rounded-md hover:bg-cyan-600"
                  >
                    Continue Shopping
                  </Link>
                </div>
              ) : (
                <>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Order ID
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Date
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Items
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Total
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {filteredOrders.map((order) => (
                          <OrderItem
                            key={order.orderId}
                            order={order}
                            onViewDetails={() => handleViewOrder(order)}
                          />
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {totalPages > 1 && (
                    <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                      <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                        <div>
                          <p className="text-sm text-gray-700">
                            Showing page{" "}
                            <span className="font-medium">{currentPage}</span>{" "}
                            of <span className="font-medium">{totalPages}</span>
                          </p>
                        </div>
                        <div>
                          <nav
                            className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px"
                            aria-label="Pagination"
                          >
                            <button
                              onClick={() => handlePageChange(currentPage - 1)}
                              disabled={currentPage === 1}
                              className={`relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 ${
                                currentPage === 1
                                  ? "opacity-50 cursor-not-allowed"
                                  : ""
                              }`}
                            >
                              Previous
                            </button>

                            {Array.from(
                              { length: totalPages },
                              (_, i) => i + 1
                            ).map((page) => (
                              <button
                                key={page}
                                onClick={() => handlePageChange(page)}
                                className={`relative inline-flex items-center px-4 py-2 border ${
                                  currentPage === page
                                    ? "z-10 bg-cyan-50 border-cyan-500 text-cyan-600"
                                    : "bg-white border-gray-300 text-gray-500 hover:bg-gray-50"
                                } text-sm font-medium`}
                              >
                                {page}
                              </button>
                            ))}

                            <button
                              onClick={() => handlePageChange(currentPage + 1)}
                              disabled={currentPage === totalPages}
                              className={`relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 ${
                                currentPage === totalPages
                                  ? "opacity-50 cursor-not-allowed"
                                  : ""
                              }`}
                            >
                              Next
                            </button>
                          </nav>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default OrdersPage;
