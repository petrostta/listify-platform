import React, { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";

import Navbar from "../components/Navbar/DesktopNavbar";
import MobileNavbar from "../components/Navbar/MobileNavbar";
import FilterSidebar from "../components/search/FilterSidebar";
import MobileFilters from "../components/search/MobileFilters";
import ProductGrid from "../components/search/ProductGrid";
import Pagination from "../components/search/Pagination";

const SearchResults = () => {
  const location = useLocation();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const currentRequestRef = useRef(null);
  const requestIdRef = useRef(0);

  const queryParams = new URLSearchParams(location.search);
  const searchQuery = queryParams.get("q") || "";
  const categoryFromURL = queryParams.get("category") || "";
  const showAll = queryParams.get("all") === "true";

  const [filters, setFilters] = useState({
    minPrice: "",
    maxPrice: "",
    sortField: "price",
    sortOrder: "asc",
  });

  const [showFilters, setShowFilters] = useState(false);
  const [pagination, setPagination] = useState({
    page: 1,
    totalPages: 0,
    total: 0,
  });

  useEffect(() => {
    return () => {
      if (currentRequestRef.current) {
        currentRequestRef.current.abort();
      }
    };
  }, []);

  useEffect(() => {
    if (searchQuery || categoryFromURL || showAll) {
      fetchSearchResults(1);
    } else {
      setLoading(false);
      setProducts([]);
    }
  }, [location.search]);

  const fetchSearchResults = async (page = 1) => {
    if (currentRequestRef.current) {
      currentRequestRef.current.abort();
    }

    const controller = new AbortController();
    currentRequestRef.current = controller;
    const requestId = ++requestIdRef.current;

    setLoading(true);
    setError(null);

    try {
      const currentParams = new URLSearchParams(location.search);
      const currentQuery = currentParams.get("q") || "";
      const currentCategory = currentParams.get("category") || "";
      const currentShowAll = currentParams.get("all") === "true";

      const params = new URLSearchParams();

      if (currentQuery) params.append("q", currentQuery);
      if (currentCategory) params.append("category", currentCategory);
      if (currentShowAll) params.append("all", "true");

      params.append("page", page);
      params.append("limit", 12);

      if (filters.minPrice) params.append("minPrice", filters.minPrice);
      if (filters.maxPrice) params.append("maxPrice", filters.maxPrice);
      params.append("sortField", filters.sortField || "price");
      params.append("sortOrder", filters.sortOrder || "asc");

      const response = await axios.get(
        `http://localhost:8080/api/search/search?${params.toString()}`,
        {
          signal: controller.signal,
          timeout: 10000,
        }
      );

      if (requestId === requestIdRef.current && !controller.signal.aborted) {
        setProducts(response.data.products || []);
        setPagination({
          page: response.data.pagination?.page || 1,
          totalPages: response.data.pagination?.pages || 0,
          total: response.data.pagination?.total || 0,
        });
        setError(null);
      }
    } catch (err) {
      if (err.name === "AbortError" || err.code === "ERR_CANCELED") {
        return;
      }

      if (requestId === requestIdRef.current) {
        if (err.response?.status === 400) {
          const errorMsg =
            err.response.data?.errors?.join(", ") ||
            "Invalid search parameters. Please try different filters.";
          setError(errorMsg);
        } else if (err.code === "ECONNABORTED") {
          setError("Search request timed out. Please try again.");
        } else {
          setError("Failed to load search results. Please try again.");
        }

        setProducts([]);
        setPagination({ page: 1, totalPages: 0, total: 0 });
      }
    } finally {
      if (requestId === requestIdRef.current) {
        setLoading(false);
      }
      if (currentRequestRef.current === controller) {
        currentRequestRef.current = null;
      }
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const applyFilters = () => {
    fetchSearchResults(1);
    setShowFilters(false);
  };

  const clearFilters = () => {
    setFilters({
      minPrice: "",
      maxPrice: "",
      sortField: "price",
      sortOrder: "asc",
    });
    setTimeout(() => fetchSearchResults(1), 100);
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      fetchSearchResults(newPage);
    }
  };

  const getCurrentSearchContext = () => {
    if (searchQuery) return `Search results for "${searchQuery}"`;
    if (categoryFromURL) return categoryFromURL;
    if (showAll) return "All Products";
    return "Search";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="hidden md:block">
        <Navbar />
      </div>
      <div className="md:hidden">
        <MobileNavbar />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">
            {getCurrentSearchContext()}
          </h1>
          <p className="text-gray-600 mt-1">
            {!loading && (
              <>
                {pagination.total}{" "}
                {pagination.total === 1 ? "result" : "results"} found
              </>
            )}
            {loading && <span className="text-cyan-600">Searching...</span>}
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          <FilterSidebar
            filters={{ ...filters, category: categoryFromURL }}
            handleFilterChange={handleFilterChange}
            applyFilters={applyFilters}
            clearFilters={clearFilters}
          />

          <div className="flex-1">
            <MobileFilters
              filters={{ ...filters, category: categoryFromURL }}
              handleFilterChange={handleFilterChange}
              applyFilters={applyFilters}
              clearFilters={clearFilters}
              showFilters={showFilters}
              setShowFilters={setShowFilters}
            />

            <ProductGrid
              products={products}
              loading={loading}
              error={error}
              searchQuery={searchQuery || categoryFromURL}
            />

            {!loading && !error && products.length > 0 && (
              <Pagination
                pagination={pagination}
                handlePageChange={handlePageChange}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchResults;
