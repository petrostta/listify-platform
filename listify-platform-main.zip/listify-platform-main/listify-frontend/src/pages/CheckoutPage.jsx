import React, { useState, useEffect, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faArrowLeft,
  faCheck,
  faCreditCard,
  faLock,
  faSpinner,
} from "@fortawesome/free-solid-svg-icons";
import Navbar from "../components/Navbar/DesktopNavbar";
import MobileNavbar from "../components/Navbar/MobileNavbar";
import PaymentMethodSelector from "../components/payment/PaymentMethodSelector";
import OrderSummary from "../components/checkout/OrderSummary";
import ShippingForm from "../components/checkout/ShippingForm";
import CheckoutSteps from "../components/checkout/CheckoutSteps";
import { AuthContext } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import axios from "axios";

const CheckoutPage = () => {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useContext(AuthContext);
  const { cart, clearCart, refreshCart } = useCart();

  const [currentStep, setCurrentStep] = useState(1);
  const [shippingInfo, setShippingInfo] = useState(null);
  const [paymentInfo, setPaymentInfo] = useState(null);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [paymentResult, setPaymentResult] = useState(null);
  const [error, setError] = useState(null);
  const [orderId, setOrderId] = useState(null);

  useEffect(() => {
    if (!cart || !cart.items || cart.items.length === 0) {
      navigate("/");
    }
  }, [cart, navigate]);

  useEffect(() => {
    if (!isAuthenticated && currentStep > 1) {
      navigate("/");
    }
  }, [isAuthenticated, currentStep, navigate]);

  const goToNextStep = () => {
    window.scrollTo(0, 0);
    setCurrentStep((prev) => prev + 1);
  };

  const goToPreviousStep = () => {
    setCurrentStep((prev) => prev - 1);
  };

  const handleShippingSubmit = (data) => {
    setShippingInfo(data);
    goToNextStep();
  };

  const handlePaymentSubmit = async (data) => {
    try {
      console.log("Auth state:", { isAuthenticated, user });

      if (!user || !isAuthenticated) {
        setError("You must be logged in to complete this purchase.");
        navigate("/");
        return;
      }
      setPaymentInfo(data);
      setProcessingPayment(true);
      setError(null);

      const orderResponse = await axios.post(
        "http://localhost:8080/api/orders",
        {
          userId: user.uuid,
          orderItems: cart.items.map((item) => {
            const orderItem = {
              productId: item.productId,
              name: item.product?.name || "Product",
              price: item.price,
              quantity: item.quantity,
            };

            if (item.variantId) {
              orderItem.variantId = item.variantId;
            }

            return orderItem;
          }),
          shippingInfo,
          billingInfo: shippingInfo,
          totalAmount: cart.subtotal,
        },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      const { orderId } = orderResponse.data;
      setOrderId(orderId);

      const paymentResponse = await axios.post(
        "http://localhost:8080/api/payments/process",
        {
          orderId,
          userId: user.uuid,
          amount: cart.subtotal,
          paymentMethod: data.paymentMethod,
          gatewayType: data.gatewayType,
          cardNumber: data.cardNumber,
          expMonth: data.expMonth,
          expYear: data.expYear,
          cvc: data.cvc,
        },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      setPaymentResult(paymentResponse.data);

      clearCart();

      goToNextStep();
    } catch (err) {
      console.error("Payment processing error:", err);
      setError(
        err.response?.data?.message ||
          "There was a problem processing your payment. Please try again."
      );
    } finally {
      setProcessingPayment(false);
    }
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <ShippingForm
            onSubmit={handleShippingSubmit}
            initialData={shippingInfo}
          />
        );
      case 2:
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">
              Select Payment Method
            </h2>
            <PaymentMethodSelector onPaymentSubmit={handlePaymentSubmit} />
            {error && (
              <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-md">
                {error}
              </div>
            )}
            {processingPayment && (
              <div className="mt-4 p-4 bg-blue-50 text-blue-700 rounded-md flex items-center">
                <FontAwesomeIcon icon={faSpinner} spin className="mr-2" />
                Processing your payment...
              </div>
            )}
          </div>
        );
      case 3:
        return (
          <div className="bg-white rounded-lg shadow p-6 text-center">
            <div className="w-20 h-20 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-4">
              <FontAwesomeIcon
                icon={faCheck}
                className="text-green-600 text-4xl"
              />
            </div>
            <h2 className="text-2xl font-bold text-green-600 mb-2">
              Payment Successful!
            </h2>
            <p className="text-gray-600 mb-6">
              Your order has been placed and is being processed.
            </p>
            <div className="mb-4 p-4 bg-gray-50 rounded-md inline-block">
              <p className="text-gray-700">
                Order Number:{" "}
                <span className="font-medium">
                  {paymentResult?.orderId || orderId}
                </span>
              </p>
              <p className="text-gray-700">
                Transaction ID:{" "}
                <span className="font-medium">
                  {paymentResult?.gatewayTransactionId}
                </span>
              </p>
            </div>
            <button
              onClick={() => navigate("/")}
              className="bg-cyan-500 text-white py-2 px-6 rounded-md hover:bg-cyan-600 transition-colors"
            >
              Continue Shopping
            </button>
          </div>
        );
      default:
        return null;
    }
  };

  // If cart data is still loading
  if (!cart) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <FontAwesomeIcon
          icon={faSpinner}
          spin
          className="text-cyan-500 text-4xl"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="hidden md:block">
        <Navbar />
      </div>
      <div className="md:hidden">
        <MobileNavbar />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Checkout</h1>
        </div>

        <CheckoutSteps currentStep={currentStep} />

        <div className="flex flex-col lg:flex-row gap-8 mt-8">
          <div className="lg:w-2/3">
            {currentStep > 1 && (
              <button
                onClick={goToPreviousStep}
                className="mb-4 flex items-center text-cyan-600 hover:text-cyan-700"
                disabled={processingPayment}
              >
                <FontAwesomeIcon icon={faArrowLeft} className="mr-1" />
                Back
              </button>
            )}

            {renderCurrentStep()}

            {currentStep === 2 && (
              <div className="mt-6 flex items-center justify-center text-gray-500 text-sm">
                <FontAwesomeIcon icon={faLock} className="mr-2" />
                All payments are secure and encrypted
              </div>
            )}
          </div>

          <div className="lg:w-1/3">
            <OrderSummary
              cart={cart}
              shippingInfo={shippingInfo}
              currentStep={currentStep}
              processingPayment={processingPayment}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
