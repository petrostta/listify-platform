import React, { useState, useEffect, useContext } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar/DesktopNavbar";
import ResponsiveNavbar from "../components/Navbar/ResponsiveNavbar";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faShippingFast,
  faShieldAlt,
  faCreditCard,
  faHeadset,
  faArrowRight,
  faStar,
  faStarHalfAlt,
  faLaptop,
  faTshirt,
  faHome,
  faRunning,
  faHeartbeat,
  faShoppingCart,
  faEye,
} from "@fortawesome/free-solid-svg-icons";
import {
  faFacebook,
  faInstagram,
  faTwitter,
} from "@fortawesome/free-brands-svg-icons";
import { CartContext } from "../context/CartContext";
import { toast } from "react-toastify";

const HomePage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // Only showing 5 categories to not take all the space of the homepage
  const categories = [
    {
      name: "Electronics",
      slug: "Electronics",
      icon: faLaptop,
      color: "bg-blue-500",
    },
    { name: "Fashion", slug: "Fashion", icon: faTshirt, color: "bg-pink-500" },
    {
      name: "Home & Garden",
      slug: "Home & Garden",
      icon: faHome,
      color: "bg-green-500",
    },
    { name: "Sports", slug: "Sports", icon: faRunning, color: "bg-orange-500" },
    {
      name: "Health & Beauty",
      slug: "Health & Beauty",
      icon: faHeartbeat,
      color: "bg-purple-500",
    },
  ];

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);

        const productsResponse = await axios.get(
          "http://localhost:8080/api/products/?limit=8"
        );

        const productList = productsResponse.data.products || [];

        const productsWithReviews = await Promise.all(
          productList.map(async (product) => {
            try {
              const reviewResponse = await axios.get(
                `http://localhost:8080/api/reviews/product/${product.uuid}/count-simple`,
                { timeout: 3000 }
              );

              return {
                ...product,
                rating: parseFloat(reviewResponse.data?.averageRating || 0),
                reviewCount: parseInt(reviewResponse.data?.count || 0),
              };
            } catch (reviewError) {
              console.warn(
                `Failed to fetch reviews for product ${product.uuid}:`,
                reviewError.message
              );
              return {
                ...product,
                rating: 0,
                reviewCount: 0,
              };
            }
          })
        );

        setProducts(productsWithReviews);
      } catch (err) {
        console.error("Error fetching products:", err);
        setError("Failed to load products. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const handleCategoryClick = (categoryName) => {
    navigate(`/search?category=${encodeURIComponent(categoryName)}`);
  };

  // Rendering star ratings based on the product's rating
  const renderStarRating = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.3 && rating % 1 <= 0.7;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    const roundedUpStars = Math.ceil(rating);

    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <FontAwesomeIcon
          key={`full-${i}`}
          icon={faStar}
          className="text-yellow-400"
          size="xs"
        />
      );
    }

    // Add half star
    if (hasHalfStar) {
      stars.push(
        <FontAwesomeIcon
          key="half"
          icon={faStarHalfAlt}
          className="text-yellow-400"
          size="xs"
        />
      );
    } else if (rating % 1 > 0.7) {
      stars.push(
        <FontAwesomeIcon
          key="almost-full"
          icon={faStar}
          className="text-yellow-400"
          size="xs"
        />
      );
    }

    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <FontAwesomeIcon
          key={`empty-${i}`}
          icon={faStar}
          className="text-gray-200"
          size="xs"
        />
      );
    }

    return stars;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <ResponsiveNavbar />

      <div className="relative bg-gradient-to-r from-cyan-500 to-cyan-400 text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 py-16 pb-24 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0 relative z-30">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Discover Amazing Products
            </h1>
            <p className="text-xl mb-8 max-w-md">
              Shop the latest trends with fast shipping and secure payments.
            </p>
            <div className="flex space-x-4">
              <Link
                to="/search?all=true"
                className="bg-white text-cyan-600 font-semibold px-6 py-3 rounded-lg hover:bg-gray-100 transition-colors"
              >
                Shop Now
              </Link>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 z-10">
          {/*the wave was created from the https://getwaves.io/ page */}
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 1440 120"
            className="w-full h-auto"
          >
            <path
              fill="#f9fafb"
              fillOpacity="1"
              d="M0,32L60,42.7C120,53,240,75,360,74.7C480,75,600,53,720,42.7C840,32,960,32,1080,42.7C1200,53,1320,75,1380,85.3L1440,96L1440,120L1380,120C1320,120,1200,120,1080,120C960,120,840,120,720,120C600,120,480,120,360,120C240,120,120,120,60,120L0,120Z"
            ></path>
          </svg>
        </div>
      </div>

      <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Shop by Category</h2>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="h-32 bg-gray-200 rounded-lg animate-pulse"
              ></div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 justify-center">
            {categories.map((category) => (
              <div
                key={category.name}
                className="relative overflow-hidden rounded-lg group cursor-pointer text-center transition-transform hover:scale-105"
                onClick={() => handleCategoryClick(category.name)}
              >
                <div
                  className={`aspect-w-1 aspect-h-1 w-full flex flex-col items-center justify-center rounded-lg ${category.color} transition-all duration-300 group-hover:opacity-90 shadow-md`}
                >
                  <FontAwesomeIcon
                    icon={category.icon}
                    className="text-white text-4xl mb-2"
                  />
                  <h3 className="text-lg font-medium text-white">
                    {category.name}
                  </h3>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-8">
            <h2 className="text-2xl font-bold text-gray-900">Products</h2>
            <Link
              to="/search?all=true"
              className="text-cyan-600 font-medium flex items-center hover:text-cyan-700"
            >
              View All <FontAwesomeIcon icon={faArrowRight} className="ml-2" />
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div
                  key={i}
                  className="border border-gray-200 rounded-lg overflow-hidden bg-white"
                >
                  <div className="h-48 bg-gray-200 animate-pulse"></div>
                  <div className="p-4">
                    <div className="h-4 bg-gray-200 rounded animate-pulse mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded animate-pulse w-2/3"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {products.map((product) => (
                <div
                  key={product.uuid}
                  className="border border-gray-200 rounded-lg overflow-hidden bg-white shadow-md hover:shadow-lg transition-all duration-300 hover:translate-y-[-5px] flex flex-col"
                >
                  <Link
                    to={`/product/${product.uuid}`}
                    className="relative overflow-hidden group"
                  >
                    <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden bg-gray-100">
                      <img
                        src={
                          product.pictures && product.pictures.length > 0
                            ? product.pictures[0].url
                            : "/placeholder-product.png"
                        }
                        alt={product.name}
                        className="h-48 w-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>

                    {/* Discount badge */}
                    {product.discount > 0 && (
                      <div className="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold rounded-full px-2 py-1">
                        -{product.discount}%
                      </div>
                    )}
                  </Link>

                  <div className="p-4 flex-grow flex flex-col">
                    <Link to={`/product/${product.uuid}`}>
                      <h3 className="text-sm font-medium text-gray-900 line-clamp-2 mb-1 hover:text-cyan-600 transition-colors">
                        {product.name}
                      </h3>
                    </Link>

                    <div className="flex items-center mb-2">
                      <div className="flex text-yellow-400">
                        {renderStarRating(product.rating || 0)}
                      </div>
                      <span className="text-xs text-gray-500 ml-1">
                        ({product.reviewCount || 0})
                      </span>
                    </div>

                    <div className="mt-auto pt-3 border-t border-gray-50">
                      <div className="flex justify-between items-center">
                        <div>
                          {product.discount > 0 ? (
                            <div>
                              <span className="text-sm font-bold text-gray-900">
                                $
                                {(
                                  product.original_price *
                                  (1 - product.discount / 100)
                                ).toFixed(2)}
                              </span>
                              <span className="text-xs text-gray-500 line-through ml-1">
                                ${product.original_price.toFixed(2)}
                              </span>
                            </div>
                          ) : (
                            <span className="text-sm font-bold text-gray-900">
                              ${product.original_price?.toFixed(2)}
                            </span>
                          )}
                        </div>
                        <Link
                          to={`/product/${product.uuid}`}
                          className="flex items-center justify-center gap-1 bg-cyan-500 text-white px-3 py-1.5 rounded-full text-xs font-medium hover:bg-cyan-600 transition-colors"
                        >
                          <FontAwesomeIcon icon={faEye} />
                          View Details
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">
            Why Shop With Us
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-cyan-100 text-cyan-600 mb-4">
                <FontAwesomeIcon icon={faShippingFast} size="lg" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Fast Shipping
              </h3>
              <p className="text-gray-500">
                Get your products delivered within 2-4 business days.
              </p>
            </div>

            <div className="text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-cyan-100 text-cyan-600 mb-4">
                <FontAwesomeIcon icon={faShieldAlt} size="lg" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Secure Payments
              </h3>
              <p className="text-gray-500">
                We use encryption technology to keep your data safe.
              </p>
            </div>

            <div className="text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-cyan-100 text-cyan-600 mb-4">
                <FontAwesomeIcon icon={faCreditCard} size="lg" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Easy Returns
              </h3>
              <p className="text-gray-500">
                30-day money back guarantee for all purchases.
              </p>
            </div>

            <div className="text-center">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-cyan-100 text-cyan-600 mb-4">
                <FontAwesomeIcon icon={faHeadset} size="lg" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                24/7 Support
              </h3>
              <p className="text-gray-500">
                Our support team is available round the clock.
              </p>
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Shop</h3>
              <ul className="space-y-2">
                <li>
                  <Link
                    to="/products"
                    className="text-gray-300 hover:text-white"
                  >
                    All Products
                  </Link>
                </li>
                <li>
                  <Link
                    to="/categories"
                    className="text-gray-300 hover:text-white"
                  >
                    Categories
                  </Link>
                </li>
                <li>
                  <Link
                    to="/trending"
                    className="text-gray-300 hover:text-white"
                  >
                    Trending
                  </Link>
                </li>
                <li>
                  <Link to="/sale" className="text-gray-300 hover:text-white">
                    Sale
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Customer Service</h3>
              <ul className="space-y-2">
                <li>
                  <Link
                    to="/contact"
                    className="text-gray-300 hover:text-white"
                  >
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link
                    to="/shipping"
                    className="text-gray-300 hover:text-white"
                  >
                    Shipping Policy
                  </Link>
                </li>
                <li>
                  <Link
                    to="/returns"
                    className="text-gray-300 hover:text-white"
                  >
                    Returns & Refunds
                  </Link>
                </li>
                <li>
                  <Link to="/faq" className="text-gray-300 hover:text-white">
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Account</h3>
              <ul className="space-y-2">
                <li>
                  <Link
                    to="/account"
                    className="text-gray-300 hover:text-white"
                  >
                    My Account
                  </Link>
                </li>
                <li>
                  <Link to="/orders" className="text-gray-300 hover:text-white">
                    Order History
                  </Link>
                </li>
                <li>
                  <Link
                    to="/wishlist"
                    className="text-gray-300 hover:text-white"
                  >
                    Wishlist
                  </Link>
                </li>
                <li>
                  <Link
                    to="/newsletter"
                    className="text-gray-300 hover:text-white"
                  >
                    Newsletter
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">About Us</h3>
              <ul className="space-y-2">
                <li>
                  <Link to="/about" className="text-gray-300 hover:text-white">
                    Our Story
                  </Link>
                </li>
                <li>
                  <Link to="/blog" className="text-gray-300 hover:text-white">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link
                    to="/careers"
                    className="text-gray-300 hover:text-white"
                  >
                    Careers
                  </Link>
                </li>
                <li>
                  <Link
                    to="/privacy"
                    className="text-gray-300 hover:text-white"
                  >
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-10 pt-10 flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 mb-4 md:mb-0">
              © 2025 Listify. All rights reserved.
            </div>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-white">
                <span className="sr-only">Facebook</span>
                <FontAwesomeIcon icon={faFacebook} className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <span className="sr-only">Instagram</span>
                <FontAwesomeIcon icon={faInstagram} className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <span className="sr-only">Twitter</span>
                <FontAwesomeIcon icon={faTwitter} className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
