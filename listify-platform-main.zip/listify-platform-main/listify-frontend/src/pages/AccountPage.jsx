import React, { useState, useContext, useEffect } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar/DesktopNavbar";
import MobileNavbar from "../components/Navbar/MobileNavbar";
import ReviewsSection from "../components/account/ReviewsSection";
import AccountHeader from "../components/account/AccountHeader";
import TabNavigation from "../components/account/TabNavigation";
import StatusMessage from "../components/account/StatusMessage";
import ProfileSection from "../components/account/ProfileSection";
import PasswordChangeForm from "../components/account/PasswordChangeForm";
import EmailChangeForm from "../components/account/EmailChangeForm";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSpinner } from "@fortawesome/free-solid-svg-icons";

const AccountPage = () => {
  const { isAuthenticated, user, refreshUser, logout } =
    useContext(AuthContext);
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("profile");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  // Redirect if not authenticated
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const tabParam = params.get("tab");

    if (tabParam && ["profile", "security", "reviews"].includes(tabParam)) {
      setActiveTab(tabParam);
    }
  }, [location.search]);

  // if data isnt loaded yet then show loading spinner
  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <FontAwesomeIcon
          icon={faSpinner}
          spin
          className="text-cyan-500 text-4xl"
        />
      </div>
    );
  }

  const handleSuccess = (message, shouldLogout = false) => {
    setSuccess(true);
    if (shouldLogout) {
      setTimeout(() => {
        setSuccess(false);
        logout();
        navigate("/");
      }, 3000);
    } else {
      setTimeout(() => setSuccess(false), 3000);
    }
  };

  const handleError = (errorMessage) => {
    setError(errorMessage);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="hidden md:block">
        <Navbar />
      </div>
      <div className="md:hidden">
        <MobileNavbar />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <AccountHeader />

          <TabNavigation activeTab={activeTab} setActiveTab={setActiveTab} />

          <StatusMessage
            success={success}
            error={error}
            onDismissError={() => setError(null)}
            activeTab={activeTab}
          />

          <div className="p-6">
            {activeTab === "profile" && (
              <ProfileSection
                user={user}
                isEditing={isEditing}
                setIsEditing={setIsEditing}
                refreshUser={refreshUser}
                onSuccess={handleSuccess}
                onError={handleError}
                setLoading={setLoading}
                loading={loading}
              />
            )}

            {activeTab === "security" && (
              <div className="space-y-8">
                <PasswordChangeForm
                  onSuccess={handleSuccess}
                  onError={handleError}
                  setLoading={setLoading}
                  loading={loading}
                />

                <EmailChangeForm
                  user={user}
                  onSuccess={handleSuccess}
                  onError={handleError}
                  setLoading={setLoading}
                  loading={loading}
                />
              </div>
            )}
            {activeTab === "reviews" && (
              <ReviewsSection
                user={user}
                onSuccess={handleSuccess}
                onError={handleError}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountPage;
