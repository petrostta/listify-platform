import React, { useState, useEffect } from "react";
import axios from "axios";
import StripePaymentForm from "./StripePaymentForm";

const PaymentMethodSelector = ({ onPaymentSubmit }) => {
  const [selectedGateway, setSelectedGateway] = useState("stripe");
  const [gateways, setGateways] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchGateways = async () => {
      try {
        setLoading(true);
        const response = await axios.get(
          "http://localhost:8080/api/payments/gateways"
        );
        setGateways(response.data.gateways);
      } catch (err) {
        console.error("Error fetching payment gateways:", err);
        setError("Failed to load payment methods");
      } finally {
        setLoading(false);
      }
    };

    fetchGateways();
  }, []);

  const handleGatewayChange = (e) => {
    setSelectedGateway(e.target.value);
  };

  const handlePaymentSubmit = (paymentData) => {
    onPaymentSubmit({
      ...paymentData,
      gatewayType: selectedGateway,
    });
  };

  if (loading) {
    return <div className="p-4 text-center">Loading payment methods...</div>;
  }

  if (error) {
    return <div className="p-4 text-center text-red-600">{error}</div>;
  }

  return (
    <div className="p-4 border rounded-lg shadow-sm bg-white">
      <h3 className="text-lg font-medium mb-4">Select Payment Method</h3>

      <div className="mb-6">
        <div className="flex flex-wrap gap-4">
          {gateways.map((gateway) => (
            <label
              key={gateway.gateway}
              className={`flex items-center p-4 border rounded-lg cursor-pointer transition-colors
                ${
                  selectedGateway === gateway.gateway
                    ? "border-cyan-500 bg-cyan-50"
                    : "border-gray-200 hover:bg-gray-50"
                }`}
            >
              <input
                type="radio"
                name="paymentGateway"
                value={gateway.gateway}
                checked={selectedGateway === gateway.gateway}
                onChange={handleGatewayChange}
                className="mr-2"
              />
              <div className="flex items-center">
                {gateway.gateway === "stripe" && (
                  <img
                    src="https://vikwp.com/images/plugins/stripe.png"
                    alt="Stripe"
                    className="h-8"
                  />
                )}
                <span className="ml-2 font-medium">
                  {gateway.gateway === "stripe" ? "Credit Card" : "PayPal"}
                </span>
              </div>
            </label>
          ))}
        </div>
      </div>

      <div className="mt-6">
        {selectedGateway === "stripe" && (
          <StripePaymentForm
            config={gateways.find((g) => g.gateway === "stripe")}
            onSubmit={handlePaymentSubmit}
          />
        )}
      </div>
    </div>
  );
};

export default PaymentMethodSelector;
