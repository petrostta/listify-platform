import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCreditCard, faLock } from "@fortawesome/free-solid-svg-icons";

const StripePaymentForm = ({ config, onSubmit }) => {
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("12/25");
  const [cvc, setCvc] = useState("123");
  const [name, setName] = useState("Test User");
  const [isProcessing, setIsProcessing] = useState(false);

  // Format card number with spaces after every 4 digits
  const formatCardNumber = (value) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || "";
    const parts = [];

    for (let i = 0; i < match.length; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(" ");
    } else {
      return value;
    }
  };

  // Format expiry date with slash after month
  const formatExpiry = (value) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");

    if (v.length > 2) {
      return `${v.substring(0, 2)}/${v.substring(2, 4)}`;
    }

    return v;
  };

  const handleCardNumberChange = (e) => {
    const formattedValue = formatCardNumber(e.target.value);
    setCardNumber(formattedValue);
  };

  const handleExpiryChange = (e) => {
    const formattedValue = formatExpiry(e.target.value);
    setExpiry(formattedValue);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsProcessing(true);

    const rawCardNumber = cardNumber.replace(/\s+/g, "");
    console.log("FRONTEND: Submitting card:", rawCardNumber);

    const [expMonth, expYear] = expiry.split("/");

    onSubmit({
      paymentMethod: {
        type: "CREDIT_CARD",
        cardLast4: rawCardNumber.slice(-4),
        provider: "Stripe Test",
      },
      // IMPORTANTE FIELDS
      cardNumber: rawCardNumber,
      expMonth: parseInt(expMonth),
      expYear: parseInt("20" + expYear),
      cvc: cvc,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="p-3 bg-gray-50 border border-gray-200 rounded-md mb-4">
        <div className="flex items-center text-gray-600 text-sm mb-1">
          <FontAwesomeIcon icon={faLock} className="mr-2 text-green-600" />
          Secure Payment
        </div>
        <div className="text-xs text-gray-500">
          Your payment information is encrypted and secure.
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Card Number
        </label>
        <div className="relative">
          <input
            type="text"
            value={cardNumber}
            onChange={handleCardNumberChange}
            className="w-full p-3 pl-10 border border-gray-300 rounded-md"
            placeholder="1234 5678 9012 3456"
            maxLength="19" // 16 digits + 3 spaces
            required
          />
          <FontAwesomeIcon
            icon={faCreditCard}
            className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
          />
        </div>
        <p className="text-xs text-gray-500 mt-1">
          Use 4242 4242 4242 4242 for successful payments
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Expiry Date
          </label>
          <input
            type="text"
            value={expiry}
            onChange={handleExpiryChange}
            className="w-full p-3 border border-gray-300 rounded-md"
            placeholder="MM/YY"
            maxLength="5"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            CVC
          </label>
          <input
            type="text"
            value={cvc}
            onChange={(e) =>
              setCvc(e.target.value.replace(/\D/g, "").substring(0, 3))
            }
            className="w-full p-3 border border-gray-300 rounded-md"
            placeholder="123"
            maxLength="3"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Cardholder Name
        </label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full p-3 border border-gray-300 rounded-md"
          placeholder="John Doe"
          required
        />
      </div>

      <button
        type="submit"
        disabled={isProcessing}
        className={`w-full py-3 px-4 rounded-md text-white font-medium
          ${isProcessing ? "bg-gray-400" : "bg-cyan-500 hover:bg-cyan-600"}`}
      >
        {isProcessing ? "Processing..." : "Pay Now"}
      </button>

      <p className="text-xs text-gray-500 text-center mt-2">
        This is a test payment and won't charge any real cards
      </p>
    </form>
  );
};

export default StripePaymentForm;
