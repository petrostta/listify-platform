import React, { useContext, useEffect } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../../context/AuthContext";

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading, user, refreshUser } =
    useContext(AuthContext);

  // If authenticated but user is null, then refreshing user data
  useEffect(() => {
    if (isAuthenticated && !user && !loading) {
      refreshUser();
    }
  }, [isAuthenticated, user, loading, refreshUser]);

  // Show loading spinner while checking authentication or when authenticated but user data isn't loaded
  if (loading || (isAuthenticated && !user)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  // if not user authenticated or user data is missing then navigate them to the home page
  if (!isAuthenticated || !user) {
    return <Navigate to="/" />;
  }

  // Rendering the prodected content
  return children;
};

export default ProtectedRoute;
