import React, { useState, useContext } from "react";
import { NavLink } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch, faSpinner } from "@fortawesome/free-solid-svg-icons";
import { HeartIcon, MapIcon, ShoppingCartIcon } from "@heroicons/react/outline";
import LoginPopup from "../Loginpopup.jsx";
import CategoriesDropdown from "../CategoriesDropdown.jsx";
import { AuthContext } from "../../context/AuthContext";
import ProfileDropdown from "../ProfileDropdown.jsx";
import AddressPopup from "../AddressPopup.jsx";
import { useSearch } from "../../hooks/useSearch";
import CartIcon from "../cart/CartIcon.jsx";

const Navbar = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAddressPopupOpen, setIsAddressPopupOpen] = useState(false);
  const { isAuthenticated, user, logout } = useContext(AuthContext);
  const {
    searchTerm,
    suggestions,
    isLoading,
    showSuggestions,
    suggestionRef,
    handleSearchChange,
    handleSearchSubmit,
    handleSuggestionClick,
    setShowSuggestions,
  } = useSearch();

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  const toggleAddressPopup = () => {
    setIsAddressPopupOpen(!isAddressPopupOpen);
  };

  return (
    <div className="w-full p-4 border-b-2 border-cyan-500 bg-white">
      <div className="max-w-[1280px] mx-auto flex items-center justify-between">
        <div className="flex items-center">
          <NavLink to="/" className="text-cyan-500 text-3xl font-pacifico">
            listify
          </NavLink>
          <CategoriesDropdown />
        </div>

        <div
          className="flex items-center flex-1 mx-4 relative"
          ref={suggestionRef}
        >
          <form onSubmit={handleSearchSubmit} className="w-full">
            <div
              className={`flex items-center border-[2px] border-cyan-500 w-full overflow-visible ${
                showSuggestions && suggestions.length > 0
                  ? "rounded-t-lg"
                  : "rounded-full"
              }`}
            >
              <input
                placeholder="Search for anything"
                className={`w-full py-2 px-4 ${
                  showSuggestions && suggestions.length > 0
                    ? "rounded-tl-lg"
                    : "rounded-l-full"
                } text-lg outline-none`}
                value={searchTerm}
                onChange={handleSearchChange}
                onFocus={() =>
                  searchTerm.length >= 2 && setShowSuggestions(true)
                }
              />
              <button
                type="submit"
                className={`bg-cyan-500 p-3 ${
                  showSuggestions && suggestions.length > 0
                    ? "rounded-tr-lg"
                    : "rounded-r-full"
                }`}
              >
                {isLoading ? (
                  <FontAwesomeIcon
                    icon={faSpinner}
                    spin
                    className="text-white text-lg"
                  />
                ) : (
                  <FontAwesomeIcon
                    icon={faSearch}
                    className="text-white text-lg bg"
                  />
                )}
              </button>
            </div>
          </form>

          {showSuggestions && suggestions.length > 0 && (
            <div
              className="absolute top-full left-0 right-0 bg-white border-2 border-t-0 border-cyan-500 rounded-b-lg shadow-lg z-50 overflow-hidden"
              style={{ marginTop: "-2px" }}
            >
              <div className="w-full border-b border-cyan-500"></div>

              <div className="max-h-60 overflow-y-auto py-1">
                {suggestions.map((suggestion, index) => (
                  <div
                    key={index}
                    className="px-4 py-2.5 hover:bg-gray-100 cursor-pointer"
                    onClick={() => handleSuggestionClick(suggestion)}
                  >
                    <div className="flex items-center ">
                      <FontAwesomeIcon
                        icon={faSearch}
                        className="text-cyan-500 mr-2 text-sm"
                      />
                      <span>{suggestion}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        <div className="flex items-center space-x-6 text-black text-lg">
          <MapIcon
            className="cursor-pointer h-6 w-6 hover:text-cyan-500"
            onClick={toggleAddressPopup}
          />
          <CartIcon />
          {isAuthenticated ? (
            <>
              <ProfileDropdown />
            </>
          ) : (
            <button
              className="text-md font-semibold hover:bg-cyan-500 hover:bg-opacity-50 hover:rounded-3xl py-2 px-3 transition-all duration-300"
              onClick={toggleModal}
            >
              Sign in
            </button>
          )}
        </div>
      </div>

      {isModalOpen && <LoginPopup setShowLogin={setIsModalOpen} />}
      {isAddressPopupOpen && (
        <AddressPopup setShowAddress={setIsAddressPopupOpen} />
      )}
    </div>
  );
};

export default Navbar;
