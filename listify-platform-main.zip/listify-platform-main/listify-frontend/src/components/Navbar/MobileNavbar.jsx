import React, { useState, useContext } from "react";
import { NavLink } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faSearch,
  faClose,
  faSpinner,
  faUser,
  faHome,
  faClipboardList,
  faBars,
} from "@fortawesome/free-solid-svg-icons";
import { MapIcon } from "@heroicons/react/outline";
import LoginPopup from "../Loginpopup.jsx";
import CategoriesDropdown from "../CategoriesDropdown.jsx";
import AddressPopup from "../AddressPopup.jsx";
import { AuthContext } from "../../context/AuthContext";
import { useSearch } from "../../hooks/useSearch";
import CartIcon from "../cart/CartIcon.jsx";
import categoriesData from "../CategoriesDropdown.jsx";

const categories = categoriesData?.categories || [
  "Electronics",
  "Fashion",
  "Home & Garden",
  "Sports",
  "Books",
  "Toys",
  "Health & Beauty",
  "Automotive",
  "Music",
  "Gaming",
  "Pets",
];

const MobileNavbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAddressPopupOpen, setIsAddressPopupOpen] = useState(false);
  const { isAuthenticated } = useContext(AuthContext);

  const {
    searchTerm,
    suggestions,
    isLoading,
    showSuggestions,
    suggestionRef,
    handleSearchChange,
    handleSearchSubmit,
    handleSuggestionClick,
    setShowSuggestions,
  } = useSearch();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const toggleModal = () => setIsModalOpen(!isModalOpen);
  const toggleAddressPopup = () => setIsAddressPopupOpen(!isAddressPopupOpen);

  return (
    <div className="w-full">
      <div className="p-4 border-b-2 border-gray-300 bg-white flex items-center justify-between md:hidden">
        <div className="text-cyan-500 text-3xl font-pacifico">listify</div>
        <div
          className="flex items-center flex-1 mx-4 relative"
          ref={suggestionRef}
        >
          <form onSubmit={handleSearchSubmit} className="w-full">
            <div className="flex items-center border-2 border-cyan-500 rounded-full w-full">
              <input
                placeholder="Search for anything"
                className="w-full py-2 px-4 rounded-l-full text-lg outline-none"
                value={searchTerm}
                onChange={handleSearchChange}
                onFocus={() =>
                  searchTerm.length >= 2 && setShowSuggestions(true)
                }
              />
              <button type="submit" className="bg-cyan-500 p-3 rounded-r-full">
                {isLoading ? (
                  <FontAwesomeIcon
                    icon={faSpinner}
                    spin
                    className="text-white text-lg"
                  />
                ) : (
                  <FontAwesomeIcon
                    icon={faSearch}
                    className="text-white text-lg"
                  />
                )}
              </button>
            </div>
          </form>
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-300 rounded-md shadow-lg z-50 max-h-60 overflow-auto">
              {suggestions.map((suggestion, index) => (
                <div
                  key={index}
                  className="px-4 py-2 hover:bg-gray-100 cursor-pointer text-sm"
                  onClick={() => handleSuggestionClick(suggestion)}
                >
                  {suggestion}
                </div>
              ))}
            </div>
          )}
        </div>
        <button
          onClick={toggleMenu}
          className="text-gray-600 focus:outline-none"
        >
          <FontAwesomeIcon icon={faBars} className="text-2xl" />
        </button>
      </div>

      {isMenuOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40">
          <div className="w-2/3 bg-white h-full shadow-lg p-4 absolute right-0 top-0">
            <FontAwesomeIcon
              icon={faClose}
              onClick={toggleMenu}
              className="text-gray-600 text-2xl absolute mt-3 right-4 hover:cursor-pointer"
            />
            <div className="mt-16">
              <CategoriesDropdown isMobile={true} />
            </div>
          </div>
        </div>
      )}

      {isModalOpen && <LoginPopup setShowLogin={setIsModalOpen} />}
      {isAddressPopupOpen && (
        <AddressPopup setShowAddress={setIsAddressPopupOpen} />
      )}

      <div className="fixed bottom-0 left-0 right-0 bg-white p-4 shadow-lg flex justify-around border-t-2 z-50">
        <NavLink to="/" className="flex flex-col items-center" end>
          <FontAwesomeIcon
            icon={faHome}
            className="h-6 w-6 hover:text-cyan-500"
          />
          <span className="text-xs">Home</span>
        </NavLink>
        <button
          onClick={toggleAddressPopup}
          className="flex flex-col items-center"
        >
          <MapIcon className="h-6 w-6 hover:text-cyan-500" />
          <span className="text-xs">Address</span>
        </button>
        <NavLink to="/orders" className="flex flex-col items-center">
          <FontAwesomeIcon
            icon={faClipboardList}
            className="h-6 w-6 hover:text-cyan-500"
          />
          <span className="text-xs">Orders</span>
        </NavLink>
        <div to="/cart" className="flex flex-col items-center">
          <CartIcon />
          <span className="text-xs">Cart</span>
        </div>
        {isAuthenticated ? (
          <NavLink to="/account" className="flex flex-col items-center">
            <FontAwesomeIcon
              icon={faUser}
              className="h-6 w-6 hover:text-cyan-500"
            />
            <span className="text-xs">Profile</span>
          </NavLink>
        ) : (
          <button onClick={toggleModal} className="flex flex-col items-center">
            <FontAwesomeIcon
              icon={faUser}
              className="h-6 w-6 hover:text-cyan-500"
            />
            <span className="text-xs">Sign in</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default MobileNavbar;
