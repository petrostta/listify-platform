import React, { useState, useEffect } from "react";
import MobileNavbar from "./MobileNavbar";
import DesktopNavbar from "./DesktopNavbar";

const ResponsiveNavbar = () => {
  const [isMobileView, setIsMobileView] = useState(window.innerWidth < 768);

  const handleResize = () => {
    setIsMobileView(window.innerWidth < 768);
  };

  useEffect(() => {
    window.addEventListener("resize", handleResize);

    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return <div>{isMobileView ? <MobileNavbar /> : <DesktopNavbar />}</div>;
};

export default ResponsiveNavbar;
