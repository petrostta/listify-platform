import React, { useState, useEffect, useRef } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBars } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";

const CategoriesDropdown = ({ isMobile }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);
  const navigate = useNavigate();
  const navigateTimeoutRef = useRef(null);

  const categories = [
    "Electronics",
    "Fashion",
    "Home & Garden",
    "Sports",
    "Books",
    "Toys",
    "Health & Beauty",
    "Automotive",
    "Music",
    "Gaming",
    "Pets",
  ];

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const closeDropdown = (e) => {
    if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
      setIsOpen(false);
    }
  };

  const handleCategoryClick = (category) => {
    if (navigateTimeoutRef.current) {
      clearTimeout(navigateTimeoutRef.current);
    }

    setIsOpen(false);

    // for prevention of race condition
    navigateTimeoutRef.current = setTimeout(() => {
      console.log(`Navigating to category: ${category}`);
      navigate(`/search?category=${encodeURIComponent(category)}`);
    }, 50);
  };

  useEffect(() => {
    document.addEventListener("click", closeDropdown);

    return () => {
      document.removeEventListener("click", closeDropdown);
      if (navigateTimeoutRef.current) {
        clearTimeout(navigateTimeoutRef.current);
      }
    };
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      {isMobile ? (
        <div className="flex flex-col space-y-2">
          {categories.map((category, index) => (
            <div
              key={index}
              className="py-2 px-4 hover:bg-cyan-500 hover:bg-opacity-50 transition-all cursor-pointer font-semibold rounded-2xl"
              onClick={() => handleCategoryClick(category)}
            >
              {category}
            </div>
          ))}
        </div>
      ) : (
        <div>
          <div
            className="flex items-center ml-5 cursor-pointer hover:bg-cyan-500 hover:bg-opacity-50 hover:rounded-3xl py-2 px-3 transition-all duration-300"
            onClick={toggleDropdown}
          >
            <FontAwesomeIcon icon={faBars} className="text-black text-lg" />
            <span className="ml-2 text-black text-md font-semibold">
              Categories
            </span>
          </div>
          {isOpen && (
            <div className="absolute left-0 mt-4 ml-4 w-48 bg-white shadow-lg border rounded-xl z-50 max-h-64 overflow-y-auto scrollbar-hidden">
              {categories.map((category, index) => (
                <div
                  key={index}
                  className={`py-2 px-4 hover:bg-cyan-500 hover:bg-opacity-50 transition-all cursor-pointer font-semibold ${
                    index === 0 ? "rounded-t-xl" : ""
                  } ${index === categories.length - 1 ? "rounded-b-xl" : ""}`}
                  onClick={() => handleCategoryClick(category)}
                >
                  {category}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CategoriesDropdown;
