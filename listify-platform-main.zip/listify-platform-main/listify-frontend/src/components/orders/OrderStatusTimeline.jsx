import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faShoppingCart,
  faCreditCard,
  faBoxOpen,
  faTruck,
  faCheckCircle,
  faTimes,
} from "@fortawesome/free-solid-svg-icons";

const OrderStatusTimeline = ({ currentStatus }) => {
  // This is the order of which the statuses will be displayed in the status timeline
  const statusOrder = [
    {
      key: "PENDING",
      label: "Order Placed",
      icon: faShoppingCart,
      description: "Your order has been placed",
    },
    {
      key: "PAYMENT_PROCESSING",
      label: "Payment Processing",
      icon: faCreditCard,
      description: "Your payment is being processed",
    },
    {
      key: "PAID",
      label: "Payment Confirmed",
      icon: faCreditCard,
      description: "Your payment has been confirmed",
    },
    {
      key: "PREPARING",
      label: "Preparing",
      icon: faBoxOpen,
      description: "Your order is being prepared",
    },
    {
      key: "SHIPPED",
      label: "Shipped",
      icon: faTruck,
      description: "Your order has been shipped",
    },
    {
      key: "DELIVERED",
      label: "Delivered",
      icon: faCheckCircle,
      description: "Your order has been delivered",
    },
  ];

  // Find current status index
  const currentIndex = statusOrder.findIndex(
    (status) => status.key === currentStatus
  );

  // Handle cancelled orders
  if (currentStatus === "CANCELLED") {
    return (
      <div className="p-4 bg-red-50 text-red-700 rounded-md flex items-center">
        <FontAwesomeIcon icon={faTimes} className="mr-2" />
        <div>
          <p className="font-medium">Order Cancelled</p>
          <p className="text-sm">This order has been cancelled</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200"></div>

      <div className="space-y-6">
        {statusOrder.map((status, index) => {
          // Determine if this step is completed, active, or upcoming
          const isCompleted = index <= currentIndex;
          const isActive = index === currentIndex;

          return (
            <div key={status.key} className="flex items-start">
              <div
                className={`relative z-10 flex-shrink-0 flex items-center justify-center w-12 h-12 rounded-full mr-4 text-white ${
                  isCompleted ? "bg-cyan-500" : "bg-gray-300"
                }`}
              >
                <FontAwesomeIcon icon={status.icon} className="text-lg" />
              </div>

              <div className="flex-grow pt-1">
                <h4
                  className={`font-medium text-lg ${
                    isActive ? "text-cyan-700" : "text-gray-900"
                  }`}
                >
                  {status.label}
                </h4>
                <p className="text-sm text-gray-500 mt-1">
                  {status.description}
                </p>

                {isActive && (
                  <div className="mt-1 text-xs text-cyan-600 font-medium">
                    Current Status
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default OrderStatusTimeline;
