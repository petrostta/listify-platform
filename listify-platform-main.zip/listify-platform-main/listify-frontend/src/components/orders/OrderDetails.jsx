import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faArrowLeft,
  faMapMarkerAlt,
  faTruck,
  faExclamationTriangle,
  faPrint,
  faRedo,
  faTimes,
} from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import OrderStatusTimeline from "./OrderStatusTimeline";

const OrderDetails = ({ order, onBack, onRefresh }) => {
  const [cancellationLoading, setCancellationLoading] = useState(false);
  const [cancellationError, setCancellationError] = useState(null);
  const [showCancellationDialog, setShowCancellationDialog] = useState(false);

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const canCancel = ["PENDING", "PAYMENT_PROCESSING", "PAID"].includes(
    order.status
  );

  const handleCancelOrder = async () => {
    try {
      setCancellationLoading(true);
      setCancellationError(null);

      await axios.post(
        `http://localhost:8080/api/orders/${order.orderId}/cancel`,
        { reason: "Cancelled by customer" },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      setShowCancellationDialog(false);
      onRefresh();
    } catch (err) {
      console.error("Error cancelling order:", err);
      setCancellationError("Failed to cancel order. Please try again.");
    } finally {
      setCancellationLoading(false);
    }
  };

  const handlePrintOrder = () => window.print();

  // Just cosmetic
  const handleReorder = () => {};

  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="p-6 border-b">
        <button
          onClick={onBack}
          className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
        >
          <FontAwesomeIcon icon={faArrowLeft} className="mr-2" />
          Back to Orders
        </button>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-xl font-semibold">Order #{order.orderId}</h2>
            <p className="text-gray-500">
              Placed on {formatDate(order.createdAt)}
            </p>
          </div>
          <div className="mt-4 md:mt-0 flex space-x-2">
            <button
              onClick={handlePrintOrder}
              className="flex items-center px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              <FontAwesomeIcon icon={faPrint} className="mr-2" />
              Print
            </button>

            {order.status !== "CANCELLED" && (
              <button
                onClick={handleReorder}
                className="flex items-center px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                <FontAwesomeIcon icon={faRedo} className="mr-2" />
                Reorder
              </button>
            )}

            {canCancel && (
              <button
                onClick={() => setShowCancellationDialog(true)}
                className="flex items-center px-3 py-2 border border-red-300 rounded-md shadow-sm text-sm leading-4 font-medium text-red-700 bg-white hover:bg-red-50"
              >
                <FontAwesomeIcon icon={faTimes} className="mr-2" />
                Cancel Order
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="p-6 border-b">
        <h3 className="text-lg font-medium mb-4">Order Status</h3>
        <OrderStatusTimeline currentStatus={order.status} />
      </div>

      <div className="p-6 border-b">
        <h3 className="text-lg font-medium mb-4">Order Items</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Product
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Price
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Quantity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {order.orderItems.map((item, index) => (
                <tr key={index}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {item.name}
                    </div>
                    <div className="text-sm text-gray-500">
                      ID: {item.productId.substring(0, 8)}...
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      ${item.price.toFixed(2)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{item.quantity}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      ${(item.price * item.quantity).toFixed(2)}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-gray-50">
              <tr>
                <th
                  colSpan="3"
                  className="px-6 py-3 text-right text-sm font-medium text-gray-500"
                >
                  Subtotal
                </th>
                <td className="px-6 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                  ${order.totalAmount.toFixed(2)}
                </td>
              </tr>
              <tr>
                <th
                  colSpan="3"
                  className="px-6 py-3 text-right text-sm font-medium text-gray-500"
                >
                  Shipping
                </th>
                <td className="px-6 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                  $0.00
                </td>
              </tr>
              <tr>
                <th
                  colSpan="3"
                  className="px-6 py-3 text-right text-sm font-medium text-gray-500"
                >
                  Tax
                </th>
                <td className="px-6 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                  ${(order.totalAmount * 0.1).toFixed(2)}
                </td>
              </tr>
              <tr>
                <th
                  colSpan="3"
                  className="px-6 py-3 text-right text-base font-medium text-gray-700"
                >
                  Total
                </th>
                <td className="px-6 py-3 whitespace-nowrap text-base font-medium text-gray-900">
                  ${(order.totalAmount * 1.1).toFixed(2)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-medium mb-4 flex items-center">
            <FontAwesomeIcon
              icon={faMapMarkerAlt}
              className="mr-2 text-cyan-500"
            />
            Shipping Address
          </h3>
          <div className="bg-gray-50 p-4 rounded-md">
            <p className="font-medium">{order.shippingInfo.fullName}</p>
            <p>{order.shippingInfo.addressLine1}</p>
            {order.shippingInfo.addressLine2 && (
              <p>{order.shippingInfo.addressLine2}</p>
            )}
            <p>
              {order.shippingInfo.city}, {order.shippingInfo.state}{" "}
              {order.shippingInfo.postalCode}
            </p>
            <p>{order.shippingInfo.country}</p>
          </div>
        </div>
        <div>
          <h3 className="text-lg font-medium mb-4 flex items-center">
            <FontAwesomeIcon icon={faTruck} className="mr-2 text-cyan-500" />
            Delivery Method
          </h3>
          <div className="bg-gray-50 p-4 rounded-md">
            <p className="font-medium">Standard Shipping</p>
            <p className="text-gray-600">
              Estimated delivery in 3-5 business days
            </p>
          </div>
        </div>
      </div>

      {showCancellationDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <div className="flex items-center text-red-600 mb-4">
              <FontAwesomeIcon
                icon={faExclamationTriangle}
                className="text-xl mr-2"
              />
              <h3 className="text-lg font-medium">Cancel Order</h3>
            </div>

            <p className="mb-4">
              Are you sure you want to cancel this order? This action cannot be
              undone.
            </p>

            {cancellationError && (
              <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md">
                {cancellationError}
              </div>
            )}

            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowCancellationDialog(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                disabled={cancellationLoading}
              >
                Keep Order
              </button>
              <button
                onClick={handleCancelOrder}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                disabled={cancellationLoading}
              >
                {cancellationLoading ? "Cancelling..." : "Yes, Cancel Order"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrderDetails;
