import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";

const OrderItem = ({ order, onViewDetails }) => {
  // formats the date
  const orderDate = new Date(order.createdAt).toLocaleDateString();

  // Displays a much shorter order ID
  const shortOrderId = order.orderId.substring(0, 8) + "...";

  // Get total items count
  const itemCount = order.orderItems.reduce(
    (total, item) => total + item.quantity,
    0
  );

  // Determins the status color
  const getStatusColor = (status) => {
    switch (status) {
      case "PENDING":
        return "bg-yellow-100 text-yellow-800";
      case "PAYMENT_PROCESSING":
        return "bg-blue-100 text-blue-800";
      case "PAID":
        return "bg-green-100 text-green-800";
      case "PREPARING":
        return "bg-purple-100 text-purple-800";
      case "SHIPPED":
        return "bg-indigo-100 text-indigo-800";
      case "DELIVERED":
        return "bg-green-100 text-green-800";
      case "CANCELLED":
        return "bg-red-100 text-red-800";
      case "FAILED":
        return "bg-red-500 text-white";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <tr>
      <td className="px-6 py-4 whitespace-nowrap">
        <div
          className="text-sm font-medium text-gray-900"
          title={order.orderId}
        >
          {shortOrderId}
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-gray-500">{orderDate}</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-gray-900">
          {itemCount} item{itemCount !== 1 ? "s" : ""}
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm font-medium text-gray-900">
          ${order.totalAmount.toFixed(2)}
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <span
          className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(
            order.status
          )}`}
        >
          {order.status.replace("_", " ")}
        </span>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
        <button
          onClick={onViewDetails}
          className="text-cyan-600 hover:text-cyan-900 flex items-center"
        >
          <FontAwesomeIcon icon={faEye} className="mr-1" />
          View
        </button>
      </td>
    </tr>
  );
};

export default OrderItem;
