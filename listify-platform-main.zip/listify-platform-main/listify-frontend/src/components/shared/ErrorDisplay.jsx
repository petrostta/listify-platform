import React from "react";
import { Link } from "react-router-dom";

const ErrorDisplay = ({ error }) => {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-md text-center">
        <h2 className="text-2xl font-bold text-red-600 mb-4">Error</h2>
        <p className="text-gray-700 mb-4">{error}</p>
        <Link to="/" className="text-cyan-600 hover:text-cyan-800">
          Return to homepage
        </Link>
      </div>
    </div>
  );
};

export default ErrorDisplay;
