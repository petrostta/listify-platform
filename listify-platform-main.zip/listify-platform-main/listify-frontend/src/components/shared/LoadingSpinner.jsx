import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSpinner } from "@fortawesome/free-solid-svg-icons";

const LoadingSpinner = () => {
  return (
    <div className="flex justify-center items-center h-64">
      <FontAwesomeIcon
        icon={faSpinner}
        spin
        size="2x"
        className="text-cyan-500"
      />
    </div>
  );
};

export default LoadingSpinner;
