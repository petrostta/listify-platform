import React from "react";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCheck,
  faPrint,
  faEnvelope,
} from "@fortawesome/free-solid-svg-icons";

const OrderConfirmation = ({ payment, orderId }) => {
  const navigate = useNavigate();

  const handlePrintReceipt = () => {
    window.print();
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 text-center">
      <div className="w-20 h-20 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-4">
        <FontAwesomeIcon icon={faCheck} className="text-green-600 text-4xl" />
      </div>

      <h2 className="text-2xl font-bold text-green-600 mb-2">
        Thank You For Your Order!
      </h2>
      <p className="text-gray-600 mb-6">
        Your payment was successful and your order is being processed.
      </p>

      <div className="mb-6 p-4 bg-gray-50 rounded-md inline-block text-left">
        <div className="mb-2">
          <span className="text-gray-500">Order Number:</span>
          <span className="font-medium ml-2">
            {orderId || payment?.orderId}
          </span>
        </div>

        <div className="mb-2">
          <span className="text-gray-500">Transaction ID:</span>
          <span className="font-medium ml-2">
            {payment?.gatewayTransactionId}
          </span>
        </div>

        <div>
          <span className="text-gray-500">Payment Method:</span>
          <span className="font-medium ml-2">
            {payment?.gatewayType === "stripe"
              ? "Credit Card"
              : payment?.gatewayType === "paypal"
              ? "PayPal"
              : "Online Payment"}
          </span>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 justify-center mb-6">
        <button
          onClick={handlePrintReceipt}
          className="flex items-center justify-center py-2 px-4 border border-gray-300 rounded-md hover:bg-gray-50"
        >
          <FontAwesomeIcon icon={faPrint} className="mr-2" />
          Print Receipt
        </button>

        <button
          onClick={() => {
            /* Email functionality would go here */
          }}
          className="flex items-center justify-center py-2 px-4 border border-gray-300 rounded-md hover:bg-gray-50"
        >
          <FontAwesomeIcon icon={faEnvelope} className="mr-2" />
          Email Receipt
        </button>
      </div>

      <div className="space-y-4">
        <button
          onClick={() => navigate("/orders")}
          className="block w-full py-3 px-4 bg-cyan-500 text-white rounded-md hover:bg-cyan-600 transition-colors"
        >
          View Order Status
        </button>

        <button
          onClick={() => navigate("/")}
          className="block w-full py-3 px-4 bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200 transition-colors"
        >
          Continue Shopping
        </button>
      </div>

      <p className="mt-6 text-sm text-gray-500">
        A confirmation email has been sent to your email address.
      </p>
    </div>
  );
};

export default OrderConfirmation;
