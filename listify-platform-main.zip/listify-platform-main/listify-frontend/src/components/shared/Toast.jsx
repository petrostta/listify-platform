import React, { useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faExclamationCircle, faCheckCircle, faTimes } from '@fortawesome/free-solid-svg-icons';

const Toast = ({ message, type = 'error', onClose, duration = 3000 }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, duration);
    
    return () => clearTimeout(timer);
  }, [duration, onClose]);

  // Each toast notification has different styles based on the error or success
  const bgColor = type === 'error' ? 'bg-red-50 border-red-300' : 'bg-green-50 border-green-300';
  const textColor = type === 'error' ? 'text-red-800' : 'text-green-800';
  const icon = type === 'error' ? faExclamationCircle : faCheckCircle;
  
  return (
    <div className={`fixed top-4 right-4 z-50 max-w-md p-4 rounded-lg shadow-lg border ${bgColor} animate-slideIn`}>
      <div className="flex items-start">
        <div className={`mr-3 ${textColor}`}>
          <FontAwesomeIcon icon={icon} />
        </div>
        <div className="flex-1">
          <p className={`text-sm ${textColor}`}>{message}</p>
        </div>
        <button 
          onClick={onClose} 
          className={`ml-4 ${textColor} hover:text-gray-500`}
        >
          <FontAwesomeIcon icon={faTimes} />
        </button>
      </div>
    </div>
  );
};

export default Toast;