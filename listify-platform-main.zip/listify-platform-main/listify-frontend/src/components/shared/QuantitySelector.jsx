import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus, faMinus } from "@fortawesome/free-solid-svg-icons";

const QuantitySelector = ({
  quantity = 1, // Provide default value
  onChange,
  min = 1,
  max = 999,
  small = false,
}) => {
  // converting quantity to string, handling null/undefined values
  const [inputValue, setInputValue] = useState(
    quantity !== null && quantity !== undefined ? quantity.toString() : "1"
  );

  // Update input value when quantity prop changes
  useEffect(() => {
    if (quantity !== null && quantity !== undefined) {
      setInputValue(quantity.toString());
    }
  }, [quantity]);

  const increment = () => {
    if (quantity < max) {
      const newValue = quantity + 1;
      setInputValue(newValue.toString());
      onChange(newValue);
    }
  };

  const decrement = () => {
    if (quantity > min) {
      const newValue = quantity - 1;
      setInputValue(newValue.toString());
      onChange(newValue);
    }
  };

  // Allowing any input during typing
  const handleChange = (e) => {
    
    setInputValue(e.target.value);
  };

  // Handle validation when the input loses focus
  const handleBlur = () => {
    let value = parseInt(inputValue, 10);

    // Handle non-numeric values
    if (isNaN(value)) {
      value = quantity || min;
    }

    // Apply min/max constraints
    if (value < min) {
      value = min;
    } else if (value > max) {
      value = max;
    }

    // Updating both local state and parent component
    setInputValue(value.toString());
    onChange(value);
  };

  // Handle Enter key press
  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      handleBlur();
    }
  };

  const buttonClasses = small
    ? "h-7 w-7 flex items-center justify-center border border-gray-300 text-gray-600"
    : "h-10 w-10 flex items-center justify-center border border-gray-300 text-gray-600";

  const inputClasses = small
    ? "h-7 w-12 border-t border-b border-gray-300 text-center text-sm"
    : "h-10 w-16 border-t border-b border-gray-300 text-center";

  // use quantity for comparisons, defaulting to min if null/undefined
  const safeQuantity =
    quantity !== null && quantity !== undefined ? quantity : min;

  return (
    <div className="flex items-center">
      <button
        onClick={decrement}
        className={`${buttonClasses} rounded-l ${
          safeQuantity <= min
            ? "opacity-50 cursor-not-allowed"
            : "hover:bg-gray-100"
        }`}
        disabled={safeQuantity <= min}
        aria-label="Decrease quantity"
      >
        <FontAwesomeIcon icon={faMinus} size={small ? "xs" : "sm"} />
      </button>

      <input
        type="text"
        value={inputValue}
        onChange={handleChange}
        onBlur={handleBlur}
        onKeyDown={handleKeyDown}
        className={inputClasses}
        aria-label="Quantity"
      />

      <button
        onClick={increment}
        className={`${buttonClasses} rounded-r ${
          safeQuantity >= max
            ? "opacity-50 cursor-not-allowed"
            : "hover:bg-gray-100"
        }`}
        disabled={safeQuantity >= max}
        aria-label="Increase quantity"
      >
        <FontAwesomeIcon icon={faPlus} size={small ? "xs" : "sm"} />
      </button>
    </div>
  );
};

export default QuantitySelector;
