import React, { useState, useRef } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faKey,
  faSpinner,
  faExclamationTriangle,
} from "@fortawesome/free-solid-svg-icons";

const PasswordChangeForm = ({ onSuccess, onError, loading, setLoading }) => {
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const isSubmittingRef = useRef(false);

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();

    if (isSubmittingRef.current || loading) {
      console.log("Submission already in progress, ignoring...");
      return;
    }

    isSubmittingRef.current = true;
    setLoading(true);

    try {
      if (passwordData.newPassword !== passwordData.confirmPassword) {
        onError("New passwords don't match");
        return;
      }

      if (passwordData.newPassword.length < 8) {
        onError("Password must be at least 8 characters long");
        return;
      }

      const passwordPolicy =
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-[\]{}|;:,.<>?]).{8,}$/;
      const noIdenticalCharacters = /(.)\1{2,}/;

      if (!passwordPolicy.test(passwordData.newPassword)) {
        onError(
          "Password must include at least one uppercase letter, one lowercase letter, one number, and one special character"
        );
        return;
      }

      if (noIdenticalCharacters.test(passwordData.newPassword)) {
        onError(
          "Password cannot contain three or more repeating characters in a row"
        );
        return;
      }

      if (passwordData.currentPassword === passwordData.newPassword) {
        onError("New password cannot be the same as current password");
        return;
      }

      console.log("Making password update request...");

      const response = await axios.put(
        "http://localhost:8080/api/auth/users/password",
        {
          currentPassword: passwordData.currentPassword,
          newPassword: passwordData.newPassword,
        },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      console.log("Password update successful:", response.data);

      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });

      const message =
        response?.data?.message || "Password updated successfully!";
      onSuccess(message);
    } catch (error) {
      console.error("Error updating password:", error);

      let errorMessage = "Failed to update password";

      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.status === 401) {
        errorMessage = "Current password is incorrect";
      } else if (error.response?.status === 400) {
        errorMessage =
          "Invalid password format or password requirements not met";
      } else if (error.message) {
        errorMessage = error.message;
      }

      onError(errorMessage);
    } finally {
      setLoading(false);
      isSubmittingRef.current = false;
    }
  };

  const getPasswordStrength = (password) => {
    if (password.length === 0) return { strength: 0, label: "" };

    let score = 0;
    const checks = [
      { regex: /.{8,}/, label: "At least 8 characters" },
      { regex: /[a-z]/, label: "Lowercase letter" },
      { regex: /[A-Z]/, label: "Uppercase letter" },
      { regex: /\d/, label: "Number" },
      { regex: /[!@#$%^&*()_+\-[\]{}|;:,.<>?]/, label: "Special character" },
    ];

    checks.forEach((check) => {
      if (check.regex.test(password)) score++;
    });

    if (score < 3) return { strength: 1, label: "Weak", color: "text-red-500" };
    if (score < 5)
      return { strength: 2, label: "Medium", color: "text-yellow-500" };
    return { strength: 3, label: "Strong", color: "text-green-500" };
  };

  const passwordStrength = getPasswordStrength(passwordData.newPassword);

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
        <FontAwesomeIcon icon={faKey} className="mr-2 text-cyan-500" />
        Change Password
      </h2>

      <form onSubmit={handlePasswordSubmit}>
        <div className="space-y-4 max-w-md">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Current Password *
            </label>
            <input
              type="password"
              name="currentPassword"
              value={passwordData.currentPassword}
              onChange={handlePasswordChange}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
              autoComplete="current-password"
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              New Password *
            </label>
            <input
              type="password"
              name="newPassword"
              value={passwordData.newPassword}
              onChange={handlePasswordChange}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
              autoComplete="new-password"
              disabled={loading}
            />

            {passwordData.newPassword && (
              <div className="mt-2">
                <div className="flex items-center space-x-2">
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all duration-300 ${
                        passwordStrength.strength === 1
                          ? "bg-red-500 w-1/3"
                          : passwordStrength.strength === 2
                          ? "bg-yellow-500 w-2/3"
                          : passwordStrength.strength === 3
                          ? "bg-green-500 w-full"
                          : "w-0"
                      }`}
                    />
                  </div>
                  <span
                    className={`text-xs font-medium ${passwordStrength.color}`}
                  >
                    {passwordStrength.label}
                  </span>
                </div>
              </div>
            )}

            <div className="mt-2">
              <p className="text-xs text-gray-600 mb-1">
                Password requirements:
              </p>
              <ul className="text-xs text-gray-500 space-y-1">
                <li
                  className={
                    passwordData.newPassword.length >= 8 ? "text-green-600" : ""
                  }
                >
                  • At least 8 characters
                </li>
                <li
                  className={
                    /[a-z]/.test(passwordData.newPassword)
                      ? "text-green-600"
                      : ""
                  }
                >
                  • One lowercase letter
                </li>
                <li
                  className={
                    /[A-Z]/.test(passwordData.newPassword)
                      ? "text-green-600"
                      : ""
                  }
                >
                  • One uppercase letter
                </li>
                <li
                  className={
                    /\d/.test(passwordData.newPassword) ? "text-green-600" : ""
                  }
                >
                  • One number
                </li>
                <li
                  className={
                    /[!@#$%^&*()_+\-[\]{}|;:,.<>?]/.test(
                      passwordData.newPassword
                    )
                      ? "text-green-600"
                      : ""
                  }
                >
                  • One special character
                </li>
                <li
                  className={
                    !/(.)\1{2,}/.test(passwordData.newPassword)
                      ? "text-green-600"
                      : ""
                  }
                >
                  • No repeating characters
                </li>
              </ul>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Confirm New Password *
            </label>
            <input
              type="password"
              name="confirmPassword"
              value={passwordData.confirmPassword}
              onChange={handlePasswordChange}
              className={`w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 ${
                passwordData.confirmPassword &&
                passwordData.newPassword !== passwordData.confirmPassword
                  ? "border-red-300 focus:ring-red-500"
                  : "border-gray-300 focus:ring-cyan-500"
              }`}
              required
              autoComplete="new-password"
              disabled={loading}
            />
            {passwordData.confirmPassword &&
              passwordData.newPassword !== passwordData.confirmPassword && (
                <p className="text-xs text-red-500 mt-1 flex items-center">
                  <FontAwesomeIcon
                    icon={faExclamationTriangle}
                    className="mr-1"
                  />
                  Passwords do not match
                </p>
              )}
          </div>

          <div className="pt-4">
            <button
              type="submit"
              className="w-full md:w-auto px-6 py-2 bg-cyan-500 text-white rounded-md hover:bg-cyan-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center transition-colors"
              disabled={
                loading ||
                isSubmittingRef.current ||
                passwordData.newPassword !== passwordData.confirmPassword ||
                !passwordData.currentPassword ||
                !passwordData.newPassword
              }
            >
              {loading ? (
                <>
                  <FontAwesomeIcon icon={faSpinner} spin className="mr-2" />
                  Updating Password...
                </>
              ) : (
                <>
                  <FontAwesomeIcon icon={faKey} className="mr-2" />
                  Update Password
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default PasswordChangeForm;
