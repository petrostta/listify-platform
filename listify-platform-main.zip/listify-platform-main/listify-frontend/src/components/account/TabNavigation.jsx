import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser, faLock, faStar } from "@fortawesome/free-solid-svg-icons";

const TabNavigation = ({ activeTab, setActiveTab }) => {
  return (
    <div className="border-b border-gray-200">
      <nav className="flex -mb-px">
        <button
          onClick={() => setActiveTab("profile")}
          className={`py-4 px-6 font-medium text-sm border-b-2 focus:outline-none ${
            activeTab === "profile"
              ? "border-cyan-500 text-cyan-600"
              : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
          }`}
        >
          <FontAwesomeIcon icon={faUser} className="mr-2" />
          Profile
        </button>
        <button
          onClick={() => setActiveTab("security")}
          className={`py-4 px-6 font-medium text-sm border-b-2 focus:outline-none ${
            activeTab === "security"
              ? "border-cyan-500 text-cyan-600"
              : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
          }`}
        >
          <FontAwesomeIcon icon={faLock} className="mr-2" />
          Security
        </button>
        <button
          onClick={() => setActiveTab("reviews")}
          className={`py-4 px-6 font-medium text-sm border-b-2 focus:outline-none ${
            activeTab === "reviews"
              ? "border-cyan-500 text-cyan-600"
              : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
          }`}
        >
          <FontAwesomeIcon icon={faStar} className="mr-2" />
          Reviews
        </button>
      </nav>
    </div>
  );
};

export default TabNavigation;
