import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser } from "@fortawesome/free-solid-svg-icons";

const AccountHeader = () => {
  return (
    <div className="bg-cyan-500 p-6">
      <div className="flex items-center">
        <div className="bg-white rounded-full p-4 shadow-md">
          <FontAwesomeIcon icon={faUser} className="text-cyan-500 text-2xl" />
        </div>
        <div className="ml-4 text-white">
          <h1 className="text-2xl font-bold">My Account</h1>
          <p>Manage your personal information and account settings</p>
        </div>
      </div>
    </div>
  );
};

export default AccountHeader;
