import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEnvelope,
  faSpinner,
  faExclamationTriangle,
  faInfoCircle,
} from "@fortawesome/free-solid-svg-icons";

const EmailChangeForm = ({
  user,
  onSuccess,
  onError,
  loading,
  setLoading,
  refreshUser,
}) => {
  const [emailData, setEmailData] = useState({
    newEmail: "",
    confirmEmail: "",
  });

  const isSubmittingRef = useRef(false);

  useEffect(() => {
    setEmailData({
      newEmail: "",
      confirmEmail: "",
    });
  }, [user]);

  const handleEmailChange = (e) => {
    const { name, value } = e.target;
    setEmailData((prev) => ({ ...prev, [name]: value.trim() }));
  };

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleEmailSubmit = async (e) => {
    e.preventDefault();

    if (isSubmittingRef.current || loading) {
      console.log("Email submission already in progress, ignoring...");
      return;
    }

    isSubmittingRef.current = true;
    setLoading(true);

    try {
      if (!validateEmail(emailData.newEmail)) {
        onError("Please enter a valid email address");
        return;
      }

      if (emailData.newEmail !== emailData.confirmEmail) {
        onError("Email addresses don't match");
        return;
      }

      if (
        user?.email &&
        emailData.newEmail.toLowerCase() === user.email.toLowerCase()
      ) {
        onError("This is already your current email address");
        return;
      }

      console.log("Making email update request...");

      const response = await axios.put(
        "http://localhost:8080/api/auth/users/email",
        {
          newEmail: emailData.newEmail,
        },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      console.log("Email update successful:", response.data);

      // Reset form
      setEmailData({
        newEmail: "",
        confirmEmail: "",
      });

      const message = response?.data?.message || "Email updated successfully";
      const newEmail = response?.data?.newEmail || emailData.newEmail;

      onSuccess(`${message} to ${newEmail}`);

      if (refreshUser) {
        setTimeout(() => {
          refreshUser();
        }, 1000);
      }
    } catch (error) {
      console.error("Error updating email:", error);

      let errorMessage = "Failed to update email address";

      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.status === 400) {
        errorMessage = "Invalid email address or email already in use";
      } else if (error.response?.status === 401) {
        errorMessage = "You are not authorized to perform this action";
      } else if (error.message) {
        errorMessage = error.message;
      }

      onError(errorMessage);
    } finally {
      setLoading(false);
      isSubmittingRef.current = false;
    }
  };

  const isEmailValid = validateEmail(emailData.newEmail);
  const emailsMatch = emailData.newEmail === emailData.confirmEmail;

  return (
    <div className="pt-8 border-t border-gray-200">
      <h2 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
        <FontAwesomeIcon icon={faEnvelope} className="mr-2 text-cyan-500" />
        Change Email Address
      </h2>

      {user?.email && (
        <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
          <p className="text-sm text-blue-800 flex items-center">
            <FontAwesomeIcon icon={faInfoCircle} className="mr-2" />
            Current email:{" "}
            <span className="font-medium ml-1">{user.email}</span>
          </p>
        </div>
      )}

      <form onSubmit={handleEmailSubmit}>
        <div className="space-y-4 max-w-md">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              New Email Address *
            </label>
            <input
              type="email"
              name="newEmail"
              value={emailData.newEmail}
              onChange={handleEmailChange}
              className={`w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 ${
                emailData.newEmail && !isEmailValid
                  ? "border-red-300 focus:ring-red-500"
                  : "border-gray-300 focus:ring-cyan-500"
              }`}
              required
              autoComplete="email"
              placeholder="Enter new email address"
              disabled={loading}
            />
            {emailData.newEmail && !isEmailValid && (
              <p className="text-xs text-red-500 mt-1 flex items-center">
                <FontAwesomeIcon
                  icon={faExclamationTriangle}
                  className="mr-1"
                />
                Please enter a valid email address
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Confirm New Email Address *
            </label>
            <input
              type="email"
              name="confirmEmail"
              value={emailData.confirmEmail}
              onChange={handleEmailChange}
              className={`w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 ${
                emailData.confirmEmail && !emailsMatch
                  ? "border-red-300 focus:ring-red-500"
                  : "border-gray-300 focus:ring-cyan-500"
              }`}
              required
              autoComplete="email"
              placeholder="Confirm new email address"
              disabled={loading} // Disable during submission
            />
            {emailData.confirmEmail && !emailsMatch && (
              <p className="text-xs text-red-500 mt-1 flex items-center">
                <FontAwesomeIcon
                  icon={faExclamationTriangle}
                  className="mr-1"
                />
                Email addresses do not match
              </p>
            )}
          </div>

          <div className="pt-4">
            <button
              type="submit"
              className="w-full md:w-auto px-6 py-2 bg-cyan-500 text-white rounded-md hover:bg-cyan-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center transition-colors"
              disabled={
                loading ||
                isSubmittingRef.current ||
                !isEmailValid ||
                !emailsMatch ||
                !emailData.newEmail ||
                !emailData.confirmEmail
              }
            >
              {loading ? (
                <>
                  <FontAwesomeIcon icon={faSpinner} spin className="mr-2" />
                  Updating Email...
                </>
              ) : (
                <>
                  <FontAwesomeIcon icon={faEnvelope} className="mr-2" />
                  Update Email
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default EmailChangeForm;
