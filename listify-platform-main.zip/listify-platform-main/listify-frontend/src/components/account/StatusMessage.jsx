import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { 
  faCheck, 
  faExclamationTriangle 
} from "@fortawesome/free-solid-svg-icons";

const StatusMessage = ({ success, error, onDismissError, activeTab }) => {
  if (!success && !error) return null;

  return (
    <>
      {success && (
        <div className="bg-green-100 text-green-700 p-4 flex items-center">
          <FontAwesomeIcon icon={faCheck} className="mr-2" />
          {activeTab === "profile"
            ? "Profile updated successfully!"
            : activeTab === "security" 
              ? "Changes saved successfully! You may be logged out shortly."
              : "Update successful!"}
        </div>
      )}

      {error && (
        <div className="bg-red-100 text-red-700 p-4 flex items-center">
          <FontAwesomeIcon icon={faExclamationTriangle} className="mr-2" />
          {error}
          <button
            onClick={onDismissError}
            className="ml-auto text-red-700 hover:text-red-900"
          >
            ×
          </button>
        </div>
      )}
    </>
  );
};

export default StatusMessage;