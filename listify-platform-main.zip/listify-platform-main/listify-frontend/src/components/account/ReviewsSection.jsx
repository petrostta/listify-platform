import React, { useState, useEffect, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faShoppingBag,
  faPen,
  faCheck,
  faStar,
  faEdit,
  faTrash,
  faSpinner,
  faExclamationTriangle,
} from "@fortawesome/free-solid-svg-icons";
import { faStar as regularStar } from "@fortawesome/free-regular-svg-icons";
import WriteReviewForm from "../product/WriteReviewForm";
import axios from "axios";
import { AuthContext } from "../../context/AuthContext";

const ReviewsSection = ({ user, onSuccess, onError }) => {
  const [loading, setLoading] = useState(true);
  const [eligibleProducts, setEligibleProducts] = useState([]);
  const [userReviews, setUserReviews] = useState([]);
  const [activeTab, setActiveTab] = useState("pending");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [reviewToEdit, setReviewToEdit] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null);

  const navigate = useNavigate();
  const { token } = useContext(AuthContext);

  useEffect(() => {
    if (user?.uuid) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch products eligible for review
      const eligibleResponse = await axios.get(
        "http://localhost:8080/api/reviews/eligibility",
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      // Fetch user's reviews with product details
      const reviewsResponse = await axios.get(
        "http://localhost:8080/api/reviews/user",
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
          params: {
            includeProductDetails: true,
          },
        }
      );

      setEligibleProducts(eligibleResponse.data.eligibleProducts || []);
      setUserReviews(reviewsResponse.data.reviews || []);
    } catch (error) {
      console.error("Error fetching review data:", error);
      onError("Failed to load review data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Get product image URL with better fallback handling
  const getProductImageUrl = (product) => {
    // For eligible products (pending reviews)
    if (product.image) {
      return product.image;
    }

    if (product.pictures && product.pictures.length > 0) {
      const firstPicture = product.pictures[0];
      if (firstPicture.url) {
        return firstPicture.url;
      }
      if (firstPicture.key) {
        return `https://pub-e2dfc4f311fa40c0b98535194e9c7266.r2.dev/${firstPicture.key}`;
      }
    }

    // For user reviews
    if (product.product?.pictures && product.product.pictures.length > 0) {
      const firstPicture = product.product.pictures[0];
      if (firstPicture.url) {
        return firstPicture.url;
      }
      if (firstPicture.key) {
        return `https://pub-e2dfc4f311fa40c0b98535194e9c7266.r2.dev/${firstPicture.key}`;
      }
    }

    return "/placeholder-product.png";
  };

  const handleWriteReview = (product) => {
    setSelectedProduct(product);
    setShowReviewForm(true);
    setIsEditing(false);
    setReviewToEdit(null);
  };

  const handleEditReview = (review) => {
    setReviewToEdit(review);
    setSelectedProduct({
      productId: review.productId,
      orderId: review.orderId,
      productName: review.productName || review.product?.name || "Product",
    });
    setShowReviewForm(true);
    setIsEditing(true);
  };

  const handleDeleteReview = (reviewId) => {
    setConfirmDelete(reviewId);
  };

  const confirmDeleteReview = async (reviewId) => {
    setDeleteLoading(true);
    try {
      await axios.delete(`http://localhost:8080/api/reviews/${reviewId}`, {
        headers: {
          Authorization: `Bearer ${token || localStorage.getItem("token")}`,
        },
      });

      setUserReviews(userReviews.filter((review) => review.uuid !== reviewId));
      onSuccess("Review deleted successfully!");
    } catch (error) {
      console.error("Error deleting review:", error);
      onError("Failed to delete review. Please try again.");
    } finally {
      setDeleteLoading(false);
      setConfirmDelete(null);
    }
  };

  const handleReviewSubmitted = () => {
    setShowReviewForm(false);
    setSelectedProduct(null);
    setReviewToEdit(null);
    setIsEditing(false);
    fetchData();
    onSuccess(
      isEditing
        ? "Review updated successfully!"
        : "Review submitted successfully!"
    );
  };

  const handleProductClick = (productId) => {
    navigate(`/product/${productId}`);
  };

  const renderStarRating = (rating) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <FontAwesomeIcon
          key={i}
          icon={i < rating ? faStar : regularStar}
          className={i < rating ? "text-yellow-400" : "text-gray-300"}
        />
      ));
  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin h-8 w-8 border-2 border-cyan-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="border-b border-gray-200">
        <nav className="flex -mb-px">
          <button
            onClick={() => setActiveTab("pending")}
            className={`py-3 px-4 font-medium text-sm border-b-2 ${
              activeTab === "pending"
                ? "border-cyan-500 text-cyan-600"
                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
          >
            Pending Reviews ({eligibleProducts.length})
          </button>
          <button
            onClick={() => setActiveTab("completed")}
            className={`py-3 px-4 font-medium text-sm border-b-2 ${
              activeTab === "completed"
                ? "border-cyan-500 text-cyan-600"
                : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
            }`}
          >
            Your Reviews ({userReviews.length})
          </button>
        </nav>
      </div>

      {showReviewForm && selectedProduct && (
        <div className="bg-gray-50 p-4 rounded-lg mb-6">
          <h3 className="text-lg font-medium mb-2">
            {isEditing ? "Edit review for " : "Write a review for "}
            <span className="font-semibold text-cyan-600">
              {selectedProduct.productName || "this product"}
            </span>
          </h3>
          <WriteReviewForm
            productId={selectedProduct.productId}
            orderId={selectedProduct.orderId}
            initialRating={isEditing ? reviewToEdit.rating : undefined}
            initialReview={
              isEditing ? reviewToEdit.reviewDescription : undefined
            }
            reviewId={isEditing ? reviewToEdit.uuid : undefined}
            isEditing={isEditing}
            onSubmitted={handleReviewSubmitted}
            onCancel={() => {
              setShowReviewForm(false);
              setSelectedProduct(null);
              setReviewToEdit(null);
              setIsEditing(false);
            }}
          />
        </div>
      )}

      {activeTab === "pending" && (
        <div>
          <h3 className="text-lg font-medium mb-4">Products to Review</h3>

          {eligibleProducts.length === 0 ? (
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <FontAwesomeIcon
                icon={faCheck}
                className="text-3xl text-gray-400 mb-2"
              />
              <p className="text-gray-600">
                You don't have any products to review right now.
              </p>
              <p className="text-sm text-gray-500 mt-1">
                Products you purchase will appear here for review after
                delivery.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {eligibleProducts.map((product) => (
                <div
                  key={`${product.productId}-${product.orderId}`}
                  className="border rounded-lg p-4 flex items-start hover:shadow-md transition-shadow bg-white"
                >
                  {/* Product Image */}
                  <div
                    className="bg-gray-100 rounded-lg h-20 w-20 flex items-center justify-center flex-shrink-0 cursor-pointer overflow-hidden border"
                    onClick={() => handleProductClick(product.productId)}
                  >
                    <img
                      src={getProductImageUrl(product)}
                      alt={product.productName || "Product"}
                      className="h-full w-full object-cover hover:scale-105 transition-transform duration-200"
                      onError={(e) => {
                        e.target.src = "/placeholder-product.png";
                      }}
                    />
                  </div>

                  {/* Product Details */}
                  <div className="ml-4 flex-grow">
                    <h4
                      className="font-medium text-lg cursor-pointer hover:text-cyan-600 transition-colors mb-1 line-clamp-2"
                      onClick={() => handleProductClick(product.productId)}
                      title={product.productName || "Product"}
                    >
                      {product.productName || "Product"}
                    </h4>
                    <p className="text-sm text-gray-500 mb-3">
                      Order: {product.orderId.substring(0, 8)}...
                    </p>
                    <button
                      onClick={() => handleWriteReview(product)}
                      className="px-4 py-2 bg-cyan-500 text-white rounded-md text-sm inline-flex items-center hover:bg-cyan-600 transition-colors"
                    >
                      <FontAwesomeIcon icon={faPen} className="mr-2" />
                      Write Review
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === "completed" && (
        <div>
          <h3 className="text-lg font-medium mb-4">Your Reviews</h3>

          {userReviews.length === 0 ? (
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <FontAwesomeIcon
                icon={faStar}
                className="text-3xl text-gray-400 mb-2"
              />
              <p className="text-gray-600">
                You haven't written any reviews yet.
              </p>
              <p className="text-sm text-gray-500 mt-1">
                Your submitted reviews will appear here.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {userReviews.map((review) => (
                <div
                  key={review.uuid}
                  className="border rounded-lg p-4 hover:shadow-sm transition-shadow bg-white"
                >
                  <div className="flex items-start mb-3">
                    {/* Product Image */}
                    <div
                      className="bg-gray-100 rounded-lg h-16 w-16 flex items-center justify-center flex-shrink-0 mr-4 overflow-hidden cursor-pointer border"
                      onClick={() => handleProductClick(review.productId)}
                    >
                      <img
                        src={getProductImageUrl(review)}
                        alt={
                          review.productName ||
                          review.product?.name ||
                          "Product"
                        }
                        className="h-full w-full object-cover hover:scale-105 transition-transform duration-200"
                        onError={(e) => {
                          e.target.src = "/placeholder-product.png";
                        }}
                      />
                    </div>

                    {/* Review Content */}
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <h4
                          className="font-medium text-lg text-cyan-600 cursor-pointer hover:underline line-clamp-2"
                          onClick={() => handleProductClick(review.productId)}
                          title={
                            review.productName ||
                            review.product?.name ||
                            "Product"
                          }
                        >
                          {review.productName ||
                            review.product?.name ||
                            "Product"}
                        </h4>
                        <span className="text-sm text-gray-500 whitespace-nowrap ml-4">
                          {new Date(review.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      <div className="flex items-center mb-3">
                        <div className="flex mr-2">
                          {renderStarRating(review.rating)}
                        </div>
                        <span className="text-sm font-medium text-gray-700">
                          {review.rating}/5
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="text-gray-700 mb-3 leading-relaxed">
                    {review.reviewDescription}
                  </p>

                  <div className="flex justify-end space-x-2">
                    <button
                      onClick={() => handleEditReview(review)}
                      className="text-sm px-3 py-1 border border-cyan-500 text-cyan-600 rounded hover:bg-cyan-50 flex items-center transition-colors"
                    >
                      <FontAwesomeIcon icon={faEdit} className="mr-1" />
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteReview(review.uuid)}
                      className="text-sm px-3 py-1 border border-red-500 text-red-600 rounded hover:bg-red-50 flex items-center transition-colors"
                    >
                      <FontAwesomeIcon icon={faTrash} className="mr-1" />
                      Delete
                    </button>
                  </div>

                  {confirmDelete === review.uuid && (
                    <div className="mt-3 p-3 bg-red-50 rounded-md border border-red-200">
                      <div className="flex items-center mb-2">
                        <FontAwesomeIcon
                          icon={faExclamationTriangle}
                          className="text-red-500 mr-2"
                        />
                        <span className="text-red-600 font-medium">
                          Are you sure you want to delete this review?
                        </span>
                      </div>
                      <div className="flex justify-end space-x-2">
                        <button
                          onClick={() => setConfirmDelete(null)}
                          className="text-sm px-3 py-1 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 transition-colors"
                          disabled={deleteLoading}
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => confirmDeleteReview(review.uuid)}
                          className="text-sm px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 flex items-center transition-colors"
                          disabled={deleteLoading}
                        >
                          {deleteLoading ? (
                            <>
                              <FontAwesomeIcon
                                icon={faSpinner}
                                spin
                                className="mr-1"
                              />
                              Deleting...
                            </>
                          ) : (
                            "Confirm Delete"
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ReviewsSection;
