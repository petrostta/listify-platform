import React, { useState, useEffect, useContext } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faClose,
  faArrowLeft,
  faWandMagicSparkles,
} from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import { AuthContext } from "../context/AuthContext";

const LoginPopup = ({ setShowLogin }) => {
  const { login } = useContext(AuthContext);
  const [currState, setCurrState] = useState("Login");
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone_number: "",
  });

  const [showPopup, setShowPopup] = useState(false);
  const [isClosing, setIsClosing] = useState(false);

  useEffect(() => {
    setShowPopup(true);
  }, []);

  const handleSwitchState = () => {
    setCurrState(currState === "Register" ? "Login" : "Register");
    setFormData({
      first_name: "",
      last_name: "",
      email: "",
      password: "",
      confirmPassword: "",
      phone_number: "",
    });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const closePopup = () => {
    setIsClosing(true);
    setTimeout(() => {
      setShowLogin(false);
    }, 300);
  };

  const generateRandomPassword = () => {
    const length = Math.floor(Math.random() * 5) + 12; // generates a random length between 12 and 16
    const lower = "abcdefghijklmnopqrstuvwxyz";
    const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const numbers = "0123456789";
    const symbols = "!@#$%^&*()_+[]{}|;:,.<>?";

    const allChars = lower + upper + numbers + symbols;

    let password = "";
    password += lower[Math.floor(Math.random() * lower.length)];
    password += upper[Math.floor(Math.random() * upper.length)];
    password += numbers[Math.floor(Math.random() * numbers.length)];
    password += symbols[Math.floor(Math.random() * symbols.length)];

    for (let i = password.length; i < length; i++) {
      password += allChars[Math.floor(Math.random() * allChars.length)];
    }

    // Shuffling the password for better randomness
    password = password
      .split("")
      .sort(() => Math.random() - 0.5)
      .join("");

    setFormData((prev) => ({
      ...prev,
      password: password,
      confirmPassword: password,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (currState === "Register") {
        if (formData.password !== formData.confirmPassword) {
          console.error("Passwords don't match");
          return;
        }
      }

      const url =
        currState === "Login"
          ? "http://localhost:8080/api/auth/users/login"
          : "http://localhost:8080/api/auth/users/register";

      const submitData =
        currState === "Login"
          ? { email: formData.email, password: formData.password }
          : {
              email: formData.email,
              password: formData.password,
              first_name: formData.first_name,
              last_name: formData.last_name,
              phone_number: formData.phone_number,
            };

      const response = await axios.post(url, submitData);

      if (currState === "Login") {
        if (response.data.token) {
          login({ uuid: response.data.uuid }, response.data.token);
          closePopup();
        } else {
          console.error("No token received from server");
        }
      } else {
        closePopup();
      }
    } catch (error) {
      console.error("Error during authentication:", error);
      if (error.response) {
        console.error("Error response data:", error.response.data);
        console.error("Error response status:", error.response.status);
        console.error("Error response headers:", error.response.headers);
      }
    }
  };

  return (
    <div
      className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"
      onClick={closePopup}
    >
      <div
        className={`relative bg-white border-2 border-cyan-500 rounded-lg p-6 w-[400px] flex flex-col items-center transform transition-all duration-100 ease-in-out 
        ${
          isClosing
            ? "scale-95 opacity-0"
            : showPopup
            ? "scale-100 opacity-100"
            : "scale-95 opacity-0"
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-full flex justify-between items-center mb-6">
          {currState === "Register" && (
            <FontAwesomeIcon
              icon={faArrowLeft}
              onClick={handleSwitchState}
              className="text-xl cursor-pointer text-cyan-500 hover:scale-110"
            />
          )}
          <FontAwesomeIcon
            icon={faClose}
            onClick={closePopup}
            className="text-xl cursor-pointer text-cyan-500 hover:scale-110"
          />
        </div>

        {currState === "Register" && (
          <>
            <div className="flex w-full mb-4">
              <div className="w-1/2 pr-2">
                <label className="w-full text-left mb-1 text-sm font-semibold text-gray-700">
                  First Name
                </label>
                <input
                  type="text"
                  name="first_name"
                  value={formData.first_name}
                  onChange={handleChange}
                  placeholder="First Name"
                  className="w-full border border-cyan-500 rounded-md p-2"
                  required
                />
              </div>
              <div className="w-1/2 pl-2">
                <label className="w-full text-left mb-1 text-sm font-semibold text-gray-700">
                  Last Name
                </label>
                <input
                  type="text"
                  name="last_name"
                  value={formData.last_name}
                  onChange={handleChange}
                  placeholder="Last Name"
                  className="w-full border border-cyan-500 rounded-md p-2"
                  required
                />
              </div>
            </div>
          </>
        )}

        <label className="w-full text-left mb-1 text-sm font-semibold text-gray-700">
          Email address
        </label>
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          placeholder="Email"
          className="w-full border border-cyan-500 rounded-md p-2 mb-4"
          required
        />

        <label className="w-full text-left mb-1 text-sm font-semibold text-gray-700">
          Password
        </label>
        <div className="relative w-full mb-4">
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Password"
            className="w-full border border-cyan-500 rounded-md p-2 pr-10"
            required
          />
          {currState === "Register" && (
            <FontAwesomeIcon
              icon={faWandMagicSparkles}
              onClick={generateRandomPassword}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-cyan-500 cursor-pointer hover:scale-110"
            />
          )}
        </div>

        {currState === "Register" && (
          <>
            <label className="w-full text-left mb-1 text-sm font-semibold text-gray-700">
              Confirm Password
            </label>
            <input
              type="password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              placeholder="Confirm Password"
              className="w-full border border-cyan-500 rounded-md p-2 mb-4"
              required
            />
          </>
        )}
        {currState === "Register" && (
          <>
            <label className="w-full text-left mb-1 text-sm font-semibold text-gray-700">
              Phone Number
            </label>
            <input
              type="tel"
              name="phone_number"
              value={formData.phone_number}
              onChange={handleChange}
              placeholder="Phone Number"
              className="w-full border border-cyan-500 rounded-md p-2 mb-4"
            />
          </>
        )}
        {currState === "Register" && (
          <p className="text-gray-500 mb-4 text-sm text-center">
            By clicking Register, you agree to{" "}
            <span className="text-cyan-500 underline cursor-pointer font-semibold">
              Listify's
            </span>{" "}
            <span className="text-cyan-500 underline cursor-pointer font-semibold">
              Terms of Use
            </span>{" "}
            and{" "}
            <span className="text-cyan-500 underline cursor-pointer font-semibold">
              Privacy Policy
            </span>
            .
          </p>
        )}

        <button
          type="submit"
          className="bg-cyan-500 text-white py-2 px-4 rounded-md w-full hover:bg-cyan-600 transition-all font-semibold"
          onClick={handleSubmit}
        >
          {currState === "Login" ? "Login" : "Register"}
        </button>

        <div className="mt-4 text-center">
          {currState === "Login" ? (
            <>
              <span>Don't have an account? </span>
              <button
                type="button"
                onClick={handleSwitchState}
                className="text-cyan-500 underline font-semibold"
              >
                Register
              </button>
            </>
          ) : (
            <>
              <span>Already have an account? </span>
              <button
                type="button"
                onClick={handleSwitchState}
                className="text-cyan-500 underline font-semibold"
              >
                Login
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoginPopup;
