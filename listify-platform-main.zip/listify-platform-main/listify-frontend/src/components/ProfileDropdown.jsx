import React, { useState, useEffect, useRef, useContext } from "react";
import { NavLink } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { UserIcon } from "@heroicons/react/outline";

const ProfileDropdown = () => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);
  const { logout } = useContext(AuthContext);

  const options = [
    { name: "Account", path: "/account" },
    { name: "Orders", path: "/orders" },
    { name: "Logout", path: "/logout" },
  ];

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const closeDropdown = (e) => {
    if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener("click", closeDropdown);
    return () => {
      document.removeEventListener("click", closeDropdown);
    };
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Profile Button */}
      <div
        className="flex items-center cursor-pointer hover:bg-cyan-500 hover:bg-opacity-50 hover:rounded-3xl py-2 px-2 transition-all duration-300 ml-[-6px]"
        onClick={toggleDropdown}
      >
        <UserIcon className="h-6 w-6 text-[16px] text-black" />
        <span className="ml-2 text-black text-[16px] font-semibold">
          Profile
        </span>
      </div>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute left-0 mt-4 w-48 bg-white shadow-lg border rounded-xl z-10 max-h-64 overflow-y-auto scrollbar-hidden z-50">
          {options.map((option, index) => {
            // For logout, use a div with onClick
            if (option.name === "Logout") {
              return (
                <div
                  key={index}
                  className={`block py-2 px-4 hover:bg-cyan-500 hover:bg-opacity-50 transition-all font-semibold cursor-pointer ${
                    index === 0 ? "rounded-t-xl" : ""
                  } ${index === options.length - 1 ? "rounded-b-xl" : ""}`}
                  onClick={() => {
                    logout();
                    setIsOpen(false);
                  }}
                >
                  {option.name}
                </div>
              );
            }

            // For other options, use NavLink
            return (
              <NavLink
                key={index}
                to={option.path}
                className={({ isActive }) =>
                  `block py-2 px-4 hover:bg-cyan-500 hover:bg-opacity-50 transition-all font-semibold ${
                    isActive ? "bg-cyan-100" : ""
                  } ${index === 0 ? "rounded-t-xl" : ""} ${
                    index === options.length - 1 ? "rounded-b-xl" : ""
                  }`
                }
                onClick={() => setIsOpen(false)}
              >
                {option.name}
              </NavLink>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ProfileDropdown;
