import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFilter, faTimesCircle } from "@fortawesome/free-solid-svg-icons";

const MobileFilters = ({
  filters,
  handleFilterChange,
  applyFilters,
  clearFilters,
  showFilters,
  setShowFilters,
}) => {
  return (
    <div className="md:hidden mb-4">
      <button
        onClick={() => setShowFilters(!showFilters)}
        className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg shadow border border-gray-200"
      >
        <FontAwesomeIcon icon={faFilter} />
        <span>Filters</span>
      </button>

      {showFilters && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex items-end">
          <div className="bg-white rounded-t-xl p-6 w-full h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-medium text-lg">Filters</h2>
              <button onClick={() => setShowFilters(false)}>
                <FontAwesomeIcon
                  icon={faTimesCircle}
                  className="text-gray-500 text-xl"
                />
              </button>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Price Range
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    name="minPrice"
                    placeholder="Min"
                    value={filters.minPrice}
                    onChange={handleFilterChange}
                    className="w-full p-3 border border-gray-300 rounded-lg text-sm"
                  />
                  <span>-</span>
                  <input
                    type="number"
                    name="maxPrice"
                    placeholder="Max"
                    value={filters.maxPrice}
                    onChange={handleFilterChange}
                    className="w-full p-3 border border-gray-300 rounded-lg text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category
                </label>
                <select
                  name="category"
                  value={filters.category}
                  onChange={handleFilterChange}
                  className="w-full p-3 border border-gray-300 rounded-lg text-sm"
                >
                  <option value="">All Categories</option>
                  <option value="Electronics">Electronics</option>
                  <option value="Fashion">Fashion</option>
                  <option value="Home & Garden">Home & Garden</option>
                  <option value="Sports">Sports</option>
                  <option value="Books">Books</option>
                  <option value="Toys">Toys</option>
                  <option value="Health & Beauty">Health & Beauty</option>
                  <option value="Automotive">Automotive</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Sort By
                </label>
                <select
                  name="sortField"
                  value={filters.sortField}
                  onChange={handleFilterChange}
                  className="w-full p-3 border border-gray-300 rounded-lg text-sm"
                >
                  <option value="price">Price</option>
                  <option value="name">Name</option>
                  <option value="createdAt">Newest</option>
                  <option value="rating">Rating</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Sort Order
                </label>
                <select
                  name="sortOrder"
                  value={filters.sortOrder}
                  onChange={handleFilterChange}
                  className="w-full p-3 border border-gray-300 rounded-lg text-sm"
                >
                  <option value="asc">Ascending</option>
                  <option value="desc">Descending</option>
                </select>
              </div>

              <div className="pt-4 space-y-3">
                <button
                  onClick={applyFilters}
                  className="w-full bg-cyan-500 text-white py-3 px-4 rounded-lg text-lg font-medium hover:bg-cyan-600 transition-colors"
                >
                  Apply Filters
                </button>
                <button
                  onClick={clearFilters}
                  className="w-full bg-gray-100 text-gray-800 py-3 px-4 rounded-lg text-lg font-medium hover:bg-gray-200 transition-colors"
                >
                  Clear Filters
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MobileFilters;
