import React from "react";
import ProductCard from "./ProductCard";
import { useNavigate } from "react-router-dom";

const ProductGrid = ({ products, loading, error, searchQuery }) => {
  const navigate = useNavigate();

  // I need to implement this function to add products to the cart
  const addToCart = (productId) => {
    
    console.log(`Adding product ${productId} to cart`);
  };

  if (loading) {
    return <LoadingSkeleton />;
  }

  if (error) {
    return <div className="bg-red-50 text-red-500 p-4 rounded-lg">{error}</div>;
  }

  if (products.length === 0) {
    return (
      <div className="bg-white p-8 rounded-lg shadow text-center">
        <p className="text-gray-500 mb-4">
          No products found matching your search criteria.
        </p>
        {searchQuery && (
          <button
            onClick={() => navigate("/")}
            className="text-cyan-600 hover:text-cyan-800"
          >
            Return to homepage
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {products.map((product) => (
        <ProductCard
          key={product.uuid}
          product={product}
          addToCart={addToCart}
        />
      ))}
    </div>
  );
};

const LoadingSkeleton = () => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100 animate-pulse"
        >
          <div className="aspect-w-1 aspect-h-1 bg-gray-200 h-48"></div>
          <div className="p-4 space-y-3">
            <div className="h-2 bg-gray-200 rounded w-1/4"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-3 bg-gray-200 rounded w-1/2"></div>
            <div className="flex justify-between pt-2">
              <div className="h-5 bg-gray-200 rounded w-1/4"></div>
              <div className="h-7 bg-gray-200 rounded-full w-1/4"></div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProductGrid;
