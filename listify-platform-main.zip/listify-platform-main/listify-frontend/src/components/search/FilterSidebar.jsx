import React from "react";

const FilterSidebar = ({
  filters,
  handleFilterChange,
  applyFilters,
  clearFilters,
}) => {
  return (
    <div className="hidden md:block w-64 shrink-0">
      <div className="bg-white p-4 rounded-lg shadow">
        <h2 className="font-medium text-lg mb-4">Filters</h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Price Range
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="number"
                name="minPrice"
                placeholder="Min"
                value={filters.minPrice}
                onChange={handleFilterChange}
                className="w-full p-2 border border-gray-300 rounded text-sm"
              />
              <span>-</span>
              <input
                type="number"
                name="maxPrice"
                placeholder="Max"
                value={filters.maxPrice}
                onChange={handleFilterChange}
                className="w-full p-2 border border-gray-300 rounded text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Category
            </label>
            <select
              name="category"
              value={filters.category}
              onChange={handleFilterChange}
              className="w-full p-2 border border-gray-300 rounded text-sm"
            >
              <option value="">All Categories</option>
              <option value="Electronics">Electronics</option>
              <option value="Fashion">Fashion</option>
              <option value="Home & Garden">Home & Garden</option>
              <option value="Sports">Sports</option>
              <option value="Books">Books</option>
              <option value="Toys">Toys</option>
              <option value="Health & Beauty">Health & Beauty</option>
              <option value="Automotive">Automotive</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Sort By
            </label>
            <select
              name="sortField"
              value={filters.sortField}
              onChange={handleFilterChange}
              className="w-full p-2 border border-gray-300 rounded text-sm"
            >
              <option value="price">Price</option>
              <option value="name">Name</option>
              <option value="rating">Rating</option>
              <option value="discount">Discount</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Sort Order
            </label>
            <select
              name="sortOrder"
              value={filters.sortOrder}
              onChange={handleFilterChange}
              className="w-full p-2 border border-gray-300 rounded text-sm"
            >
              <option value="asc">Ascending</option>
              <option value="desc">Descending</option>
            </select>
          </div>

          <div className="pt-4 space-y-2">
            <button
              onClick={applyFilters}
              className="w-full bg-cyan-500 text-white py-2 px-4 rounded hover:bg-cyan-600 transition-colors"
            >
              Apply Filters
            </button>
            <button
              onClick={clearFilters}
              className="w-full bg-gray-100 text-gray-800 py-2 px-4 rounded hover:bg-gray-200 transition-colors"
            >
              Clear Filters
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FilterSidebar;
