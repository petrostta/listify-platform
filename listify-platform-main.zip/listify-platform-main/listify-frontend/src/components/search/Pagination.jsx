import React from "react";

const Pagination = ({ pagination, handlePageChange }) => {
  if (pagination.totalPages <= 1) {
    return null;
  }

  return (
    <div className="flex justify-center mt-8">
      <nav className="flex items-center space-x-2">
        <button
          onClick={() => handlePageChange(pagination.page - 1)}
          disabled={pagination.page === 1}
          className={`px-3 py-1 rounded border ${
            pagination.page === 1
              ? "text-gray-400 border-gray-200"
              : "text-gray-700 border-gray-300 hover:bg-gray-50"
          }`}
        >
          Previous
        </button>

        {[...Array(pagination.totalPages)].map((_, i) => {
          const pageNum = i + 1;
          // Show limited page numbers with ellipsis
          if (
            pageNum === 1 ||
            pageNum === pagination.totalPages ||
            (pageNum >= pagination.page - 1 && pageNum <= pagination.page + 1)
          ) {
            return (
              <button
                key={pageNum}
                onClick={() => handlePageChange(pageNum)}
                className={`px-3 py-1 rounded ${
                  pagination.page === pageNum
                    ? "bg-cyan-500 text-white"
                    : "text-gray-700 hover:bg-gray-50 border border-gray-300"
                }`}
              >
                {pageNum}
              </button>
            );
          } else if (
            (pageNum === pagination.page - 2 && pagination.page > 3) ||
            (pageNum === pagination.page + 2 &&
              pagination.page < pagination.totalPages - 2)
          ) {
            return <span key={`ellipsis-${pageNum}`}>...</span>;
          }
          return null;
        })}

        <button
          onClick={() => handlePageChange(pagination.page + 1)}
          disabled={pagination.page === pagination.totalPages}
          className={`px-3 py-1 rounded border ${
            pagination.page === pagination.totalPages
              ? "text-gray-400 border-gray-200"
              : "text-gray-700 border-gray-300 hover:bg-gray-50"
          }`}
        >
          Next
        </button>
      </nav>
    </div>
  );
};

export default Pagination;
