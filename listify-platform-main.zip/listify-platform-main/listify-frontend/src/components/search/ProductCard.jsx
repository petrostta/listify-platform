import React, { useState } from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faStar,
  faHeart,
  faShoppingCart,
  faStarHalfAlt,
  faEye,
} from "@fortawesome/free-solid-svg-icons";

const ProductCard = ({ product, addToCart }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isImageLoaded, setIsImageLoaded] = useState(true);
  const [isAddingToCart, setIsAddingToCart] = useState(false);

  const finalPrice =
    product.discount > 0
      ? (product.original_price * (1 - product.discount / 100)).toFixed(2)
      : product.original_price?.toFixed(2);

  const getImageUrl = () => {
    if (!product.pictures || product.pictures.length === 0) {
      return "/placeholder-product.png";
    }

    const imagePath =
      product.pictures[0].key || product.pictures[0].url.split("/").pop();

    if (imagePath.includes("https://")) {
      return imagePath;
    }

    return `https://pub-e2dfc4f311fa40c0b98535194e9c7266.r2.dev/${imagePath}`;
  };

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsAddingToCart(true);
    addToCart(product.uuid);
    setTimeout(() => setIsAddingToCart(false), 500);
  };

  return (
    <div
      className="group relative bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 h-full flex flex-col"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {product.discount > 0 && (
        <div className="absolute top-3 left-3 z-10 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded-full">
          {product.discount}% OFF
        </div>
      )}

      <div className="absolute right-3 top-3 z-10 flex flex-col space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

      <Link to={`/product/${product.uuid}`} className="flex flex-col h-full">
        <div className="relative overflow-hidden bg-gray-50 aspect-square">
          <img
            src={getImageUrl()}
            alt={product.name}
            className={`w-full h-full object-contain transform transition-transform duration-500 ${
              isHovered ? "scale-105" : ""
            }`}
            onError={(e) => {
              if (isImageLoaded) {
                setIsImageLoaded(false);
                e.target.src = "/placeholder-product.png";
              }
            }}
          />
        </div>

        <div className="p-4 flex flex-col flex-grow">
          {product.category && (
            <div className="text-xs font-medium text-gray-500 mb-1 uppercase tracking-wider">
              {product.category}
            </div>
          )}

          <h3 className="font-medium text-gray-800 text-sm md:text-base mb-1 line-clamp-2 min-h-[2.75rem] group-hover:text-cyan-600 transition-colors">
            {product.name}
          </h3>

          <div className="flex items-center mb-2 mt-auto">
            <div className="flex">
              {[...Array(5)].map((_, i) => {
                if (i < Math.floor(product.rating || 0)) {
                  return (
                    <FontAwesomeIcon
                      key={`star-${product.uuid}-${i}`}
                      icon={faStar}
                      className="text-yellow-400"
                      size="xs"
                    />
                  );
                } else if (
                  i === Math.floor(product.rating || 0) &&
                  product.rating % 1 >= 0.3 &&
                  product.rating % 1 < 0.8
                ) {
                  return (
                    <FontAwesomeIcon
                      key={`star-${product.uuid}-${i}`}
                      icon={faStarHalfAlt}
                      className="text-yellow-400"
                      size="xs"
                    />
                  );
                } else {
                  return (
                    <FontAwesomeIcon
                      key={`star-${product.uuid}-${i}`}
                      icon={faStar}
                      className="text-gray-200"
                      size="xs"
                    />
                  );
                }
              })}
            </div>
            <span className="text-xs text-gray-500 ml-1">
              ({product.reviewCount || 0})
            </span>
          </div>

          <div className="flex items-center justify-between mt-1">
            <div>
              {product.discount > 0 ? (
                <div className="flex flex-col">
                  <span className="text-lg font-bold text-gray-900">
                    ${finalPrice}
                  </span>
                  <span className="text-xs text-gray-400 line-through">
                    ${product.original_price?.toFixed(2)}
                  </span>
                </div>
              ) : (
                <span className="text-lg font-bold text-gray-900">
                  ${finalPrice}
                </span>
              )}
            </div>

            <button
              onClick={handleAddToCart}
              className="md:hidden bg-cyan-500 text-white rounded-full p-2 shadow-sm hover:bg-cyan-600 transition-colors"
              aria-label="Add to cart"
            >
              <FontAwesomeIcon icon={faShoppingCart} size="sm" />
            </button>
          </div>
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;
