import React from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faShoppingBag, faTruck } from "@fortawesome/free-solid-svg-icons";

const OrderSummary = ({
  cart,
  shippingInfo,
  currentStep,
  processingPayment,
}) => {
  if (!cart || !cart.items) return null;

  // Calculate totals
  const subtotal = cart.subtotal || 0;
  const estimatedTax = subtotal * 0.1; // tax
  const shipping = subtotal > 100 ? 0 : 5.99; // if subtotal > $100, free shipping
  const total = subtotal + estimatedTax + shipping;

  return (
    <div className="bg-white rounded-lg shadow p-6 sticky top-20">
      <h2 className="text-xl font-semibold mb-4 flex items-center">
        <FontAwesomeIcon icon={faShoppingBag} className="mr-2 text-cyan-600" />
        Order Summary
      </h2>

      <div className="mb-4 space-y-3 max-h-60 overflow-y-auto">
        {cart.items.map((item) => (
          <div key={item._id} className="flex items-center border-b pb-3">
            <div className="w-10 h-10 bg-gray-100 rounded overflow-hidden mr-3">
              <img
                src={
                  item.product?.pictures?.[0]?.url || "/placeholder-product.png"
                }
                alt={item.product?.name || "Product"}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-800 line-clamp-1">
                {item.product?.name || "Product"}
              </p>
              <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
            </div>
            <div className="text-sm font-medium text-gray-900">
              ${(item.price * item.quantity).toFixed(2)}
            </div>
          </div>
        ))}
      </div>

      <div className="mb-4 border-b pb-4">
        <div className="flex justify-between mb-2">
          <span className="text-gray-600">Subtotal</span>
          <span className="text-gray-900">${subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between mb-2">
          <span className="text-gray-600">Estimated Tax</span>
          <span className="text-gray-900">${estimatedTax.toFixed(2)}</span>
        </div>
        <div className="flex justify-between mb-2">
          <span className="text-gray-600">Shipping</span>
          <span className="text-gray-900">
            {shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`}
          </span>
        </div>
      </div>

      {/* Total */}
      <div className="flex justify-between mb-6">
        <span className="text-lg font-bold text-gray-900">Total</span>
        <span className="text-lg font-bold text-gray-900">
          ${total.toFixed(2)}
        </span>
      </div>

      {shippingInfo && currentStep > 1 && (
        <div className="mb-6 pb-4 border-b">
          <h3 className="font-medium text-gray-900 mb-2 flex items-center">
            <FontAwesomeIcon icon={faTruck} className="mr-2 text-cyan-600" />
            Shipping To
          </h3>
          <p className="text-sm text-gray-600">
            {shippingInfo.fullName}
            <br />
            {shippingInfo.addressLine1}
            <br />
            {shippingInfo.city}, {shippingInfo.state} {shippingInfo.postalCode}
            <br />
            {shippingInfo.country}
          </p>
        </div>
      )}

      {currentStep < 3 && !processingPayment && (
        <Link
          to="/"
          className="block text-center text-sm text-cyan-600 hover:text-cyan-800"
          onClick={() => document.querySelector(".cart-icon")?.click()}
        >
          Edit cart
        </Link>
      )}
    </div>
  );
};

export default OrderSummary;
