import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheck } from "@fortawesome/free-solid-svg-icons";

const CheckoutSteps = ({ currentStep }) => {
  const steps = [
    { id: 1, name: "Shipping" },
    { id: 2, name: "Payment" },
    { id: 3, name: "Confirmation" }
  ];

  return (
    <div className="hidden sm:block">
      <div className="flex items-center">
        {steps.map((step, index) => (
          <React.Fragment key={step.id}>
            <div className="relative flex items-center justify-center">
              <div
                className={`h-10 w-10 rounded-full flex items-center justify-center ${
                  currentStep > step.id
                    ? "bg-cyan-600"
                    : currentStep === step.id
                    ? "bg-cyan-500"
                    : "bg-gray-300"
                } text-white`}
              >
                {currentStep > step.id ? (
                  <FontAwesomeIcon icon={faCheck} />
                ) : (
                  step.id
                )}
              </div>
              <div
                className={`absolute -bottom-6 whitespace-nowrap text-xs font-medium ${
                  currentStep >= step.id ? "text-cyan-600" : "text-gray-500"
                }`}
              >
                {step.name}
              </div>
            </div>

            {index < steps.length - 1 && (
              <div
                className={`h-0.5 w-full ${
                  currentStep > step.id + 1
                    ? "bg-cyan-600"
                    : currentStep > step.id
                    ? "bg-gradient-to-r from-cyan-600 to-gray-300"
                    : "bg-gray-300"
                }`}
              ></div>
            )}
          </React.Fragment>
        ))}
      </div>
      <div className="h-10"></div> 
    </div>
  );
};

export default CheckoutSteps;