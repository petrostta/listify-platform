import React, { useState, useEffect, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import LoginPopup from "./Loginpopup";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faClose } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";

const AddressPopup = ({ setShowAddress }) => {
  const { isAuthenticated, user, refreshUser } = useContext(AuthContext);
  const [showLoginPopup, setShowLoginPopup] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    street: "",
    city: "",
    country: "",
    zipCode: "",
    phone_number: "",
  });

  useEffect(() => {
    if (isAuthenticated && user) {
      setFormData({
        street: user.address?.street || "",
        city: user.address?.city || "",
        country: user.address?.country || "",
        zipCode: user.address?.zipCode || "",
        phone_number: user.phone_number || "",
      });
    }
  }, [isAuthenticated, user]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isAuthenticated) {
      setShowLoginPopup(true);
      return;
    }

    try {
      await axios.put(
        `http://localhost:8080/api/users/${user.uuid}`,
        {
          phone_number: formData.phone_number,
          address: {
            street: formData.street,
            city: formData.city,
            country: formData.country,
            zipCode: formData.zipCode,
          },
        },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      refreshUser();
      setIsEditing(false);
    } catch (error) {
      console.error("Error updating address:", error);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-800">
            {isEditing ? "Edit Address" : "Your Address"}
          </h2>
          <button
            onClick={() => setShowAddress(false)}
            className="text-gray-500 hover:text-gray-700"
          >
            <FontAwesomeIcon icon={faClose} className="text-2xl" />
          </button>
        </div>

        {showLoginPopup ? (
          <LoginPopup setShowLogin={setShowLoginPopup} />
        ) : !isAuthenticated ? (
          <div className="text-center py-6">
            <p className="text-gray-600 mb-4">
              You need to be logged in to manage your address.
            </p>
            <button
              onClick={() => setShowLoginPopup(true)}
              className="bg-cyan-500 text-white py-2 px-6 rounded-lg hover:bg-cyan-600"
            >
              Login
            </button>
          </div>
        ) : isEditing ? (
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number
                </label>
                <input
                  type="text"
                  name="phone_number"
                  value={formData.phone_number}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Street Address
                </label>
                <input
                  type="text"
                  name="street"
                  value={formData.street}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  City
                </label>
                <input
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Country
                </label>
                <input
                  type="text"
                  name="country"
                  value={formData.country}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Zip Code
                </label>
                <input
                  type="text"
                  name="zipCode"
                  value={formData.zipCode}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-cyan-500 text-white rounded-md hover:bg-cyan-600"
                >
                  Save
                </button>
              </div>
            </div>
          </form>
        ) : (
          <div>
            {user && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">
                    Phone Number
                  </h3>
                  <p className="mt-1">{user.phone_number || "Not provided"}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Address</h3>
                  {user.address &&
                  (user.address.street || user.address.city) ? (
                    <p className="mt-1">
                      {user.address.street || ""}
                      {user.address.street && <br />}
                      {user.address.city || ""}
                      {user.address.city && user.address.zipCode && ", "}
                      {user.address.zipCode || ""}
                      {(user.address.city || user.address.zipCode) && <br />}
                      {user.address.country || ""}
                    </p>
                  ) : (
                    <p className="mt-1 text-gray-500">No address provided</p>
                  )}
                </div>
                <div className="pt-4">
                  <button
                    onClick={() => setIsEditing(true)}
                    className="w-full px-4 py-2 bg-cyan-500 text-white rounded-md hover:bg-cyan-600"
                  >
                    Edit
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default AddressPopup;
