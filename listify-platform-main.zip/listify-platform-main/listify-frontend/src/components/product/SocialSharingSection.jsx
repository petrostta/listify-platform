import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faShareAlt } from "@fortawesome/free-solid-svg-icons";
import {
  faFacebook,
  faTwitter,
  faInstagram,
} from "@fortawesome/free-brands-svg-icons";

const SocialSharingSection = () => {
  return (
    <div className="mt-6 flex items-center">
      <span className="text-sm text-gray-500 mr-2">Share:</span>
      <div className="flex space-x-3">
        <button className="text-gray-400 hover:text-cyan-500 transition-colors">
          <FontAwesomeIcon icon={faShareAlt} />
        </button>
        <button className="text-gray-400 hover:text-blue-600 transition-colors">
          <FontAwesomeIcon icon={faFacebook} />
        </button>
        <button className="text-gray-400 hover:text-blue-400 transition-colors">
          <FontAwesomeIcon icon={faTwitter} />
        </button>
        <button className="text-gray-400 hover:text-pink-600 transition-colors">
          <FontAwesomeIcon icon={faInstagram} />
        </button>
      </div>
    </div>
  );
};

export default SocialSharingSection;
