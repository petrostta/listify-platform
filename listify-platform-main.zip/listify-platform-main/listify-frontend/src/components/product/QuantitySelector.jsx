import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus, faMinus } from "@fortawesome/free-solid-svg-icons";

const QuantitySelector = ({
  quantity,
  stock,
  onIncrement,
  onDecrement,
  onChange,
}) => {
  return (
    <div className="mt-6">
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Quantity
      </label>
      <div className="flex items-center">
        <button
          onClick={onDecrement}
          className={`h-10 w-10 border border-gray-300 flex items-center justify-center rounded-l ${
            quantity <= 1 ? "bg-gray-100 text-gray-400" : "hover:bg-gray-100"
          }`}
          disabled={quantity <= 1}
        >
          <FontAwesomeIcon icon={faMinus} />
        </button>
        <input
          type="number"
          value={quantity}
          onChange={onChange}
          min="1"
          max={stock}
          className="h-10 w-20 border-t border-b border-gray-300 text-center"
        />
        <button
          onClick={onIncrement}
          className={`h-10 w-10 border border-gray-300 flex items-center justify-center rounded-r ${
            quantity >= stock
              ? "bg-gray-100 text-gray-400"
              : "hover:bg-gray-100"
          }`}
          disabled={quantity >= stock}
        >
          <FontAwesomeIcon icon={faPlus} />
        </button>
      </div>
    </div>
  );
};

export default QuantitySelector;
