import { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faStar as solidStar,
  faStarHalfAlt,
} from "@fortawesome/free-solid-svg-icons";
import { faStar as regularStar } from "@fortawesome/free-regular-svg-icons";
import ProductReviewsTab from "./ProductReviewsTab";
import axios from "axios";

const ProductTabs = ({ product, selectedVariant, onUpdateReviewStats }) => {
  const [activeTab, setActiveTab] = useState("description");
  const [reviewCount, setReviewCount] = useState(0);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    if (product?.uuid) {
      fetchReviewCount();
    }
  }, [product?.uuid, refreshKey]); 

  const fetchReviewCount = async () => {
    try {
      const response = await axios.get(
        `http://localhost:8080/api/reviews/product/${
          product.uuid
        }/count-simple?t=${Date.now()}`
      );

      if (response.data) {
        setReviewCount(response.data.count || 0);

        if (onUpdateReviewStats) {
          onUpdateReviewStats({
            averageRating: response.data.averageRating || 0,
            totalReviews: response.data.count || 0,
          });
        }
      }
    } catch (error) {
      console.error("Error fetching review count:", error);
      setReviewCount(0);
    }
  };

  const handleReviewStatsUpdate = () => {
    setRefreshKey((prev) => prev + 1);
  };

  const tabs = [
    { id: "description", label: "Description" },
    { id: "specifications", label: "Specifications" },
    { id: "reviews", label: `Reviews(${reviewCount})` },
  ];

  // Showing the variant description if it exists if not it shows the normal description
  const displayDescription = () => {
    if (selectedVariant && selectedVariant.description) {
      return selectedVariant.description;
    }
    return product.description;
  };

  const getSpecifications = () => {
    const specs = [];

    //  product attributes
    if (product.attributes && Array.isArray(product.attributes)) {
      product.attributes.forEach((attr) => {
        specs.push({ key: attr.key, value: attr.value });
      });
    }

    // variant-specific attributes if a variant is selected
    if (selectedVariant && selectedVariant.attributes) {
      selectedVariant.attributes.forEach((attr) => {
        // Check if this key already exists and update it
        const existingIndex = specs.findIndex((spec) => spec.key === attr.key);
        if (existingIndex >= 0) {
          specs[existingIndex].value = attr.value;
        } else {
          specs.push({ key: attr.key, value: attr.value });
        }
      });
    }

    return specs;
  };

  return (
    <div className="mt-8">
      <div className="border-b border-gray-200">
        <nav className="flex -mb-px">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-4 px-6 font-medium text-sm border-b-2 ${
                activeTab === tab.id
                  ? "border-cyan-500 text-cyan-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      <div className="py-4">
        {activeTab === "description" && (
          <div className="prose max-w-none">
            <p>{displayDescription()}</p>
          </div>
        )}

        {activeTab === "specifications" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {getSpecifications().map((spec, index) => (
              <div key={index} className="flex border-b pb-2">
                <div className="w-1/2 font-medium text-gray-600">
                  {spec.key}
                </div>
                <div className="w-1/2 text-gray-900">{spec.value}</div>
              </div>
            ))}
          </div>
        )}

        {activeTab === "reviews" && (
          <ProductReviewsTab
            product={product}
            isActive={activeTab === "reviews"}
            onReviewStatsUpdate={handleReviewStatsUpdate}
          />
        )}
      </div>
    </div>
  );
};

export default ProductTabs;
