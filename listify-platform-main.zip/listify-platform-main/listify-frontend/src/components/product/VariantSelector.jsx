import React, { useState, useEffect } from "react";

const VariantSelector = ({
  product,
  variants,
  selectedVariant,
  onVariantChange,
}) => {
  const [attributeGroups, setAttributeGroups] = useState({});
  const [selectedAttributes, setSelectedAttributes] = useState({});

  useEffect(() => {
    if (!variants || variants.length === 0 || !product.variantAttributes) {
      return;
    }

    const attributeMap = {};
    product.variantAttributes.forEach((attrKey) => {
      attributeMap[attrKey] = new Set();
    });

    variants.forEach((variant) => {
      if (variant.attributes) {
        variant.attributes.forEach((attr) => {
          if (attributeMap[attr.key]) {
            attributeMap[attr.key].add(attr.value);
          }
        });
      }
    });

    const formattedGroups = {};
    Object.keys(attributeMap).forEach((key) => {
      formattedGroups[key] = Array.from(attributeMap[key]);
    });

    setAttributeGroups(formattedGroups);

    if (selectedVariant && selectedVariant.attributes) {
      const initialSelection = {};
      selectedVariant.attributes.forEach((attr) => {
        initialSelection[attr.key] = attr.value;
      });
      setSelectedAttributes(initialSelection);
    }
  }, [variants, selectedVariant, product]);

  useEffect(() => {
    if (Object.keys(selectedAttributes).length === 0) {
      return;
    }

    const matchingVariant = variants.find((variant) => {
      if (!variant.attributes) return false;

      return Object.entries(selectedAttributes).every(([key, value]) => {
        const attribute = variant.attributes.find((attr) => attr.key === key);
        return attribute && attribute.value === value;
      });
    });

    if (matchingVariant && matchingVariant !== selectedVariant) {
      onVariantChange(matchingVariant);
    }
  }, [selectedAttributes, variants, onVariantChange, selectedVariant]);

  const handleSelectAttribute = (key, value) => {
    const newSelection = { ...selectedAttributes, [key]: value };
    setSelectedAttributes(newSelection);

    const exactMatch = variants.find((variant) => {
      if (!variant.attributes) return false;

      return Object.entries(newSelection).every(([k, v]) => {
        const attribute = variant.attributes.find((attr) => attr.key === k);
        return attribute && attribute.value === v;
      });
    });

    if (exactMatch) {
      onVariantChange(exactMatch);
      return;
    }

    const bestMatch = variants.find((variant) => {
      if (!variant.attributes) return false;
      return variant.attributes.some(
        (attr) => attr.key === key && attr.value === value
      );
    });

    if (bestMatch) {
      onVariantChange(bestMatch);
    } else {
      onVariantChange(null);
    }
  };

  const isAttributeAvailable = (key, value) => {
    return variants.some(
      (variant) =>
        variant.attributes &&
        variant.attributes.some(
          (attr) => attr.key === key && attr.value === value
        )
    );
  };

  const isVariantInStock = (key, value) => {
    const matchingVariants = variants.filter(
      (variant) =>
        variant.attributes &&
        variant.attributes.some(
          (attr) => attr.key === key && attr.value === value
        )
    );

    return matchingVariants.some((variant) => variant.stock > 0);
  };

  const renderAttributeSelector = (key, values) => {
    const displayKey = key.charAt(0).toUpperCase() + key.slice(1);

    if (key.toLowerCase() === "color") {
      return (
        <div key={key} className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {displayKey}:{" "}
            <span className="text-cyan-600 font-semibold">
              {selectedAttributes[key]}
            </span>
          </label>
          <div className="flex flex-wrap gap-2">
            {values.map((value) => {
              const isSelected = selectedAttributes[key] === value;
              const isAvailable = isAttributeAvailable(key, value);
              const inStock = isVariantInStock(key, value);

              return (
                <button
                  key={value}
                  onClick={() =>
                    isAvailable && inStock && handleSelectAttribute(key, value)
                  }
                  disabled={!isAvailable || !inStock}
                  className={`
                    w-10 h-10 rounded-full border-2 relative
                    ${isSelected ? "ring-2 ring-offset-2 ring-cyan-500" : ""}
                    ${
                      !isAvailable || !inStock
                        ? "opacity-40 cursor-not-allowed"
                        : "cursor-pointer hover:scale-110 transition-transform"
                    }
                  `}
                  style={{
                    backgroundColor: value.toLowerCase(),
                    borderColor:
                      value.toLowerCase() === "white"
                        ? "#e5e7eb"
                        : value.toLowerCase(),
                  }}
                  title={`${value}${
                    !isAvailable
                      ? " (Not available)"
                      : !inStock
                      ? " (Out of Stock)"
                      : ""
                  }`}
                >
                  {isSelected && (
                    <span className="absolute inset-0 flex items-center justify-center">
                      <svg
                        width="14"
                        height="14"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M5 12L10 17L20 7"
                          stroke={
                            value.toLowerCase() === "white" ? "black" : "white"
                          }
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      );
    }

    if (key.toLowerCase() === "size") {
      return (
        <div key={key} className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {displayKey}:{" "}
            <span className="text-cyan-600 font-semibold">
              {selectedAttributes[key]}
            </span>
          </label>
          <div className="flex flex-wrap gap-2">
            {values.map((value) => {
              const isSelected = selectedAttributes[key] === value;
              const isAvailable = isAttributeAvailable(key, value);
              const inStock = isVariantInStock(key, value);

              return (
                <button
                  key={value}
                  onClick={() =>
                    isAvailable && inStock && handleSelectAttribute(key, value)
                  }
                  disabled={!isAvailable || !inStock}
                  className={`
                    min-w-[3rem] h-10 px-3 border rounded text-center font-medium text-sm
                    ${
                      isSelected
                        ? "border-cyan-500 bg-cyan-50 text-cyan-700"
                        : "border-gray-300 text-gray-700"
                    }
                    ${
                      !isAvailable || !inStock
                        ? "opacity-40 cursor-not-allowed"
                        : "cursor-pointer hover:bg-gray-50"
                    }
                  `}
                  title={`${value}${
                    !isAvailable
                      ? " (Not available)"
                      : !inStock
                      ? " (Out of Stock)"
                      : ""
                  }`}
                >
                  {value}
                </button>
              );
            })}
          </div>
        </div>
      );
    }

    return (
      <div key={key} className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          {displayKey}:{" "}
          <span className="text-cyan-600 font-semibold">
            {selectedAttributes[key]}
          </span>
        </label>
        <div className="flex flex-wrap gap-2">
          {values.map((value) => {
            const isSelected = selectedAttributes[key] === value;
            const isAvailable = isAttributeAvailable(key, value);
            const inStock = isVariantInStock(key, value);

            return (
              <button
                key={value}
                onClick={() =>
                  isAvailable && inStock && handleSelectAttribute(key, value)
                }
                disabled={!isAvailable || !inStock}
                className={`
                  px-4 py-2 border rounded-md text-sm
                  ${
                    isSelected
                      ? "border-cyan-500 bg-cyan-50 text-cyan-700"
                      : "border-gray-300 text-gray-700"
                  }
                  ${
                    !isAvailable || !inStock
                      ? "opacity-40 cursor-not-allowed"
                      : "cursor-pointer hover:bg-gray-50"
                  }
                `}
                title={`${value}${
                  !isAvailable
                    ? " (Not available)"
                    : !inStock
                    ? " (Out of Stock)"
                    : ""
                }`}
              >
                {value}
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  if (!product.variantAttributes || !variants || variants.length === 0) {
    return null;
  }

  return (
    <div>
      {Object.entries(attributeGroups).map(([key, values]) =>
        renderAttributeSelector(key, values)
      )}
    </div>
  );
};

export default VariantSelector;
