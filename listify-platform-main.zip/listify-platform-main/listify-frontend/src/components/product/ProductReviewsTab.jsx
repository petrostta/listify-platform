import { useState, useEffect, useContext, useRef } from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar as solidStar } from "@fortawesome/free-solid-svg-icons";
import { faStar as regularStar } from "@fortawesome/free-regular-svg-icons";
import { faThumbsUp, faStarHalfAlt } from "@fortawesome/free-solid-svg-icons";
import { AuthContext } from "../../context/AuthContext";
import WriteReviewForm from "./WriteReviewForm";
import axios from "axios";

const ProductReviewsTab = ({ product, isActive }) => {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [eligibleProducts, setEligibleProducts] = useState([]);
  const [reviewStats, setReviewStats] = useState({
    averageRating: 0,
    totalReviews: 0,
  });
  const [pagination, setPagination] = useState({
    page: 1,
    totalPages: 1,
    limit: 10,
  });
  const { isAuthenticated, user } = useContext(AuthContext);
  const [reviewsLoading, setReviewsLoading] = useState(false);
  const [eligibilityLoading, setEligibilityLoading] = useState(false);

  const dataFetched = useRef(false);
  const controller = useRef(null);

  useEffect(() => {
    if (product?.uuid && !dataFetched.current) {
      const cachedData = sessionStorage.getItem(
        `product_reviews:${product.uuid}:${pagination.page}`
      );
      const cachedTimestamp = sessionStorage.getItem(
        `product_reviews:${product.uuid}:${pagination.page}:timestamp`
      );

      if (cachedData && cachedTimestamp) {
        const now = Date.now();
        if (now - parseInt(cachedTimestamp) < 5 * 60 * 1000) {
          try {
            const parsedData = JSON.parse(cachedData);
            setReviews(parsedData.reviews || []);
            setReviewStats({
              averageRating: parsedData.stats?.averageRating || 0,
              totalReviews: parsedData.stats?.totalReviews || 0,
            });
            setPagination({
              ...pagination,
              totalPages: parsedData.pagination?.totalPages || 1,
            });
            dataFetched.current = true;
            return;
          } catch (e) {
            console.error("Error parsing cached review data:", e);
          }
        }
      }

      if (!isActive) {
        prefetchReviews();
      }
    }
  }, [product?.uuid]);

  useEffect(() => {
    if (isActive && product?.uuid) {
      if (controller.current) {
        controller.current.abort();
      }

      fetchProductReviews();

      if (isAuthenticated) {
        fetchEligibleProducts();
      }
    }

    return () => {
      if (controller.current) {
        controller.current.abort();
      }
    };
  }, [isActive, product?.uuid, isAuthenticated, pagination.page]);

  const prefetchReviews = async () => {
    if (!product?.uuid) return;

    try {
      const response = await axios.get(
        `http://localhost:8080/api/reviews/product/${product.uuid}?page=${pagination.page}&limit=${pagination.limit}`
      );

      if (response.data) {
        sessionStorage.setItem(
          `product_reviews:${product.uuid}:${pagination.page}`,
          JSON.stringify(response.data)
        );
        sessionStorage.setItem(
          `product_reviews:${product.uuid}:${pagination.page}:timestamp`,
          Date.now().toString()
        );
      }
    } catch (error) {
      console.error("Error prefetching reviews:", error);
    }
  };

  const fetchProductReviews = async () => {
    if (!product?.uuid || reviewsLoading) return;

    controller.current = new AbortController();

    try {
      setReviewsLoading(true);
      setLoading(true);

      const cachedData = sessionStorage.getItem(
        `product_reviews:${product.uuid}:${pagination.page}`
      );
      if (cachedData) {
        try {
          const parsedData = JSON.parse(cachedData);
          setReviews(parsedData.reviews || []);
          setReviewStats({
            averageRating: parsedData.stats?.averageRating || 0,
            totalReviews: parsedData.stats?.totalReviews || 0,
          });
          setPagination({
            ...pagination,
            totalPages: parsedData.pagination?.totalPages || 1,
          });

          fetchAndUpdateCache();
          return;
        } catch (e) {
          console.error("Error parsing cached review data:", e);
        }
      }

      const response = await axios.get(
        `http://localhost:8080/api/reviews/product/${product.uuid}?page=${pagination.page}&limit=${pagination.limit}`,
        { signal: controller.current.signal }
      );

      if (response.data) {
        setReviews(response.data.reviews || []);
        setReviewStats({
          averageRating: response.data.stats?.averageRating || 0,
          totalReviews: response.data.stats?.totalReviews || 0,
        });
        setPagination({
          ...pagination,
          totalPages: response.data.pagination?.totalPages || 1,
        });

        sessionStorage.setItem(
          `product_reviews:${product.uuid}:${pagination.page}`,
          JSON.stringify(response.data)
        );
        sessionStorage.setItem(
          `product_reviews:${product.uuid}:${pagination.page}:timestamp`,
          Date.now().toString()
        );
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        console.error("Error fetching product reviews:", error);
      }
    } finally {
      setReviewsLoading(false);
      setLoading(false);
    }
  };

  const fetchAndUpdateCache = async () => {
    if (!product?.uuid) return;

    try {
      const response = await axios.get(
        `http://localhost:8080/api/reviews/product/${product.uuid}?page=${pagination.page}&limit=${pagination.limit}`
      );

      if (response.data) {
        sessionStorage.setItem(
          `product_reviews:${product.uuid}:${pagination.page}`,
          JSON.stringify(response.data)
        );
        sessionStorage.setItem(
          `product_reviews:${product.uuid}:${pagination.page}:timestamp`,
          Date.now().toString()
        );
      }
    } catch (error) {
      console.error("Error updating reviews cache:", error);
    }
  };

  const fetchEligibleProducts = async () => {
    if (!user?.uuid || eligibilityLoading) return;

    try {
      setEligibilityLoading(true);

      const cachedEligibility = localStorage.getItem(
        `eligibility:${user.uuid}`
      );
      const cachedTimestamp = localStorage.getItem(
        `eligibility:${user.uuid}:timestamp`
      );

      if (cachedEligibility && cachedTimestamp) {
        const now = Date.now();
        if (now - parseInt(cachedTimestamp) < 10 * 60 * 1000) {
          try {
            setEligibleProducts(JSON.parse(cachedEligibility));
            return;
          } catch (e) {
            console.error("Error parsing cached eligibility:", e);
          }
        }
      }

      const response = await axios.get(
        `http://localhost:8080/api/reviews/eligibility`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      if (response.data?.eligibleProducts) {
        const eligible = response.data.eligibleProducts || [];
        setEligibleProducts(eligible);

        localStorage.setItem(
          `eligibility:${user.uuid}`,
          JSON.stringify(eligible)
        );
        localStorage.setItem(
          `eligibility:${user.uuid}:timestamp`,
          Date.now().toString()
        );
      }
    } catch (error) {
      console.error("Error fetching eligible products:", error);
    } finally {
      setEligibilityLoading(false);
    }
  };

  const isEligibleToReview = () => {
    if (!isAuthenticated || !eligibleProducts.length) return false;
    return eligibleProducts.some((item) => item.productId === product.uuid);
  };

  const getEligibleOrderId = () => {
    if (!isEligibleToReview()) return null;
    const eligibleProduct = eligibleProducts.find(
      (item) => item.productId === product.uuid
    );
    return eligibleProduct ? eligibleProduct.orderId : null;
  };

  const handleWriteReview = () => {
    setShowReviewForm(true);
  };

  const handleReviewSubmitted = () => {
    setShowReviewForm(false);

    sessionStorage.removeItem(
      `product_reviews:${product.uuid}:${pagination.page}`
    );
    sessionStorage.removeItem(
      `product_reviews:${product.uuid}:${pagination.page}:timestamp`
    );
    localStorage.removeItem(`eligibility:${user?.uuid}`);

    const keys = Object.keys(sessionStorage);
    keys.forEach((key) => {
      if (key.includes(`product_reviews:${product.uuid}`)) {
        sessionStorage.removeItem(key);
      }
    });

    fetchProductReviews();
    fetchEligibleProducts();

    if (onReviewStatsUpdate) {
      onReviewStatsUpdate();
    }
  };

  const renderStarRating = (rating) => {
    return (
      <div className="flex">
        {[...Array(5)].map((_, i) => {
          if (i < Math.floor(rating)) {
            return (
              <FontAwesomeIcon
                key={i}
                icon={solidStar}
                className="text-yellow-400"
              />
            );
          } else if (
            i === Math.floor(rating) &&
            rating % 1 >= 0.3 &&
            rating % 1 < 0.8
          ) {
            return (
              <FontAwesomeIcon
                key={i}
                icon={faStarHalfAlt}
                className="text-yellow-400"
              />
            );
          } else {
            return (
              <FontAwesomeIcon
                key={i}
                icon={regularStar}
                className="text-gray-300"
              />
            );
          }
        })}
      </div>
    );
  };

  const handlePageChange = (newPage) => {
    if (newPage > 0 && newPage <= pagination.totalPages) {
      setPagination({
        ...pagination,
        page: newPage,
      });
    }
  };

  if (!isActive) return null;

  return (
    <div className="mt-4">
      <div className="bg-gray-50 p-4 rounded-lg mb-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center">
              <span className="text-2xl font-bold text-gray-900 mr-2">
                {reviewStats.averageRating.toFixed(1)}
              </span>
              <div className="flex">
                {renderStarRating(reviewStats.averageRating)}
              </div>
            </div>
            <p className="text-sm text-gray-600 mt-1">
              Based on {reviewStats.totalReviews} reviews
            </p>
          </div>

          {isAuthenticated && (
            <div className="flex space-x-2">
              {isEligibleToReview() && (
                <button
                  onClick={handleWriteReview}
                  className="px-4 py-2 bg-cyan-500 text-white rounded-md hover:bg-cyan-600"
                >
                  Write Review
                </button>
              )}
              <Link
                to="/account?tab=reviews"
                className="px-4 py-2 border border-cyan-500 text-cyan-500 rounded-md hover:bg-cyan-50"
              >
                Manage Reviews
              </Link>
            </div>
          )}
        </div>
      </div>

      {showReviewForm && (
        <WriteReviewForm
          productId={product.uuid}
          orderId={getEligibleOrderId()}
          onSubmitted={handleReviewSubmitted}
          onCancel={() => setShowReviewForm(false)}
        />
      )}

      <div className="space-y-6">
        {loading ? (
          <div className="space-y-6">
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="border-b pb-6 animate-pulse">
                <div className="flex justify-between">
                  <div>
                    <div className="flex items-center">
                      <div className="h-4 w-24 bg-gray-200 rounded"></div>
                      <span className="mx-2 text-gray-400">•</span>
                      <div className="h-4 w-20 bg-gray-200 rounded"></div>
                    </div>
                    <div className="flex mt-1">
                      <div className="h-4 w-20 bg-gray-200 rounded mt-2"></div>
                    </div>
                  </div>
                </div>
                <div className="h-4 w-full bg-gray-200 rounded mt-3"></div>
                <div className="h-4 w-3/4 bg-gray-200 rounded mt-2"></div>
              </div>
            ))}
          </div>
        ) : reviews.length === 0 ? (
          <div className="text-center py-8 bg-gray-50 rounded-lg">
            <p className="text-gray-600">No reviews yet for this product.</p>
            {isAuthenticated && isEligibleToReview() && (
              <button
                onClick={handleWriteReview}
                className="mt-4 px-4 py-2 bg-cyan-500 text-white rounded-md hover:bg-cyan-600"
              >
                Be the first to write a review
              </button>
            )}
          </div>
        ) : (
          <>
            {reviews.map((review) => (
              <div key={review.uuid} className="border-b pb-6">
                <div className="flex justify-between">
                  <div>
                    <div className="flex items-center">
                      <span className="font-medium text-gray-900">
                        {review.userDisplayName || "Anonymous"}
                      </span>
                      <span className="mx-2 text-gray-400">•</span>
                      <span className="text-sm text-gray-500">
                        {new Date(review.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex mt-1">
                      {renderStarRating(review.rating)}
                    </div>
                  </div>
                  <button className="text-gray-500 hover:text-cyan-500 flex items-center">
                    <FontAwesomeIcon icon={faThumbsUp} className="mr-1" />
                    <span>{review.helpfulCount || 0}</span>
                  </button>
                </div>
                <p className="mt-3 text-gray-800">{review.reviewDescription}</p>
              </div>
            ))}

            {pagination.totalPages > 1 && (
              <div className="flex justify-center pt-6">
                <nav className="flex items-center">
                  <button
                    onClick={() => handlePageChange(pagination.page - 1)}
                    disabled={pagination.page === 1}
                    className="px-3 py-1 rounded-md border mr-2 disabled:opacity-50"
                  >
                    Previous
                  </button>

                  <div className="flex space-x-1">
                    {Array.from(
                      { length: Math.min(pagination.totalPages, 5) },
                      (_, i) => {
                        let pageToShow;
                        if (pagination.totalPages <= 5) {
                          pageToShow = i + 1;
                        } else if (i === 0) {
                          pageToShow = 1;
                        } else if (i === 4) {
                          pageToShow = pagination.totalPages;
                        } else {
                          const middleStart = Math.max(2, pagination.page - 1);
                          const middleEnd = Math.min(
                            pagination.totalPages - 1,
                            middleStart + 2
                          );
                          pageToShow = middleStart + (i - 1);

                          if (i === 1 && middleStart > 2) {
                            return (
                              <span key="ellipsis1" className="px-3 py-1">
                                ...
                              </span>
                            );
                          }

                          if (
                            i === 3 &&
                            middleEnd < pagination.totalPages - 1
                          ) {
                            return (
                              <span key="ellipsis2" className="px-3 py-1">
                                ...
                              </span>
                            );
                          }
                        }

                        return (
                          <button
                            key={pageToShow}
                            onClick={() => handlePageChange(pageToShow)}
                            className={`px-3 py-1 rounded-md ${
                              pagination.page === pageToShow
                                ? "bg-cyan-500 text-white"
                                : "border"
                            }`}
                          >
                            {pageToShow}
                          </button>
                        );
                      }
                    )}
                  </div>

                  <button
                    onClick={() => handlePageChange(pagination.page + 1)}
                    disabled={pagination.page === pagination.totalPages}
                    className="px-3 py-1 rounded-md border ml-2 disabled:opacity-50"
                  >
                    Next
                  </button>
                </nav>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default ProductReviewsTab;
