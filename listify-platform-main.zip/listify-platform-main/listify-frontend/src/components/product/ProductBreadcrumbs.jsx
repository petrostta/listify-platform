import React from "react";
import { Link } from "react-router-dom";

const ProductBreadcrumbs = ({ product }) => {
  return (
    <nav className="flex mb-6 text-sm">
      <Link to="/" className="text-gray-500 hover:text-gray-700">
        Home
      </Link>
      <span className="mx-2 text-gray-400">/</span>
      <Link
        to={`/search?category=${product.category}`}
        className="text-gray-500 hover:text-gray-700"
      >
        {product.category}
      </Link>
      <span className="mx-2 text-gray-400">/</span>
      <span className="text-gray-900">{product.name}</span>
    </nav>
  );
};

export default ProductBreadcrumbs;
