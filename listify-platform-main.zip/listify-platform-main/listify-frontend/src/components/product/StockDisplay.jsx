import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCheck,
  faTimes,
  faExclamationTriangle,
} from "@fortawesome/free-solid-svg-icons";

const StockDisplay = ({ stock }) => {
  return (
    <div className="mt-4">
      <div
        className={`px-3 py-1.5 rounded-full inline-flex items-center ${
          stock > 0
            ? stock <= 5
              ? "bg-amber-100 text-amber-700"
              : "bg-green-100 text-green-700"
            : "bg-red-100 text-red-700"
        }`}
      >
        <FontAwesomeIcon
          icon={
            stock > 0 ? (stock <= 5 ? faExclamationTriangle : faCheck) : faTimes
          }
          className="mr-2"
        />
        <span className="font-medium">
          {stock > 0
            ? stock <= 5
              ? `Low Stock - Only ${stock} left`
              : `In Stock - ${stock} available`
            : "Out of Stock"}
        </span>
      </div>
    </div>
  );
};

export default StockDisplay;
