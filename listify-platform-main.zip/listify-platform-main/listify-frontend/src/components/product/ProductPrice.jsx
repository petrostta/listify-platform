import React from "react";

const ProductPrice = ({ finalPrice, originalPrice, discount }) => {
  return (
    <div className="mt-4 flex items-center">
      <span className="text-2xl font-bold text-gray-900">
        ${finalPrice.toFixed(2)}
      </span>
      {discount > 0 && (
        <>
          <span className="ml-2 text-lg text-gray-500 line-through">
            ${originalPrice.toFixed(2)}
          </span>
          <span className="ml-2 px-2 py-1 bg-red-100 text-red-700 text-sm rounded-full">
            {discount}% OFF
          </span>
        </>
      )}
    </div>
  );
};

export default ProductPrice;
