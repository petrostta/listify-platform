import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar, faShoppingCart } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";

const RelatedProducts = ({ products }) => {
  const [productsWithReviews, setProductsWithReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (products && products.length > 0) {
      fetchReviewDataForProducts();
    }
  }, [products]);

  const fetchReviewDataForProducts = async () => {
    try {
      setLoading(true);

      const reviewPromises = products.map(async (product) => {
        try {
          const response = await axios.get(
            `http://localhost:8080/api/reviews/product/${product.uuid}/count-simple`,
            { timeout: 2000 }
          );

          return {
            ...product,
            rating: response.data?.averageRating || 0,
            reviewCount: response.data?.count || 0,
          };
        } catch (error) {
          console.error(
            `Error fetching reviews for product ${product.uuid}:`,
            error
          );
          return {
            ...product,
            rating: product.rating || 0,
            reviewCount: product.reviewCount || 0,
          };
        }
      });

      const updatedProducts = await Promise.all(reviewPromises);
      setProductsWithReviews(updatedProducts);
    } catch (error) {
      console.error("Error fetching review data for related products:", error);
      setProductsWithReviews(
        products.map((product) => ({
          ...product,
          rating: product.rating || 0,
          reviewCount: product.reviewCount || 0,
        }))
      );
    } finally {
      setLoading(false);
    }
  };

  const getImageUrl = (product) => {
    if (!product.pictures || product.pictures.length === 0) {
      return "/placeholder-product.png";
    }

    const imagePath =
      product.pictures[0].key || product.pictures[0].url.split("/").pop();

    if (imagePath.includes("https://")) {
      return imagePath;
    }

    return `https://pub-e2dfc4f311fa40c0b98535194e9c7266.r2.dev/${imagePath}`;
  };

  const calculatePrice = (basePrice, discount) => {
    if (!discount) return basePrice?.toFixed(2);
    return (basePrice * (1 - discount / 100)).toFixed(2);
  };

  if (!products || products.length === 0) {
    return null;
  }

  const displayProducts = loading ? products : productsWithReviews;

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Related Products
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {displayProducts.map((product) => (
          <Link
            key={product.uuid}
            to={`/product/${product.uuid}`}
            className="group block bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-gray-100"
          >
            <div className="relative aspect-square overflow-hidden bg-gray-100">
              <img
                src={getImageUrl(product)}
                alt={product.name}
                className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
              />

              {product.discount > 0 && (
                <div className="absolute top-2 left-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded-full">
                  {product.discount}% OFF
                </div>
              )}
            </div>

            <div className="p-4">
              {product.category && (
                <p className="text-xs text-gray-500 mb-1 uppercase tracking-wider">
                  {product.category}
                </p>
              )}

              <h3 className="text-sm font-medium text-gray-900 mb-1 line-clamp-2 group-hover:text-cyan-600 transition-colors">
                {product.name}
              </h3>

              <div className="flex items-center mb-2">
                {loading ? (
                  <div className="flex space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <div
                        key={i}
                        className="w-3 h-3 bg-gray-200 rounded animate-pulse"
                      ></div>
                    ))}
                  </div>
                ) : (
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <FontAwesomeIcon
                        key={i}
                        icon={faStar}
                        className={
                          i < Math.round(product.rating || 0)
                            ? "text-yellow-400"
                            : "text-gray-200"
                        }
                        size="xs"
                      />
                    ))}
                  </div>
                )}
                <span className="text-xs text-gray-500 ml-1">
                  {loading ? "..." : `(${product.reviewCount || 0})`}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  {product.discount > 0 ? (
                    <>
                      <span className="font-bold text-gray-900">
                        $
                        {calculatePrice(
                          product.original_price,
                          product.discount
                        )}
                      </span>
                      <span className="text-xs text-gray-500 line-through ml-2">
                        ${product.original_price?.toFixed(2)}
                      </span>
                    </>
                  ) : (
                    <span className="font-bold text-gray-900">
                      ${product.original_price?.toFixed(2)}
                    </span>
                  )}
                </div>

                <button
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log("Quick add to cart:", product.uuid);
                  }}
                  className="h-8 w-8 flex items-center justify-center bg-gray-100 rounded-full hover:bg-cyan-500 hover:text-white transition-colors"
                  aria-label="Add to cart"
                >
                  <FontAwesomeIcon icon={faShoppingCart} size="xs" />
                </button>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default RelatedProducts;
