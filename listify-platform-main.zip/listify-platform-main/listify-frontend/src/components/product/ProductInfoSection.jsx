import React, { useState, useEffect } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faStar as solidStar,
  faStarHalfAlt,
} from "@fortawesome/free-solid-svg-icons";
import { faStar as regularStar } from "@fortawesome/free-regular-svg-icons";
import VariantSelector from "./VariantSelector";
import ProductPrice from "./ProductPrice";
import StockDisplay from "./StockDisplay";
import QuantitySelector from "./QuantitySelector";
import ProductActions from "./ProductActions";
import DeliveryInfoSection from "./DeliveryInfoSection";
import SocialSharingSection from "./SocialSharingSection";

const ProductInfoSection = ({
  product,
  selectedVariant,
  onVariantChange,
  reviewStats: propReviewStats,
  addToCart,
  isAuthenticated,
  reviewStatsKey = 0,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [addingToCart, setAddingToCart] = useState(false);
  const [productAdded, setProductAdded] = useState(false);

  const [reviewStats, setReviewStats] = useState({
    averageRating: 0,
    totalReviews: 0,
  });

  useEffect(() => {
    if (product?.uuid) {
      const fetchReviewStats = async () => {
        try {
          const response = await axios.get(
            `http://localhost:8080/api/reviews/product/${
              product.uuid
            }/count-simple?t=${Date.now()}`,
            { timeout: 3000 }
          );

          if (response.data) {
            const apiReviewStats = response.data;
            setReviewStats({
              averageRating: parseFloat(apiReviewStats.averageRating || 0),
              totalReviews: parseInt(apiReviewStats.count || 0),
            });
            console.log("Direct API review stats:", response.data);
          }
        } catch (error) {
          console.error("Error fetching direct review stats:", error);
          setReviewStats(propReviewStats);
        }
      };

      fetchReviewStats();
    }
  }, [product?.uuid, reviewStatsKey, propReviewStats]);

  // Price and stock calculations
  const getDisplayPrice = () => {
    if (selectedVariant) {
      return {
        originalPrice: selectedVariant.original_price,
        discount: selectedVariant.discount,
        finalPrice: calculatePrice(
          selectedVariant.original_price,
          selectedVariant.discount
        ),
        stock: selectedVariant.stock || 0,
      };
    }

    return {
      originalPrice: product.original_price,
      discount: product.discount,
      finalPrice: calculatePrice(product.original_price, product.discount),
      stock: product.stock || 0,
    };
  };

  const calculatePrice = (basePrice, discount) => {
    if (!discount) return basePrice;
    return basePrice * (1 - discount / 100);
  };

  // Quantity control
  const handleQuantityChange = (e) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0 && value <= getDisplayPrice().stock) {
      setQuantity(value);
    }
  };

  const incrementQuantity = () => {
    if (quantity < getDisplayPrice().stock) {
      setQuantity(quantity + 1);
    }
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  // Add to cart
  const handleAddToCart = async () => {
    if (!getDisplayPrice().stock > 0) return;

    setAddingToCart(true);

    try {
      let selectedAttributes = [];

      // If we have a selected variant, use its attributes
      if (selectedVariant && selectedVariant.attributes) {
        selectedAttributes = [...selectedVariant.attributes];
      } else if (product && product.attributes) {
        selectedAttributes = [...product.attributes];
      }

      const variantId = selectedVariant ? selectedVariant.uuid : null;

      const success = await addToCart(
        product.uuid,
        variantId,
        quantity,
        selectedAttributes
      );

      if (success) {
        setProductAdded(true);
        setTimeout(() => setProductAdded(false), 3000);
      }
    } catch (err) {
      console.error("Error adding to cart:", err);
      alert(
        err.response?.data?.message || "Error adding to cart. Please try again."
      );
    } finally {
      setAddingToCart(false);
    }
  };

  const { originalPrice, discount, finalPrice, stock } = getDisplayPrice();
  const inStock = stock > 0;

  return (
    <div
      className="lg:w-1/2 p-6 lg:border-l border-gray-200"
      id="product-details"
    >
      <h1 className="text-2xl font-bold text-gray-900">{product.name}</h1>

      <div className="flex items-center mb-4">
        <div className="flex">
          {[...Array(5)].map((_, i) => {
            if (i < Math.floor(reviewStats.averageRating)) {
              // Full star
              return (
                <FontAwesomeIcon
                  key={i}
                  icon={solidStar}
                  className="text-yellow-400"
                />
              );
            } else if (
              i === Math.floor(reviewStats.averageRating) &&
              reviewStats.averageRating % 1 >= 0.3 &&
              reviewStats.averageRating % 1 < 0.8
            ) {
              // Half star (for ratings with decimal part between 0.3 and 0.8)
              return (
                <FontAwesomeIcon
                  key={i}
                  icon={faStarHalfAlt}
                  className="text-yellow-400"
                />
              );
            } else {
              // Empty star
              return (
                <FontAwesomeIcon
                  key={i}
                  icon={regularStar}
                  className="text-gray-300"
                />
              );
            }
          })}
        </div>
        <span className="ml-2 text-sm text-gray-600">
          {reviewStats.averageRating > 0
            ? `${reviewStats.averageRating.toFixed(1)} (${
                reviewStats.totalReviews
              } ${reviewStats.totalReviews === 1 ? "review" : "reviews"})`
            : "No reviews yet"}
        </span>
      </div>

      <ProductPrice
        finalPrice={finalPrice}
        originalPrice={originalPrice}
        discount={discount}
      />

      <StockDisplay stock={stock} />

      {product.variants && product.variants.length > 0 && (
        <div className="mt-6">
          <VariantSelector
            product={product}
            variants={product.variants}
            selectedVariant={selectedVariant}
            onVariantChange={onVariantChange}
          />
        </div>
      )}

      <QuantitySelector
        quantity={quantity}
        stock={stock}
        onIncrement={incrementQuantity}
        onDecrement={decrementQuantity}
        onChange={handleQuantityChange}
      />

      <ProductActions
        inStock={inStock}
        addingToCart={addingToCart}
        productAdded={productAdded}
        onAddToCart={handleAddToCart}
      />

      <DeliveryInfoSection />

      <SocialSharingSection />
    </div>
  );
};

export default ProductInfoSection;
