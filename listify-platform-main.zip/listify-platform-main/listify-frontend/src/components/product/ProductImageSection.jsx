import React from 'react';
import ImageGallery from './ImageGallery';

const ProductImageSection = ({ productImages, variantImages }) => {
  return (
    <div className="lg:w-1/2 p-6">
      <ImageGallery
        images={productImages}
        variantImages={variantImages}
      />
    </div>
  );
};

export default ProductImageSection;