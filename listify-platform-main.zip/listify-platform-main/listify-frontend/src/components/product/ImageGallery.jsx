import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faSearch,
  faChevronLeft,
  faChevronRight,
} from "@fortawesome/free-solid-svg-icons";

const ImageGallery = ({ images, variantImages = [] }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [lightboxOpen, setLightboxOpen] = useState(false);

  // Combining all the images of the product and variantts together
  const allImages = [
    ...variantImages,
    ...images.filter(
      (img) => !variantImages.some((vImg) => vImg.key === img.key)
    ),
  ];

  // Reseting the current image index when variant images change
  useEffect(() => {
    if (variantImages?.length > 0) {
      setCurrentImageIndex(0);
    }
  }, [variantImages]);

  const handlePrevious = (e) => {
    e.stopPropagation();
    setCurrentImageIndex((prevIndex) =>
      prevIndex === 0 ? allImages.length - 1 : prevIndex - 1
    );
  };

  const handleNext = (e) => {
    e.stopPropagation();
    setCurrentImageIndex((prevIndex) =>
      prevIndex === allImages.length - 1 ? 0 : prevIndex + 1
    );
  };

  const handleImageClick = () => {
    if (window.innerWidth >= 768) {
      setLightboxOpen(true);
    }
  };

  const handleMouseMove = (e) => {
    if (isZoomed) {
      const { left, top, width, height } =
        e.currentTarget.getBoundingClientRect();
      const x = ((e.clientX - left) / width) * 100;
      const y = ((e.clientY - top) / height) * 100;
      setMousePosition({ x, y });
    }
  };

  // Geting the image's URL
  const getImageUrl = (image) => {
    if (!image) return "/placeholder-product.png";

    if (image.url && image.url.startsWith("http")) {
      return image.url;
    }

    return `https://pub-e2dfc4f311fa40c0b98535194e9c7266.r2.dev/${image.key}`;
  };

  if (allImages.length === 0) {
    return (
      <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
        <span className="text-gray-400">No image available</span>
      </div>
    );
  }

  return (
    <div>
      <div
        className="relative overflow-hidden bg-gray-50 rounded-lg aspect-square mb-4"
        onClick={handleImageClick}
        onMouseEnter={() => setIsZoomed(true)}
        onMouseLeave={() => setIsZoomed(false)}
        onMouseMove={handleMouseMove}
      >
        <img
          src={getImageUrl(allImages[currentImageIndex])}
          alt={allImages[currentImageIndex]?.altText || "Product image"}
          className={`w-full h-full object-contain transition-transform duration-200 ${
            isZoomed ? "scale-125" : ""
          }`}
          style={
            isZoomed
              ? {
                  transformOrigin: `${mousePosition.x}% ${mousePosition.y}%`,
                }
              : {}
          }
        />

        <div className="absolute top-4 right-4 bg-white text-gray-600 p-2 rounded-full shadow-md hidden md:block">
          <FontAwesomeIcon icon={faSearch} />
        </div>

        {allImages.length > 1 && (
          <>
            <button
              onClick={handlePrevious}
              className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white text-gray-800 rounded-full p-2 shadow-md focus:outline-none hover:bg-gray-100"
            >
              <FontAwesomeIcon icon={faChevronLeft} />
            </button>
            <button
              onClick={handleNext}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white text-gray-800 rounded-full p-2 shadow-md focus:outline-none hover:bg-gray-100"
            >
              <FontAwesomeIcon icon={faChevronRight} />
            </button>
          </>
        )}
      </div>

      {allImages.length > 1 && (
        <div className="flex overflow-x-auto space-x-2 pb-2">
          {allImages.map((image, index) => (
            <div
              key={index}
              onClick={() => setCurrentImageIndex(index)}
              className={`flex-shrink-0 w-16 h-16 rounded-md border-2 cursor-pointer overflow-hidden ${
                currentImageIndex === index
                  ? "border-cyan-500"
                  : "border-gray-200"
              }`}
            >
              <img
                src={getImageUrl(image)}
                alt={image.altText || `Thumbnail ${index + 1}`}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
        </div>
      )}

      {lightboxOpen && (
        <div
          className="fixed inset-0 z-50 bg-black bg-opacity-90 flex items-center justify-center"
          onClick={() => setLightboxOpen(false)}
        >
          <button
            className="absolute top-4 right-4 text-white text-xl p-2"
            onClick={() => setLightboxOpen(false)}
          >
            &times;
          </button>

          <div className="relative max-w-4xl w-full mx-auto">
            <img
              src={getImageUrl(allImages[currentImageIndex])}
              alt={allImages[currentImageIndex]?.altText || "Product image"}
              className="max-h-[80vh] mx-auto"
            />

            {allImages.length > 1 && (
              <>
                <button
                  onClick={handlePrevious}
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white text-gray-800 rounded-full p-3 shadow-md focus:outline-none hover:bg-gray-100"
                >
                  <FontAwesomeIcon icon={faChevronLeft} />
                </button>
                <button
                  onClick={handleNext}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white text-gray-800 rounded-full p-3 shadow-md focus:outline-none hover:bg-gray-100"
                >
                  <FontAwesomeIcon icon={faChevronRight} />
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageGallery;
