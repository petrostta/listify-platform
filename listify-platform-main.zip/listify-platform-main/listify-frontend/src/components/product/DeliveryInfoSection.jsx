import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faShippingFast,
  faClock,
  faUndo,
  faShieldAlt,
} from "@fortawesome/free-solid-svg-icons";

const DeliveryInfoSection = () => {
  return (
    <div className="mt-8 border-t border-gray-200 pt-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">
        Delivery & Returns
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-cyan-50 p-3 rounded-lg">
          <div className="flex items-start">
            <FontAwesomeIcon
              icon={faShippingFast}
              className="text-cyan-500 mr-3 mt-1 text-lg"
            />
            <div>
              <h4 className="font-medium text-cyan-800">Free Shipping</h4>
              <p className="text-sm text-cyan-700">On orders over $35</p>
            </div>
          </div>
        </div>

        <div className="bg-cyan-50 p-3 rounded-lg">
          <div className="flex items-start">
            <FontAwesomeIcon
              icon={faClock}
              className="text-cyan-500 mr-3 mt-1 text-lg"
            />
            <div>
              <h4 className="font-medium text-cyan-800">Fast Delivery</h4>
              <p className="text-sm text-cyan-700">3-5 business days</p>
            </div>
          </div>
        </div>

        <div className="bg-cyan-50 p-3 rounded-lg">
          <div className="flex items-start">
            <FontAwesomeIcon
              icon={faUndo}
              className="text-cyan-500 mr-3 mt-1 text-lg"
            />
            <div>
              <h4 className="font-medium text-cyan-800">Easy Returns</h4>
              <p className="text-sm text-cyan-700">30-day return policy</p>
            </div>
          </div>
        </div>

        <div className="bg-cyan-50 p-3 rounded-lg">
          <div className="flex items-start">
            <FontAwesomeIcon
              icon={faShieldAlt}
              className="text-cyan-500 mr-3 mt-1 text-lg"
            />
            <div>
              <h4 className="font-medium text-cyan-800">Secure Payment</h4>
              <p className="text-sm text-cyan-700">Protected checkout</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryInfoSection;
