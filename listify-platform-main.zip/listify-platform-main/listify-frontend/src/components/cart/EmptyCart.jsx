import React from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faShoppingCart } from "@fortawesome/free-solid-svg-icons";

const EmptyCart = ({ onClose }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full p-8 text-center">
      <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-6">
        <FontAwesomeIcon
          icon={faShoppingCart}
          className="text-gray-400 text-3xl"
        />
      </div>

      <h3 className="text-lg font-medium text-gray-900 mb-2">
        Your cart is empty
      </h3>
      <p className="text-gray-500 mb-6">
        Looks like you haven't added any products to your cart yet.
      </p>

      <div className="space-y-3 w-full">
        <Link
          to="/"
          onClick={onClose}
          className="block w-full py-3 px-4 bg-cyan-500 text-white rounded-lg text-center font-medium hover:bg-cyan-600 transition-colors"
        >
          Continue Shopping
        </Link>

        <Link
          to="/trending"
          onClick={onClose}
          className="block w-full py-3 px-4 border border-gray-300 rounded-lg text-center text-gray-700 font-medium hover:bg-gray-50 transition-colors"
        >
          Discover Trending Products
        </Link>
      </div>
    </div>
  );
};

export default EmptyCart;
