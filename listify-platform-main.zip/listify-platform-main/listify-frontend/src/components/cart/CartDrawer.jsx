import React, { useContext } from "react";
import { useCart } from "../../context/CartContext";
import CartItem from "./CartItem";
import EmptyCart from "./EmptyCart";
import CartFooter from "./CartFooter";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faClose, faSpinner, faLock } from "@fortawesome/free-solid-svg-icons";
import { AuthContext } from "../../context/AuthContext";

const CartDrawer = () => {
  const {
    cart,
    loading,
    error,
    isCartOpen,
    setIsCartOpen,
    cartItemCount,
    cartSubtotal,
  } = useCart();

  const { isAuthenticated, openLoginModal } = useContext(AuthContext);

  if (!isCartOpen) return null;

  // Handle login button click
  const handleLoginClick = () => {
    setIsCartOpen(false);
    // Open login modal with login tab
    openLoginModal("Login");
  };

  // Handle register button click
  const handleRegisterClick = () => {
    setIsCartOpen(false);
    // Open login modal with register tab
    openLoginModal("Register");
  };

  const LoginPrompt = () => (
    <div className="flex-1 overflow-y-auto p-4 flex flex-col items-center justify-center text-gray-600">
      <FontAwesomeIcon icon={faLock} className="text-3xl mb-4 text-cyan-500" />
      <h3 className="text-lg font-medium text-center mb-3">
        Please log in to view your cart
      </h3>
      <p className="text-center text-sm mb-6">
        You need to be logged in to add items to your cart and checkout.
      </p>
      <button
        onClick={handleLoginClick}
        className="px-6 py-2 bg-cyan-500 text-white rounded hover:bg-cyan-600 transition-colors"
      >
        Log In
      </button>
      <button
        onClick={handleRegisterClick}
        className="mt-3 text-cyan-600 hover:text-cyan-800"
      >
        Create an account
      </button>
    </div>
  );

  return (
    <div className="fixed inset-0 overflow-hidden z-50">
      <div
        className="absolute inset-0 bg-black bg-opacity-50 transition-opacity"
        onClick={() => setIsCartOpen(false)}
      ></div>

      <div className="absolute inset-y-0 right-0 max-w-md w-full bg-white shadow-xl flex flex-col transform transition-transform">
        <div className="p-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-medium text-gray-900">
            Your Cart
            {isAuthenticated && cartItemCount > 0 && (
              <span className="ml-2 text-sm text-cyan-600">
                ({cartItemCount} items)
              </span>
            )}
          </h2>
          <button
            onClick={() => setIsCartOpen(false)}
            className="text-gray-500 hover:text-gray-700 p-1 rounded-full focus:outline-none focus:ring-2 focus:ring-cyan-500"
          >
            <FontAwesomeIcon icon={faClose} size="lg" />
          </button>
        </div>

        {!isAuthenticated ? (
          <LoginPrompt />
        ) : (
          <div className="flex-1 overflow-y-auto p-4">
            {loading ? (
              <div className="flex justify-center items-center h-full">
                <FontAwesomeIcon
                  icon={faSpinner}
                  spin
                  className="text-cyan-500 text-2xl"
                />
              </div>
            ) : error ? (
              <div className="bg-red-50 p-4 rounded text-red-600 text-center my-4">
                {error}
                <button
                  onClick={() => window.location.reload()}
                  className="underline ml-2 text-red-700"
                >
                  Try again
                </button>
              </div>
            ) : !cart || !cart.items || cart.items.length === 0 ? (
              <EmptyCart onClose={() => setIsCartOpen(false)} />
            ) : (
              <div className="space-y-4">
                {cart.items.map((item) => (
                  <CartItem
                    key={item.id || item._id || item.productId}
                    item={item}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {isAuthenticated && cart && cart.items && cart.items.length > 0 && (
          <CartFooter subtotal={cartSubtotal} />
        )}
      </div>
    </div>
  );
};

export default CartDrawer;
