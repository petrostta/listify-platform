import React, { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../../context/CartContext";
import { AuthContext } from "../../context/AuthContext";

const CartFooter = ({ subtotal }) => {
  const { clearCart, setIsCartOpen } = useCart();
  const { isAuthenticated } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleCheckout = () => {
    setIsCartOpen(false);
    navigate("/checkout");
  };

  return (
    <div className="border-t border-gray-200 p-4 space-y-4">
      <div className="flex justify-between items-center">
        <span className="text-base font-medium text-gray-900">Subtotal</span>
        <span className="text-lg font-bold text-cyan-600">
          ${subtotal.toFixed(2)}
        </span>
      </div>

      <p className="text-xs text-gray-500">
        Shipping and taxes will be calculated at checkout.
      </p>

      <div className="space-y-2">
        <button
          onClick={handleCheckout}
          className="block w-full py-3 px-4 bg-cyan-500 text-white rounded-lg text-center font-medium hover:bg-cyan-600 transition-colors"
        >
          Proceed to Checkout
        </button>

        <button
          onClick={clearCart}
          className="block w-full py-3 px-4 text-cyan-700 bg-cyan-50 rounded-lg text-center font-medium hover:bg-cyan-100 transition-colors"
        >
          Clear Cart
        </button>
      </div>
    </div>
  );
};

export default CartFooter;
