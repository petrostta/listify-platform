import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { useCart } from "../../context/CartContext";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash, faSpinner } from "@fortawesome/free-solid-svg-icons";
import QuantitySelector from "../shared/QuantitySelector";

const CartItem = ({ item }) => {
  const { updateCartItem, removeCartItem } = useCart();
  const [isUpdating, setIsUpdating] = useState(false);
  const [isRemoving, setIsRemoving] = useState(false);
  const [localItem, setLocalItem] = useState(item);

  // Fetch missing product details if needed
  useEffect(() => {
    const fetchMissingProductDetails = async () => {
      if (item.productId && !item.product) {
        try {
          const response = await axios.get(
            `http://localhost:8080/api/products/${item.productId}`
          );

          // Manually enrich the item with product data
          const enrichedItem = {
            ...item,
            product: {
              uuid: response.data.uuid,
              name: response.data.name,
              pictures: response.data.pictures || [],
              stock: response.data.stock,
              discount: response.data.discount,
            },
          };

          setLocalItem(enrichedItem);
        } catch (err) {
          console.error(
            `Failed to fetch product details for ${item.productId}:`,
            err
          );
        }
      } else {
        setLocalItem(item);
      }
    };

    fetchMissingProductDetails();
  }, [item]);

  // Update quantity handler
  const handleQuantityChange = async (newQuantity) => {
    if (newQuantity === localItem.quantity) return;

    setIsUpdating(true);
    console.log("Updating item with ID:", localItem._id);
    await updateCartItem(localItem._id, newQuantity);
    setIsUpdating(false);
  };

  // Remove item handler
  const handleRemove = async () => {
    setIsRemoving(true);
    console.log("Removing item with ID:", localItem._id);
    await removeCartItem(localItem._id);
    setIsRemoving(false);
  };

  // Calculating the final price with the discount included
  const calculateFinalPrice = () => {
    let originalPrice;
    let discount;

    if (localItem.variantId && localItem.variant) {
      // Using the price of the variant
      originalPrice = localItem.variant.original_price || localItem.price;
      discount = localItem.variant.discount || 0;
    } else {
      // If it's the main product then it will use the main products price
      originalPrice = localItem.product?.original_price || localItem.price;
      discount = localItem.product?.discount || 0;
    }

    // Calculating the final price if there is a discount included
    if (discount > 0) {
      const discountedPrice = originalPrice * (1 - discount / 100);
      return {
        originalPrice: originalPrice * localItem.quantity,
        finalPrice: discountedPrice * localItem.quantity,
        discount,
      };
    }

    return {
      finalPrice: originalPrice * localItem.quantity,
      originalPrice: null,
      discount: 0,
    };
  };

  // Price info
  const { finalPrice, originalPrice, discount } = calculateFinalPrice();

  // Get image URL with fallbacks
  const getImageUrl = () => {
    // Debug log
    console.log("Getting image for item:", {
      hasProductObj: !!localItem.product,
      hasPictures: !!localItem.product?.pictures,
      picturesLength: localItem.product?.pictures?.length || 0,
      firstPicture: localItem.product?.pictures?.[0],
    });

    // If no product info
    if (!localItem.product?.pictures && !localItem.product?.images) {
      return "/placeholder-product.png";
    }

    const pictures =
      localItem.product?.pictures || localItem.product?.images || [];

    if (pictures.length === 0) {
      return "/placeholder-product.png";
    }

    const picture = pictures[0];

    // If it has a complete URL
    if (picture.url && picture.url.startsWith("http")) {
      return picture.url;
    }

    // If it has a key
    if (picture.key) {
      return `https://pub-e2dfc4f311fa40c0b98535194e9c7266.r2.dev/${picture.key}`;
    }

    // If the product has no picture or key then we can return the place holder picture which I need to add
    return "/placeholder-product.png";
  };

  // Getting the variant data of the item
  const getVariantInfo = () => {
    if (
      localItem.selectedAttributes &&
      localItem.selectedAttributes.length > 0
    ) {
      return localItem.selectedAttributes
        .map((attr) => `${attr.key}: ${attr.value}`)
        .join(", ");
    }

    if (localItem.variant && localItem.variant.attributes) {
      return localItem.variant.attributes
        .map((attr) => `${attr.key}: ${attr.value}`)
        .join(", ");
    }

    if (localItem.product && localItem.product.attributes) {
      return localItem.product.attributes
        .map((attr) => `${attr.key}: ${attr.value}`)
        .join(", ");
    }

    return "";
  };

  const productName = localItem.product?.name || localItem.name || "Product";
  const productUrl = `/product/${
    localItem.productId || localItem.product?.uuid
  }`;
  const imageUrl = getImageUrl();
  const variantInfo = getVariantInfo();

  console.log("Cart item structure:", localItem);

  return (
    <div className="flex items-start border-b border-gray-200 pb-4">
      <Link
        to={productUrl}
        className="w-20 h-20 rounded overflow-hidden flex-shrink-0 bg-gray-100"
      >
        <img
          src={imageUrl}
          alt={productName}
          className="w-full h-full object-cover"
          onError={(e) => {
            e.target.src = "/placeholder-product.png";
          }}
        />
      </Link>

      <div className="ml-4 flex-1">
        <Link
          to={productUrl}
          className="text-sm font-medium text-gray-900 hover:text-cyan-600 line-clamp-2"
        >
          {productName}
        </Link>

        {variantInfo && (
          <p className="text-xs text-gray-500 mt-1">{variantInfo}</p>
        )}

        <div className="mt-2 flex items-center justify-between">
          <div className="flex items-center">
            {isUpdating ? (
              <FontAwesomeIcon
                icon={faSpinner}
                spin
                className="text-gray-400"
              />
            ) : (
              <QuantitySelector
                quantity={localItem.quantity}
                onChange={handleQuantityChange}
                max={localItem.product?.stock || 10}
                min={1}
                small
              />
            )}
          </div>

          <div className="flex items-center">
            {discount > 0 ? (
              <div className="flex flex-col items-end">
                <span className="text-sm font-medium text-gray-900">
                  ${finalPrice.toFixed(2)}
                </span>
                <span className="text-xs text-gray-500 line-through">
                  ${originalPrice.toFixed(2)}
                </span>
              </div>
            ) : (
              <span className="text-sm font-medium text-gray-900 mr-3">
                ${finalPrice.toFixed(2)}
              </span>
            )}

            <button
              onClick={handleRemove}
              disabled={isRemoving}
              className="text-gray-400 hover:text-red-500 transition-colors ml-3"
              aria-label="Remove item"
            >
              {isRemoving ? (
                <FontAwesomeIcon icon={faSpinner} spin />
              ) : (
                <FontAwesomeIcon icon={faTrash} />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartItem;
