import React, { useContext } from "react";
import { ShoppingCartIcon } from "@heroicons/react/outline";
import { useCart } from "../../context/CartContext";
import { AuthContext } from "../../context/AuthContext";

const CartIcon = () => {
  const { setIsCartOpen, cartItemCount } = useCart();
  const { isAuthenticated } = useContext(AuthContext);

  return (
    <div className="relative">
      <ShoppingCartIcon
        className="cursor-pointer h-6 w-6 hover:text-cyan-500"
        onClick={() => setIsCartOpen(true)}
      />

      {isAuthenticated && cartItemCount > 0 && (
        <span className="absolute -top-1 -right-1 bg-cyan-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full min-w-[16px] h-[16px] flex items-center justify-center text-center">
          {cartItemCount > 99 ? "99+" : cartItemCount}
        </span>
      )}
    </div>
  );
};

export default CartIcon;
