import { useState, useEffect, useRef } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export const useSearch = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const navigate = useNavigate();
  const debounceTimer = useRef(null);
  const suggestionRef = useRef(null);

  // If user clicks outside of the suggestioins then it closes
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        suggestionRef.current &&
        !suggestionRef.current.contains(event.target)
      ) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // fetching suggestiopns
  useEffect(() => {
    if (searchTerm.length >= 2) {
      setIsLoading(true);
      clearTimeout(debounceTimer.current);

      debounceTimer.current = setTimeout(async () => {
        try {
          const response = await axios.get(
            `http://localhost:8080/api/search/suggestions?q=${encodeURIComponent(
              searchTerm
            )}`
          );
          setSuggestions(response.data || []);
          setShowSuggestions(true);
        } catch (error) {
          console.error("Error fetching search suggestions:", error);
          setSuggestions([]);
        } finally {
          setIsLoading(false);
        }
      }, 300); // 300ms debounce delay
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }

    return () => {
      clearTimeout(debounceTimer.current);
    };
  }, [searchTerm]);

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchTerm.trim())}`);
      setShowSuggestions(false);
    }
  };

  const handleSuggestionClick = (suggestion) => {
    setSearchTerm(suggestion);
    navigate(`/search?q=${encodeURIComponent(suggestion)}`);
    setShowSuggestions(false);
  };

  return {
    searchTerm,
    suggestions,
    isLoading,
    showSuggestions,
    suggestionRef,
    handleSearchChange,
    handleSearchSubmit,
    handleSuggestionClick,
    setShowSuggestions,
  };
};
