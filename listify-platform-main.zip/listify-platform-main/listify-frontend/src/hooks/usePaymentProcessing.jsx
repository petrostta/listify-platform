import { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import axios from "axios";

export const usePaymentProcessing = () => {
  const { user } = useContext(AuthContext);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);
  const [orderId, setOrderId] = useState(null);

  const processPayment = async (orderData, paymentData) => {
    try {
      setProcessing(true);
      setError(null);

      // First create the order
      const orderResponse = await axios.post(
        "http://localhost:8080/api/orders",
        {
          ...orderData,
          userId: user.uuid,
        },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      const { orderId } = orderResponse.data;
      setOrderId(orderId);

      // Then process the payment
      const paymentResponse = await axios.post(
        "http://localhost:8080/api/payments/process",
        {
          orderId,
          userId: user.uuid,
          amount: orderData.totalAmount,
          paymentMethod: paymentData.paymentMethod,
          gatewayType: paymentData.gatewayType,
        },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );

      setResult(paymentResponse.data);
      return {
        success: true,
        order: orderResponse.data,
        payment: paymentResponse.data,
      };
    } catch (err) {
      console.error("Payment processing error:", err);
      setError(
        err.response?.data?.message ||
          "There was a problem processing your payment. Please try again."
      );
      return {
        success: false,
        error: err.response?.data?.message || "Payment processing failed",
      };
    } finally {
      setProcessing(false);
    }
  };

  return {
    processPayment,
    processing,
    error,
    result,
    orderId,
    clearError: () => setError(null),
  };
};
